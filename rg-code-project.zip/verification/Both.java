import java.awt.image.BufferedImage; import java.io.*; import java.nio.file.*; import java.security.*; import java.util.*; import java.util.zip.*;
import javax.crypto.*; import java.security.SecureRandom; import javax.crypto.spec.*; import javax.imageio.ImageIO;

public class Both {
  static class Bits { int w,h; byte[] b; Bits(int w,int h){this.w=w;this.h=h;b=new byte[(int)(((long)w*h+7)>>3)];}
    void set(int x,int y){long i=(long)y*w+x;int k=(int)(i>>3);b[k]=(byte)(b[k]|(0x80>>(int)(i&7)));}
    boolean get(int x,int y){long i=(long)y*w+x;return ((b[(int)(i>>3)]>>(7-(int)(i&7)))&1)==1;}}
  static class Ori { Bits s;int k,width,height; Ori(Bits s,int k){this.s=s;this.k=k;width=k%2==0?s.w:s.h;height=k%2==0?s.h:s.w;}
    boolean get(int x,int y){switch(k){case 0:return s.get(x,y);case 1:return s.get(s.w-1-y,x);case 2:return s.get(s.w-1-x,s.h-1-y);default:return s.get(y,s.h-1-x);}}}
  static Bits toBits(BufferedImage im){Bits r=new Bits(im.getWidth(),im.getHeight());int[] row=new int[im.getWidth()];
    for(int y=0;y<im.getHeight();y++){im.getRGB(0,y,im.getWidth(),1,row,0,im.getWidth());for(int x=0;x<row.length;x++){int p=row[x];int l=(299*((p>>16)&255)+587*((p>>8)&255)+114*(p&255))/1000;if(l<128)r.set(x,y);}}return r;}
  static Bits crop(Bits img){int x0=Integer.MAX_VALUE,x1=-1,y0=Integer.MAX_VALUE,y1=-1;for(int y=0;y<img.h;y++)for(int x=0;x<img.w;x++)if(img.get(x,y)){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}
    if(x1<0)return null;Bits o=new Bits(x1-x0+1,y1-y0+1);for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++)if(img.get(x,y))o.set(x-x0,y-y0);return o;}
  interface At{boolean f(int i);}
  static int runs(int len,At a){int n=0;boolean prev=false;for(int i=0;i<len;i++){boolean b=a.f(i);if(b&&!prev)n++;prev=b;}return n;}
  static boolean[] grid; static int gw,gh;
  static boolean sample(Ori o){int bw=o.width,bh=o.height;int pX=0;while(pX<bw&&o.get(bw-1-pX,bh/2))pX++;int pY=0;while(pY<bh&&o.get(bw/2,bh-1-pY))pY++;pX=Math.max(pX,1);pY=Math.max(pY,1);
    final int topY=Math.min(pY/2,bh-1),leftX=Math.min(pX/2,bw-1);int w=2*runs(bw,i->o.get(i,topY))-1,h=2*runs(bh,i->o.get(leftX,i))-1;
    if(w<9||h<9||Math.abs(w*pX-bw)>w||Math.abs(h*pY-bh)>h)return false;double px=(double)bw/w,py=(double)bh/h;int[] cols=new int[w],rows=new int[h];
    for(int i=0;i<w;i++)cols[i]=(int)((i+0.5)*px);for(int i=0;i<h;i++)rows[i]=(int)((i+0.5)*py);boolean[] g=new boolean[w*h];
    for(int r=0;r<h;r++)for(int c=0;c<w;c++)g[r*w+c]=o.get(cols[c],rows[r]);
    for(int c=0;c<w;c++)if(!g[(h-1)*w+c])return false;for(int r=0;r<h;r++)if(!g[r*w+w-1])return false;
    for(int c=0;c<w;c++)if(g[c]!=(c%2==0))return false;for(int r=0;r<h;r++)if(g[r*w]!=(r%2==0))return false;grid=g;gw=w;gh=h;return true;}
  static byte[] gridBytes(){byte[] out=new byte[((gh-4)*(gw-4)+7)/8];int i=0;for(int r=2;r<gh-2;r++)for(int c=2;c<gw-2;c++){if(grid[r*gw+c])out[i>>3]=(byte)(out[i>>3]|(0x80>>(i&7)));i++;}return out;}
  static int crc16(byte[] d,int off,int len){int crc=0xFFFF;for(int i=off;i<off+len;i++){crc^=(d[i]&0xFF)<<8;for(int k=0;k<8;k++){crc=((crc&0x8000)!=0)?(crc<<1)^0x1021:crc<<1;crc&=0xFFFF;}}return crc;}
  static byte[] pbkdf2(String pw,byte[] salt,int it,int dk)throws Exception{byte[] p=pw.getBytes("UTF-8");int blocks=(dk+31)/32;byte[] out=new byte[dk];
    for(int b=1;b<=blocks;b++){Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(p,"HmacSHA256"));m.update(salt);m.update(new byte[]{(byte)(b>>>24),(byte)(b>>>16),(byte)(b>>>8),(byte)b});
      byte[] u=m.doFinal();byte[] t=u.clone();for(int i=1;i<it;i++){u=m.doFinal(u);for(int k=0;k<t.length;k++)t[k]^=u[k];}System.arraycopy(t,0,out,(b-1)*32,Math.min(32,dk-(b-1)*32));}return out;}
  // ChaCha20 stream
  static class CC{int[] st=new int[16],w=new int[16];byte[] blk=new byte[64];int pos=64,ctr=0;
    CC(byte[] key,byte[] nonce){st[0]=0x61707865;st[1]=0x3320646e;st[2]=0x79622d32;st[3]=0x6b206574;for(int i=0;i<8;i++)st[4+i]=le(key,i*4);for(int i=0;i<3;i++)st[13+i]=le(nonce,i*4);}
    int le(byte[] b,int o){return (b[o]&255)|((b[o+1]&255)<<8)|((b[o+2]&255)<<16)|((b[o+3]&255)<<24);}
    void q(int a,int b,int c,int d){w[a]+=w[b];w[d]=Integer.rotateLeft(w[d]^w[a],16);w[c]+=w[d];w[b]=Integer.rotateLeft(w[b]^w[c],12);w[a]+=w[b];w[d]=Integer.rotateLeft(w[d]^w[a],8);w[c]+=w[d];w[b]=Integer.rotateLeft(w[b]^w[c],7);}
    void refill(){st[12]=ctr++;System.arraycopy(st,0,w,0,16);for(int r=0;r<10;r++){q(0,4,8,12);q(1,5,9,13);q(2,6,10,14);q(3,7,11,15);q(0,5,10,15);q(1,6,11,12);q(2,7,8,13);q(3,4,9,14);}
      for(int i=0;i<16;i++){int v=w[i]+st[i];blk[i*4]=(byte)v;blk[i*4+1]=(byte)(v>>>8);blk[i*4+2]=(byte)(v>>>16);blk[i*4+3]=(byte)(v>>>24);}pos=0;}
    int nb(){if(pos==64)refill();return blk[pos++]&255;}
    long u32(){long a=nb(),b=nb(),c=nb(),d=nb();return a|(b<<8)|(c<<16)|(d<<24);}}
  static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format("%02x",x));return s.toString();}
  static byte[] inflate(byte[] d)throws Exception{Inflater i=new Inflater();i.setInput(d);ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] buf=new byte[65536];while(!i.finished()){int n=i.inflate(buf);if(n==0&&i.needsInput())throw new Exception("damaged");o.write(buf,0,n);}return o.toByteArray();}
  static byte[] open(Bits box,String pw)throws Exception{
    for(int k=0;k<4;k++){ if(!sample(new Ori(box,k)))continue; byte[] raw=gridBytes(); if(raw.length<8||(raw[0]&255)!=0xA5)continue; int ver=raw[1]&255; if(ver<1||ver>3)continue;
      int pos=2,flags=0; if(ver==3){flags=raw[2]&255;pos=3;} long len=((raw[pos]&255L)<<24)|((raw[pos+1]&255L)<<16)|((raw[pos+2]&255L)<<8)|(raw[pos+3]&255L); pos+=4+(ver==3?28:0);
      if(pos+len+2>raw.length)continue; byte[] pay=Arrays.copyOfRange(raw,pos,pos+(int)len); int crc=((raw[pos+(int)len]&255)<<8)|(raw[pos+(int)len+1]&255);
      if(crc!=crc16(pay,0,pay.length))throw new Exception("CRC");
      if(ver==1)return pay; if(ver==2)return inflate(pay); byte[] head=Arrays.copyOfRange(raw,0,pos); byte[] salt=Arrays.copyOfRange(head,7,23),nonce=Arrays.copyOfRange(head,23,35);
      byte[] key=pbkdf2(pw,salt,200000,32); Cipher c; if((flags&4)!=0){c=Cipher.getInstance("ChaCha20-Poly1305");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"ChaCha20"),new IvParameterSpec(nonce));}
      else{c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));}
      c.updateAAD(head); byte[] body=c.doFinal(pay); return (flags&1)!=0?inflate(body):body; }
    throw new Exception("not a code"); }
  static final int SQ=8,COLS=96,ROWS=174,N=COLS*ROWS,SQB=192,IMG_ROWS=173,MAXW=768,MAXH=1384; static final long K=10325L,KINV=6845L;
static void sq()throws Exception{
    String dir="/mnt/user-data/outputs/rgcode-android/app/src/test/resources/vectors/";
    BufferedImage im=ImageIO.read(new File(dir+"square_file.png")); int w=im.getWidth(),h=im.getHeight(); int[] px=new int[w*h]; im.getRGB(0,0,w,h,px,0,w);
    String pw="sq-pw"; byte[] file=null;
    for(int k=0;k<4;k++){ int ow=(k%2==0)?w:h; if(ow!=768)continue; final int kk=k;
      java.util.function.IntBinaryOperator at=(x,y)->{switch(kk){case 0:return px[y*w+x];case 1:return px[x*w+(w-1-y)];case 2:return px[(h-1-y)*w+(w-1-x)];default:return px[(h-1-x)*w+y];}};
      byte[] head=new byte[SQB]; for(int ty=0;ty<8;ty++)for(int tx=0;tx<8;tx++){int p=at.applyAsInt(tx,ty);int o=(ty*8+tx)*3;head[o]=(byte)(p>>16);head[o+1]=(byte)(p>>8);head[o+2]=(byte)p;}
      byte[] salt=Arrays.copyOfRange(head,0,16),nonce=Arrays.copyOfRange(head,16,28); byte[] d=pbkdf2(pw,salt,200000,96);
      byte[] enc=Arrays.copyOfRange(d,0,32),hdr=Arrays.copyOfRange(d,32,64),perm=Arrays.copyOfRange(d,64,96);
      CC m=new CC(hdr,nonce); byte[] f=new byte[12]; for(int i=0;i<12;i++)f[i]=(byte)(head[28+i]^m.nb());
      if(!new String(f,8,4,"US-ASCII").equals("SQv1"))continue;
      long hh=((f[4]&255L)<<24)|((f[5]&255L)<<16)|((f[6]&255L)<<8)|(f[7]&255L); byte[] tag=Arrays.copyOfRange(head,40,56);
      byte[] out=new byte[N*SQB]; for(int i=0;i<N;i++){int r=i/COLS,c=i%COLS;for(int ty=0;ty<8;ty++)for(int tx=0;tx<8;tx++){int p=at.applyAsInt(c*8+tx,r*8+ty);int o=i*SQB+(ty*8+tx)*3;out[o]=(byte)(p>>16);out[o+1]=(byte)(p>>8);out[o+2]=(byte)p;}}
      CC s=new CC(perm,nonce); int[] pm=new int[N]; for(int i=0;i<N;i++)pm[i]=i;
      for(int i=N-1;i>=2;i--){int mm=i;long lim=4294967296L-(4294967296L%mm);int j;while(true){long v=s.u32();if(v<lim){j=1+(int)(v%mm);break;}}int t=pm[i];pm[i]=pm[j];pm[j]=t;}
      int[] inv=new int[N]; for(int i=0;i<N;i++)inv[pm[i]]=i;
      byte[] sealed=new byte[MAXW*MAXH*3+16];
      for(int r=0;r<IMG_ROWS;r++)for(int c=0;c<COLS;c++){int j=COLS+r*COLS+c;int from=inv[(int)((j*KINV)%N)];for(int ty=0;ty<8;ty++)System.arraycopy(out,from*SQB+ty*24,sealed,((r*8+ty)*MAXW+c*8)*3,24);}
      System.arraycopy(tag,0,sealed,sealed.length-16,16);
      byte[] aad=new byte[28]; System.arraycopy(salt,0,aad,0,16); System.arraycopy(nonce,0,aad,16,12);
      Cipher ci=Cipher.getInstance("ChaCha20-Poly1305"); ci.init(Cipher.DECRYPT_MODE,new SecretKeySpec(enc,"ChaCha20"),new IvParameterSpec(nonce)); ci.updateAAD(aad);
      byte[] padded=ci.doFinal(sealed); long len=((padded[0]&255L)<<24)|((padded[1]&255L)<<16)|((padded[2]&255L)<<8)|(padded[3]&255L);
      file=Arrays.copyOfRange(padded,4,4+(int)len); System.out.println("orientation k="+k+" rows="+hh+" len="+len); break; }
    byte[] want=Files.readAllBytes(Paths.get(dir+"square_file.bin"));
    System.out.println(Arrays.equals(file,want)?"[PASS] RG-Square decode matches Python":"[FAIL] RG-Square");
    // rotated variants: rotate the PNG 90/180 in memory and rerun is covered by the same index formulas for k=1..3
  }


  // ======== encoder mirror (same logic as RgCode.buildStream/render and RgSquare.encodeFile) ========
  static byte[] be32(long v){return new byte[]{(byte)(v>>>24),(byte)(v>>>16),(byte)(v>>>8),(byte)v};}
  static byte[] cat(byte[]... p){int n=0;for(byte[] x:p)n+=x.length;byte[] o=new byte[n];int k=0;for(byte[] x:p){System.arraycopy(x,0,o,k,x.length);k+=x.length;}return o;}
  static byte[] crcB(byte[] p){int c=crc16(p,0,p.length);return new byte[]{(byte)(c>>>8),(byte)c};}
  static byte[] deflate(byte[] d){Deflater f=new Deflater(9);f.setInput(d);f.finish();ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] buf=new byte[65536];while(!f.finished())o.write(buf,0,f.deflate(buf));f.end();return o.toByteArray();}
  static byte[] seal(boolean chacha,byte[] key,byte[] nonce,byte[] aad,byte[] plain)throws Exception{Cipher c;if(chacha){c=Cipher.getInstance("ChaCha20-Poly1305");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"ChaCha20"),new IvParameterSpec(nonce));}
    else{c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));}c.updateAAD(aad);return c.doFinal(plain);}
  static byte[] buildStream(byte[] data,String pw,boolean compress,boolean chacha)throws Exception{byte[] body=data;boolean def=false;if(compress){byte[] p=deflate(data);if(p.length<data.length){body=p;def=true;}}
    if(pw==null){byte[] head=cat(new byte[]{(byte)0xA5,(byte)(def?2:1)},be32(body.length));return cat(head,body,crcB(body));}
    SecureRandom r=new SecureRandom();byte[] salt=new byte[16],nonce=new byte[12];r.nextBytes(salt);r.nextBytes(nonce);int flags=(def?1:0)|(chacha?4:0);
    byte[] head=cat(new byte[]{(byte)0xA5,3,(byte)flags},be32(body.length+16),salt,nonce);byte[] sealed=seal(chacha,pbkdf2(pw,salt,200000,32),nonce,head,body);return cat(head,sealed,crcB(sealed));}
  static boolean modBlack(byte[] st,int w,int h,int r,int c){if(r==h-1||c==w-1)return true;if(r==0)return c%2==0;if(c==0)return r%2==0;if(r<2||c<2||r>=h-2||c>=w-2)return false;
    int i=(r-2)*(w-4)+(c-2);int by=i>>3;return by<st.length&&((st[by]>>(7-(i&7)))&1)==1;}
  static BufferedImage render(byte[] st,int w,int h,int px){int Q=4;int iw=(w+8)*px,ih=(h+8)*px;BufferedImage im=new BufferedImage(iw,ih,BufferedImage.TYPE_INT_RGB);
    for(int m=0;m<h+8;m++){int r=m-Q;for(int cm=0;cm<w+8;cm++){int c=cm-Q;boolean on=r>=0&&r<h&&c>=0&&c<w&&modBlack(st,w,h,r,c);int col=on?0:0xFFFFFF;
      for(int ty=0;ty<px;ty++)for(int tx=0;tx<px;tx++)im.setRGB(cm*px+tx,m*px+ty,col);}}return im;}
  static int[] grid(int shortSide,int a,int b,int px){int w=2*((shortSide/px-8)/2)+1;int num=(w+8)*b;int h=(2*num+a)/(2*a)-8;if(h%2==0)h++;return new int[]{w,h};}
  static BufferedImage squareEnc(byte[] data,String pw)throws Exception{
    int rowBytes=MAXW*3;int rows=(data.length+4+rowBytes-1)/rowBytes;byte[] raster=new byte[rows*rowBytes];System.arraycopy(be32(data.length),0,raster,0,4);System.arraycopy(data,0,raster,4,data.length);
    SecureRandom rnd=new SecureRandom();byte[] salt=new byte[16],nonce=new byte[12];rnd.nextBytes(salt);rnd.nextBytes(nonce);byte[] d=pbkdf2(pw,salt,200000,96);
    byte[] enc=Arrays.copyOfRange(d,0,32),hdr=Arrays.copyOfRange(d,32,64),pk=Arrays.copyOfRange(d,64,96);byte[] padded=new byte[MAXW*MAXH*3];System.arraycopy(raster,0,padded,0,raster.length);
    byte[] sealed=seal(true,enc,nonce,cat(salt,nonce),padded);int cl=sealed.length-16;byte[] sq=new byte[N*SQB];rnd.nextBytes(sq);
    for(int r=0;r<IMG_ROWS;r++)for(int c=0;c<COLS;c++)for(int ty=0;ty<8;ty++)System.arraycopy(sealed,((r*8+ty)*MAXW+c*8)*3,sq,(COLS+r*COLS+c)*SQB+ty*24,24);
    byte[] fields=cat(be32(MAXW),be32(rows),"SQv1".getBytes("US-ASCII"));CC m=new CC(hdr,nonce);System.arraycopy(salt,0,sq,0,16);System.arraycopy(nonce,0,sq,16,12);
    for(int i=0;i<12;i++)sq[28+i]=(byte)(fields[i]^m.nb());System.arraycopy(sealed,cl,sq,40,16);
    CC s=new CC(pk,nonce);int[] pm=new int[N];for(int i=0;i<N;i++)pm[i]=i;
    for(int i=N-1;i>=2;i--){int mm=i;long lim=4294967296L-(4294967296L%mm);int j;while(true){long v=s.u32();if(v<lim){j=1+(int)(v%mm);break;}}int t=pm[i];pm[i]=pm[j];pm[j]=t;}
    byte[] out=new byte[N*SQB];for(int i=0;i<N;i++){int src=(int)(((long)pm[i]*K)%N);System.arraycopy(sq,src*SQB,out,i*SQB,SQB);}
    BufferedImage im=new BufferedImage(768,1392,BufferedImage.TYPE_INT_RGB);
    for(int i=0;i<N;i++){int r=i/COLS,c=i%COLS;for(int ty=0;ty<8;ty++)for(int tx=0;tx<8;tx++){int o=i*SQB+(ty*8+tx)*3;im.setRGB(c*8+tx,r*8+ty,((out[o]&255)<<16)|((out[o+1]&255)<<8)|(out[o+2]&255));}}return im;}
  static void enc()throws Exception{
    new File("/tmp/mirror/out").mkdirs();byte[] text=Files.readAllBytes(Paths.get("/tmp/mirror/text.bin"));byte[] blob=Files.readAllBytes(Paths.get("/tmp/mirror/blob.bin"));
    int[] g=grid(1480,9,16,8);ImageIO.write(render(buildStream(text,"pässword-ü",true,true),g[0],g[1],8),"png",new File("/tmp/mirror/out/k_chacha_916.png"));
    g=grid(1480,1,1,2);ImageIO.write(render(buildStream(blob,"pw-aes",false,false),g[0],g[1],2),"png",new File("/tmp/mirror/out/k_aes_11.png"));
    g=grid(1480,3,4,2);ImageIO.write(render(buildStream(text,null,true,true),g[0],g[1],2),"png",new File("/tmp/mirror/out/k_deflate_34.png"));
    ImageIO.write(squareEnc(blob,"sq-pw"),"png",new File("/tmp/mirror/out/k_square.png"));System.out.println("encoded 4 images");}
  public static void main(String[] a)throws Exception{
    if(a.length>0){enc();return;}
    String dir="/mnt/user-data/outputs/rgcode-android/app/src/test/resources/vectors/"; Properties pr=new Properties(); pr.load(new InputStreamReader(new FileInputStream(dir+"crypto.properties"),"UTF-8"));
    int fail=0;
    byte[] salt=new byte[16];for(int i=0;i<16;i++)salt[i]=(byte)i;
    fail+=chk("crc16",crc16("123456789".getBytes(),0,9)==0x29B1);
    fail+=chk("pbkdf2 c=3",hex(pbkdf2("passwd","salt".getBytes(),3,40)).equals(pr.getProperty("pbkdf2_iter3_40")));
    fail+=chk("pbkdf2 200k utf8 96B",hex(pbkdf2("pässword-ü",salt,200000,96)).equals(pr.getProperty("pbkdf2_iter200k_96")));
    byte[] key=new byte[32],nonce=new byte[12];for(int i=0;i<32;i++)key[i]=(byte)i;for(int i=0;i<12;i++)nonce[i]=(byte)i;
    CC cc=new CC(key,nonce);byte[] ks=new byte[150];for(int i=0;i<150;i++)ks[i]=(byte)cc.nb();fail+=chk("chacha keystream",hex(ks).equals(pr.getProperty("chacha_first_150")));
    // shuffle
    CC s=new CC(key,nonce);int N=96*174;int[] perm=new int[N];for(int i=0;i<N;i++)perm[i]=i;
    for(int i=N-1;i>=2;i--){int m=i;long lim=4294967296L-(4294967296L%m);int j;while(true){long v=s.u32();if(v<lim){j=1+(int)(v%m);break;}}int t=perm[i];perm[i]=perm[j];perm[j]=t;}
    java.nio.ByteBuffer bb=java.nio.ByteBuffer.allocate(N*4).order(java.nio.ByteOrder.LITTLE_ENDIAN);for(int p:perm)bb.putInt(p);
    fail+=chk("shuffle sha256",hex(MessageDigest.getInstance("SHA-256").digest(bb.array())).equals(pr.getProperty("shuffle_sha256")));
    String[][] v={{"rg_raw_1x1_8px",null},{"rg_deflate_3x4",null},{"rg_chacha_9x16","pässword-ü"},{"rg_aes_rot180","pw-aes"},{"rg_chacha_rot90_1px","pw"}};
    for(String[] x:v){byte[] got=open(crop(toBits(ImageIO.read(new File(dir+x[0]+".png")))),x[1]);byte[] want=Files.readAllBytes(Paths.get(dir+x[0]+".bin"));fail+=chk("decode "+x[0],Arrays.equals(got,want));}
    System.out.println(fail==0?"ALL MIRROR CHECKS PASSED":fail+" FAILED");sq();}
  static int chk(String n,boolean ok){System.out.println((ok?"[PASS] ":"[FAIL] ")+n);return ok?0:1;}
}
