"""RG-Square: hide an RGB raster (or any file laid into one) as colour noise.

Order of operations (encode):
    raster (padded with zeros to 96 x 173 squares) -> ChaCha20-Poly1305 -> cut into 8x8 squares
    -> RG-Disperse v1 scatter -> header square at index 0 -> 768 x 1392 RGB PNG.
Because the squares hold CIPHERTEXT, the scatter is only a visual effect; confidentiality and
integrity come from the AEAD. (Permutation alone is not security: see the spec limitations.)

Header square (192 bytes = 8x8x3), never moved:
    0..15   salt                                    plain
    16..27  nonce (shared by the three sub-keys)   plain
    28..39  width(4) | height(4) | b"SQv1"          XOR ChaCha20 keystream (header key)
    40..55  Poly1305 tag of the whole padded raster plain
    56..191 random filler
Keys: PBKDF2-HMAC-SHA256(password, salt, 200_000, 96 bytes) = enc_key | hdr_key | perm_key.
"""
import os
import struct

import numpy as np
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from PIL import Image

SQ, COLS, ROWS = 8, 96, 174
N = COLS * ROWS                   # 16,704 squares
K, KINV = 10325, 6845             # dispersion multiplier and its inverse mod N
SQ_BYTES = SQ * SQ * 3            # 192
IMG_ROWS = ROWS - 1               # image occupies grid rows 1..173
MAX_W, MAX_H = COLS * SQ, IMG_ROWS * SQ     # 768 x 1384
MAGIC = b"SQv1"
PBKDF2_ITERATIONS = 200_000
IMAGE_SIZE = (COLS * SQ, ROWS * SQ)         # (768, 1392)


class SquareError(Exception):
    """Clean decode failure for RG-Square."""


class WrongPasswordError(SquareError):
    """Header magic did not verify: wrong password or not an RG-Square image."""


class TamperedError(SquareError):
    """Header verified but the AEAD tag failed: pixels were modified (e.g. recompressed)."""


assert (K * KINV) % N == 1 and np.gcd(K, N) == 1


def _keys(password: str, salt: bytes):
    kdf = PBKDF2HMAC(hashes.SHA256(), 96, salt, PBKDF2_ITERATIONS)
    d = kdf.derive(password.encode("utf-8"))
    return d[:32], d[32:64], d[64:]


def _keystream(key: bytes, nonce: bytes):
    """Endless ChaCha20 keystream generator (RFC 8439 block counter starts at 0)."""
    enc = Cipher(algorithms.ChaCha20(key, b"\0\0\0\0" + nonce), mode=None).encryptor()
    while True:
        yield enc.update(bytes(4096))


def _shuffle(perm_key: bytes, nonce: bytes) -> np.ndarray:
    """Fisher-Yates over 1..N-1 with rejection sampling on 32-bit keystream words."""
    stream, buf, pos = _keystream(perm_key, nonce), b"", 0

    def u32() -> int:
        nonlocal buf, pos
        if pos + 4 > len(buf):
            buf, pos = buf[pos:] + next(stream), 0
        v = struct.unpack_from("<I", buf, pos)[0]
        pos += 4
        return v

    def below(m: int) -> int:                 # uniform in [0, m), no modulo bias
        limit = 2 ** 32 - (2 ** 32 % m)
        while True:
            v = u32()
            if v < limit:
                return v % m

    perm = np.arange(N, dtype=np.int64)       # perm[0] stays 0
    for i in range(N - 1, 1, -1):             # indices 1..N-1
        j = 1 + below(i)                      # j in [1, i]
        perm[i], perm[j] = perm[j], perm[i]
    return perm


def _scatter_map(perm: np.ndarray) -> np.ndarray:
    """src[i] = (shuffle[i] * K) mod N : output position i takes square src[i]."""
    return (perm * K) % N


def encode(raster: np.ndarray, password: str) -> Image.Image:
    """raster: uint8 array (h, w, 3) with w <= 768, h <= 1384. Returns a 768x1392 RGB image."""
    h, w, _ = raster.shape
    if not (0 < w <= MAX_W and 0 < h <= MAX_H) or raster.dtype != np.uint8:
        raise SquareError(f"raster must be uint8 and at most {MAX_W}x{MAX_H}")
    salt, nonce = os.urandom(16), os.urandom(12)
    enc_key, hdr_key, perm_key = _keys(password, salt)
    padded = np.zeros((MAX_H, MAX_W, 3), np.uint8)
    padded[:h, :w] = raster
    sealed = ChaCha20Poly1305(enc_key).encrypt(nonce, padded.tobytes(), salt + nonce)
    cipher, tag = sealed[:-16], sealed[-16:]
    tiles = np.frombuffer(cipher, np.uint8).reshape(IMG_ROWS, SQ, COLS, SQ, 3)
    tiles = tiles.transpose(0, 2, 1, 3, 4).reshape(IMG_ROWS * COLS, SQ_BYTES)

    squares = np.frombuffer(os.urandom(N * SQ_BYTES), np.uint8).reshape(N, SQ_BYTES).copy()
    squares[COLS:] = tiles                    # image squares start at grid row 1
    fields = struct.pack(">II", w, h) + MAGIC
    mask = next(_keystream(hdr_key, nonce))[:12]
    squares[0, :16], squares[0, 16:28] = np.frombuffer(salt, np.uint8), np.frombuffer(nonce, np.uint8)
    squares[0, 28:40] = np.frombuffer(bytes(a ^ b for a, b in zip(fields, mask)), np.uint8)
    squares[0, 40:56] = np.frombuffer(tag, np.uint8)

    src = _scatter_map(_shuffle(perm_key, nonce))
    out = squares[src]                        # out[i] = squares[(shuffle[i]*K) mod N]; out[0] = squares[0]
    pix = out.reshape(ROWS, COLS, SQ, SQ, 3).transpose(0, 2, 1, 3, 4).reshape(ROWS * SQ, COLS * SQ, 3)
    return Image.fromarray(pix, "RGB")


def _try_header(pix: np.ndarray, password: str):
    """Return (w, h, keys, nonce, tag) if the header square verifies for this orientation."""
    head = pix[:SQ, :SQ].reshape(-1)
    salt, nonce, masked, tag = (bytes(head[:16]), bytes(head[16:28]),
                                bytes(head[28:40]), bytes(head[40:56]))
    enc_key, hdr_key, perm_key = _keys(password, salt)
    fields = bytes(a ^ b for a, b in zip(masked, next(_keystream(hdr_key, nonce))[:12]))
    if fields[8:] != MAGIC:
        return None
    w, h = struct.unpack(">II", fields[:8])
    if not (0 < w <= MAX_W and 0 < h <= MAX_H):
        return None
    return w, h, enc_key, perm_key, salt, nonce, tag


def decode(image: Image.Image, password: str) -> np.ndarray:
    """Return the original (h, w, 3) uint8 raster. Tries 0/90/180/270 degrees."""
    rgb = np.asarray(image.convert("RGB"))
    for k in range(4):
        pix = np.rot90(rgb, k)
        if pix.shape[:2] != IMAGE_SIZE[::-1]:
            continue                          # a 90/270 turn of a correct image changes the dimensions
        found = _try_header(pix, password)
        if found is None:
            continue
        w, h, enc_key, perm_key, salt, nonce, tag = found
        out = np.ascontiguousarray(pix).reshape(ROWS, SQ, COLS, SQ, 3)
        out = out.transpose(0, 2, 1, 3, 4).reshape(N, SQ_BYTES)
        inv = np.empty(N, np.int64)
        perm = _shuffle(perm_key, nonce)
        inv[perm] = np.arange(N)              # inv[shuffle[i]] = i
        m = (np.arange(N, dtype=np.int64) * KINV) % N     # squares[j] = out[ inv[(j*KINV) mod N] ]
        squares = out[inv[m]]
        tiles = squares[COLS:].reshape(IMG_ROWS, COLS, SQ, SQ, 3).transpose(0, 2, 1, 3, 4)
        try:
            plain = ChaCha20Poly1305(enc_key).decrypt(nonce, tiles.tobytes() + tag, salt + nonce)
        except InvalidTag:
            raise TamperedError("squares were modified: file damaged or recompressed") from None
        return np.frombuffer(plain, np.uint8).reshape(MAX_H, MAX_W, 3)[:h, :w].copy()
    raise WrongPasswordError("wrong password or not an RG-Square image")


def file_to_raster(data: bytes) -> np.ndarray:
    """Lay arbitrary bytes into a 768-wide RGB raster: 4-byte length prefix, zero padded."""
    body = struct.pack(">I", len(data)) + data
    if len(body) > MAX_W * MAX_H * 3:
        raise SquareError("file too large for one RG-Square image")
    rows = -(-len(body) // (MAX_W * 3))
    flat = np.zeros(rows * MAX_W * 3, np.uint8)
    flat[:len(body)] = np.frombuffer(body, np.uint8)
    return flat.reshape(rows, MAX_W, 3)


def raster_to_file(raster: np.ndarray) -> bytes:
    flat = raster.reshape(-1).tobytes()
    (n,) = struct.unpack_from(">I", flat)
    return flat[4:4 + n]
