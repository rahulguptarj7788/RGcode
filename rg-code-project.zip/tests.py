"""Round-trip tests and measurements. Run: python3 tests.py   (exit code 0 = all passed)."""
import io
import os
import sys
import time
import zlib

import numpy as np
from PIL import Image

import rgcode
import rgqr
import rgsquare

FAILS = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")
    if not ok:
        FAILS.append(name)


def raises(exc, fn) -> bool:
    try:
        fn()
    except exc:
        return True
    except Exception as e:                    # any other exception type is a failure
        print("   unexpected:", type(e).__name__, e)
    return False


def prose(n: int) -> bytes:
    """English prose from the GPL text shipped with the OS (identical on every run)."""
    with open("/usr/share/common-licenses/GPL-3", "rb") as f:
        return f.read()[:n]


def png_roundtrip(img: Image.Image) -> Image.Image:
    """Force a real PNG encode/decode so tests exercise the file format."""
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return Image.open(io.BytesIO(buf.getvalue()))


rng = np.random.default_rng(1234)

print("== 1. pinned capacity table (rule: QUIET=4, round half up, H forced odd) ==")
PINNED = {  # (shape, px): (W, H, capacity, image width, image height)
    ("9:16", 1): (1473, 2625, 481273, 1481, 2633), ("9:16", 2): (733, 1309, 118910, 1482, 2634),
    ("9:16", 4): (363, 653, 29115, 1484, 2644), ("9:16", 8): (177, 321, 6847, 1480, 2632),
    ("1:1", 1): (1473, 1473, 269737, 1481, 1481), ("3:4", 1): (1473, 1967, 360447, 1481, 1975),
    ("big", 1): (2153, 3835, 1029094, 2161, 3843),
}
for (shape, px), (W, H, cap, iw, ih) in PINNED.items():
    got = (*rgcode.grid_size(shape, px), rgcode.capacity(*rgcode.grid_size(shape, px)), *rgcode.image_size(shape, px))
    check(f"{shape} {px}px", got == (W, H, cap, iw, ih), f"grid {W}x{H} cap {cap} image {iw}x{ih}" if got == (W, H, cap, iw, ih) else f"got {got}")

print("\n== 2. every shape x grade, full capacity, byte-identical ==")
for shape in ("1:1", "3:4", "9:16"):
    for grade, px in rgcode.GRADE_PX.items():
        w, h = rgcode.grid_size(shape, px)
        for pw in (None, "pässword-ü"):
            n = rgcode.capacity(w, h, pw is not None)
            data = rng.bytes(n)
            img = png_roundtrip(rgcode.encode(data, shape, px, pw, compress=False))
            check(f"{shape} grade{grade} {px}px {'enc' if pw else 'raw'} {n} B",
                  rgcode.decode(img, pw) == data and img.size == rgcode.image_size(shape, px))

print("\n== 3. compression ==")
text = prose(14947)
packed = zlib.compress(text, 9)
print(f"   GPL-3 text: {len(text)} B -> {len(packed)} B = {len(text) / len(packed):.2f}x (spec prose: 2.18x)")
for pw in (None, "pw"):
    for comp in (True, False):
        img = rgcode.encode(text, "9:16", None, pw, comp) if comp or pw else rgcode.encode(text, "9:16", 1, pw, comp)
        check(f"14,947 B text, password={bool(pw)}, compress={comp}", rgcode.decode(img, pw) == text)

print("\n== 3b. both AEAD ciphers (flag bit2) ==")
for cipher in ("chacha20poly1305", "aes-gcm"):
    data = rng.bytes(3000)
    im = png_roundtrip(rgcode.encode(data, "1:1", None, "pw", True, cipher))
    check(f"cipher {cipher}", rgcode.decode(im, "pw") == data)

print("\n== 4. wrong password / damage ==")
img = rgcode.encode(b"secret", "1:1", None, "right")
check("RG-Code wrong password", raises(rgcode.WrongPasswordError, lambda: rgcode.decode(img, "wrong")))
check("RG-Code missing password", raises(rgcode.WrongPasswordError, lambda: rgcode.decode(img, None)))
raw_img = rgcode.encode(b"x" * 500, "1:1", 8, None, False)
arr = np.array(raw_img.convert("L"))
ys, xs = np.nonzero(arr < 128)
arr[ys.min() + 5 * 8 + 4, xs.min() + 20 * 8 + 4] ^= 255      # flip one data module
check("RG-Code flipped module -> 'file damaged'", raises(rgcode.FileDamagedError, lambda: rgcode.decode(Image.fromarray(arr), None)))
check("RG-Code blank image", raises(rgcode.NotACodeError, lambda: rgcode.decode(Image.new("L", (300, 300), 255), None)))

print("\n== 5. rotation without being told anything ==")
for shape, px in (("1:1", 8), ("3:4", 4), ("9:16", 8), ("9:16", 1)):
    data = rng.bytes(300)
    base = rgcode.encode(data, shape, px, "pw")
    for deg in (0, 90, 180, 270):
        check(f"{shape} {px}px rotated {deg}", rgcode.decode(base.rotate(deg, expand=True), "pw") == data)

print("\n== 6. RG-Square ==")
photo = (np.linspace(0, 255, 768 * 1381 * 3).reshape(1381, 768, 3) + rng.integers(0, 40, (1381, 768, 3))).clip(0, 255).astype(np.uint8)
t = time.time()
sq = rgsquare.encode(photo, "hunter2")
print(f"   encode {time.time() - t:.2f}s, image {sq.size}, squares {rgsquare.N}")
sq = png_roundtrip(sq)
t = time.time()
back = rgsquare.decode(sq, "hunter2")
print(f"   decode {time.time() - t:.2f}s")
check("768x1381 photo byte-identical", back.shape == photo.shape and np.array_equal(back, photo))
check("RG-Square wrong password", raises(rgsquare.WrongPasswordError, lambda: rgsquare.decode(sq, "nope")))
for deg in (90, 180, 270):
    check(f"RG-Square rotated {deg}", np.array_equal(rgsquare.decode(sq.rotate(deg, expand=True), "hunter2"), photo))
bad = np.array(sq)
bad[500, 300, 0] ^= 1
check("RG-Square one flipped bit -> clean error", raises(rgsquare.TamperedError, lambda: rgsquare.decode(Image.fromarray(bad), "hunter2")))
blob = rng.bytes(200_000)
check("RG-Square arbitrary file", rgsquare.raster_to_file(rgsquare.decode(rgsquare.encode(rgsquare.file_to_raster(blob), "pw"), "pw")) == blob)
flat = np.array(sq).reshape(-1, 3)
print(f"   ciphertext squares: mean byte {flat.mean():.1f} (ideal 127.5), distinct values {len(np.unique(flat))}")

print("\n== 7. sharing robustness (measured; RG-Code, full 9:16 grid, unencrypted random data) ==")
cols = [("jpg80", ("jpeg", 80)), ("jpg50", ("jpeg", 50)), ("jpg30", ("jpeg", 30)),
        ("rs75", ("resize", .75)), ("rs60", ("resize", .6)), ("rs50", ("resize", .5)), ("rs33", ("resize", .33))]
print("   grade  " + "  ".join(f"{c:>5}" for c, _ in cols))
for px in (1, 2, 4, 8):
    w, h = rgcode.grid_size("9:16", px)
    data = rng.bytes(rgcode.capacity(w, h))
    base = rgcode.encode(data, "9:16", px, None, False).convert("L")
    row = []
    for _, (kind, v) in cols:
        if kind == "jpeg":
            buf = io.BytesIO()
            base.save(buf, "JPEG", quality=v)
            im = Image.open(io.BytesIO(buf.getvalue()))
        else:
            im = base.resize((round(base.width * v), round(base.height * v)), Image.BICUBIC)
        try:
            row.append("OK" if rgcode.decode(im, None) == data else "FAIL")
        except rgcode.RGCodeError:
            row.append("FAIL")
    print(f"   {px} px   " + "  ".join(f"{r:>5}" for r in row))

print("\n== 8. standard-QR tier (independent OpenCV decoder) ==")
for n in (50, 1000, 2953):
    txt = ("The quick brown fox. " * 200)[:n].encode()
    im = png_roundtrip(rgqr.encode(txt))
    check(f"plain text {n} B -> real QR", rgqr.decode(im) == txt, f"image {im.size}")
check("2,954 B text refused", raises(rgcode.CapacityError, lambda: rgqr.encode(b"a" * 2954)))
blob = rng.bytes(1500)
check("binary 1500 B + password", rgqr.decode(png_roundtrip(rgqr.encode(blob, "pw")), "pw") == blob)
check("QR wrong password", raises(rgcode.WrongPasswordError, lambda: rgqr.decode(rgqr.encode(blob, "pw"), "bad")))
check("auto: 2000 B random binary + password fits QR tier", rgqr.encode(rng.bytes(2000), "pw").size[0] > 0)
check("auto: 2300 B random binary + password does NOT fit (base64 + header)", raises(rgcode.CapacityError, lambda: rgqr.encode(rng.bytes(2300), "pw")))

for n, want in ((2000, "QR 1:1"), (30000, "RG 1:1"), (300000, "RG 3:4 or 9:16")):
    data = rng.bytes(n)
    im = rgqr.encode_cascade(data, "pw")
    ok = rgqr.decode(im, "pw") == data if want == "QR 1:1" else rgcode.decode(im, "pw") == data
    check(f"cascade {n} B -> {want}", ok, f"image {im.size}")

print("\nRESULT:", "ALL PASSED" if not FAILS else f"{len(FAILS)} FAILED: {FAILS}")
sys.exit(1 if FAILS else 0)
