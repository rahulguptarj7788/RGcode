# RG CODE — format specification, version 1

Status: written from the Python reference (`rgcode.py`, `rgsquare.py`, `rgqr.py`) and the Kotlin core under
`rgcode-android/app/src/main/java/com/rgcode/app/core/`. A second engineer should be able to write a compatible
decoder from this document alone. Section 9 says exactly what has and has not been verified.

## 0. Conventions

- **Byte order** is big-endian unless a field says otherwise. **Bit order** inside a byte is most-significant bit first.
- **Round half up** means `floor(x + 1/2)`; all geometry is integer arithmetic.
- **Units.** KiB = 1,024 B, MiB = 1,048,576 B (binary). Plain "B" is bytes. Nothing in this document uses decimal MB.
- **Black pixel** = grayscale luminance < 128, with luminance `(299 R + 587 G + 114 B) / 1000`; transparent pixels are
  composited over white first. Black is drawn as `#000000`, white as `#FFFFFF`.
- **Image files are lossless PNG only.** A reader must be given the original pixels: no resampling, no colour conversion.

## 1. Shared primitives

| Primitive | Definition |
|---|---|
| Password | Unicode string encoded as UTF-8. **No normalisation** (no NFC/NFKC) is applied. Empty is not allowed; the app requires at least 8 characters. |
| KDF | PBKDF2-HMAC-SHA256 (RFC 8018), 200,000 iterations, 16-byte random salt stored in the code. Output length 32 B (RG-Code) or 96 B (RG-Square). |
| AEAD | ChaCha20-Poly1305 (RFC 8439) or AES-256-GCM, 12-byte nonce, 16-byte tag, output = ciphertext ‖ tag. |
| CRC-16 | CRC-CCITT: polynomial 0x1021, initial value 0xFFFF, no reflection, no final XOR. Equals Python `binascii.crc_hqx(data, 0xFFFF)`. Check value: CRC of ASCII `123456789` = **0x29B1**. |
| Deflate | zlib stream (RFC 1950), level 9. Applied only when the result is strictly smaller than the input. |
| ChaCha20 keystream | RFC 8439 block function, block counter starts at 0, 12-byte nonce. (Python: 16-byte nonce = `00 00 00 00` ‖ nonce.) |

Compress before encrypting, never after: ciphertext does not compress.

## 2. RG-Code (systems B–F): rectangular black-and-white code

### 2.1 Layout of the module grid

A grid of `W × H` modules, **W and H both odd**, drawn with a **4-module white quiet zone on every side**.
The PNG is `(W + 8) × px` wide and `(H + 8) × px` high, where `px` is the pixel size of one module.

| Element | Rule (row `r`, column `c`, 0-based, from the top-left of the grid) |
|---|---|
| Bottom frame | row `H-1`: all black |
| Right frame | column `W-1`: all black |
| Top clock track | row 0: black iff `c` is even |
| Left clock track | column 0: black iff `r` is even |
| Ring 1 | row 1, column 1, row `H-2`, column `W-2`: white (except where a frame above says black) |
| Data area | rows `2 .. H-3`, columns `2 .. W-3`: `(H-4) × (W-4)` bits, row-major |

Priority when rules overlap: bottom frame and right frame first, then the top clock track, then the left clock track,
then the data area, then white. There is **no orientation marker**: the solid frame sits at the bottom and right, so
the orientation is the one in which the structure test of 2.5 passes.

### 2.2 Grid size rule (pinned; one rule, one table)

```
QUIET = 4
W = 2 * floor( (short_side // px - 2*QUIET) / 2 ) + 1          # the odd integer nearest to short_side/px - 8, ties up
H = round_half_up( (W + 2*QUIET) * b / a ) - 2*QUIET ;  if H is even: H += 1
```

| Shape | short side `short_side` | `a : b` |
|---|---|---|
| 1:1 | 1480 | 1 : 1 |
| 3:4 | 1480 | 3 : 4 |
| 9:16 | 1480 | 9 : 16 |
| 4K canvas | 2160 | 9 : 16 |
| 8K canvas (opt-in) | 4320 | 9 : 16 |

Grades: 1 = 1 px, 2 = 2 px, 3 = 4 px, 4 = **8 px**, 5 = 1 px on the 4K or 8K canvas. "Auto" uses the largest `px`
in {8, 4, 2, 1} that fits the data.

Pinned results. **Image sizes are the real PNG sizes, not the nominal canvas labels** (for example 1 px is 1481 wide,
not 1480, because W must be odd and the quiet zone is exactly 4 modules):

| Shape | Grade | Square | W × H (modules) | Image size (px) | Capacity, no password | Capacity, password |
|---|:-:|:-:|---|---|---:|---:|
| 1:1 | 4 | 8 px | 177 × 177 | 1480 × 1480 | 3,733 B | 3,688 B |
| 1:1 | 3 | 4 px | 363 × 363 | 1484 × 1484 | 16,102 B | 16,057 B |
| 1:1 | 2 | 2 px | 733 × 733 | 1482 × 1482 | 66,422 B | 66,377 B |
| 1:1 | 1 | 1 px | 1473 × 1473 | 1481 × 1481 | 269,737 B | 269,692 B |
| 3:4 | 4 | 8 px | 177 × 239 | 1480 × 1976 | 5,073 B | 5,028 B |
| 3:4 | 3 | 4 px | 363 × 487 | 1484 × 1980 | 21,666 B | 21,621 B |
| 3:4 | 2 | 2 px | 733 × 981 | 1482 × 1978 | 89,021 B | 88,976 B |
| 3:4 | 1 | 1 px | 1473 × 1967 | 1481 × 1975 | 360,447 B | 360,402 B |
| 9:16 | 4 | 8 px | 177 × 321 | 1480 × 2632 | 6,847 B | 6,802 B |
| 9:16 | 3 | 4 px | 363 × 653 | 1484 × 2644 | 29,115 B | 29,070 B |
| 9:16 | 2 | 2 px | 733 × 1309 | 1482 × 2634 | 118,910 B | 118,865 B |
| 9:16 | 1 | 1 px | 1473 × 2625 | 1481 × 2633 | 481,273 B | 481,228 B |
| 4K canvas (9:16) | 5 | 1 px | 2153 × 3835 | 2161 × 3843 | 1,029,094 B | 1,029,049 B |
| 8K canvas (9:16) | 5 | 1 px | 4313 × 7675 | 4321 × 7683 | 4,131,784 B | 4,131,739 B |

Capacity (bytes of data after optional deflate) = `floor((H-4)*(W-4) / 8) - overhead`, with overhead 8 B (no password)
or 53 B (password: 37 B header + CRC, plus the 16 B tag). For no password this equals `((H-4)*(W-4) - 64) // 8`.

Memory: an ARGB_8888 bitmap costs 4 B per pixel. 4K = 2161 × 3843 = **31.7 MiB**; 8K = 4321 × 7683 = **126.6 MiB**.

### 2.3 Stored stream

Written into the data area from the first data bit; the unused tail is zero bits.

| Field | Size | Notes |
|---|---|---|
| magic | 1 | `0xA5` |
| version | 1 | `1` raw, `2` deflate, `3` encrypted |
| flags | 1 | **only when version = 3.** bit0 = payload was deflated before encryption; bit1 = reserved (0; Argon2id later); **bit2 = cipher: 1 ChaCha20-Poly1305, 0 AES-256-GCM**; bits 3–7 reserved, must be 0 |
| length | 4 | length of the stored payload (for version 3: ciphertext length + 16) |
| salt | 16 | version 3 only |
| nonce | 12 | version 3 only |
| payload | `length` | raw bytes (v1), zlib stream (v2), ciphertext ‖ tag (v3) |
| CRC-16 | 2 | over the stored payload bytes only |

For version 3 the AEAD **associated data is every header byte before the payload** (magic through nonce, 35 bytes).
The key is `PBKDF2(password, salt, 200000, 32)`. Checks happen in this order and a failure stops the decode:
CRC → AEAD tag → inflate. A decoder never returns partial data.

### 2.4 Encoding

1. Optionally deflate; keep it only if smaller. 2. If a password is set, pick a random salt and nonce, encrypt with the
chosen AEAD. 3. Serialise the stream and CRC. 4. If `len(stream) * 8 > (H-4)*(W-4)`, fail with a capacity error.
5. Draw the grid and the quiet zone.

### 2.5 Decoding (nothing is told to the decoder: no size, no grade, no orientation)

1. Binarise (section 0). 2. Crop to the bounding box of all black pixels: `bw × bh`.
3. For `k = 0, 1, 2, 3` (the image rotated counter-clockwise by `90·k` degrees; a 90° turn swaps `bw` and `bh`):
   - `pitchX` = number of consecutive black pixels starting at the **right edge** on row `floor(bh/2)`, going left (minimum 1).
     `pitchY` = consecutive black pixels from the **bottom edge** upward on column `floor(bw/2)` (minimum 1).
     These are the thickness of the solid frame, i.e. one module.
   - `W = 2 * (black runs along row min(pitchY/2, bh-1)) - 1`; `H = 2 * (black runs along column min(pitchX/2, bw-1)) - 1`
     (integer halves). Reject this `k` if `W < 9`, `H < 9`, `|W*pitchX - bw| > W` or `|H*pitchY - bh| > H`.
   - Sample module `(r, c)` at pixel `x = floor((c + 0.5) * bw / W)`, `y = floor((r + 0.5) * bh / H)`.
   - **Structure test:** last row all black, last column all black, row 0 black exactly at even columns, column 0 black
     exactly at even rows. Otherwise try the next `k`.
   - Pack the data-area bits into bytes (MSB first, final partial byte zero-padded). Require `byte0 = 0xA5` and
     `version in {1,2,3}`; require `pos + length + 2 <= available bytes`. Otherwise try the next `k`.
4. The first `k` that passes is used. If none does: "no code found".
5. Open the stream as in 2.3.

Errors a reader must distinguish: **not a code**; **file damaged** (CRC mismatch, or an inflate error); **wrong password
or tampered** (tag failure, or a password is needed and none was given); **unsupported** (version 3 with reserved
flag bits set). A version byte outside 1–3 is currently treated as "not a code".

## 3. RG-Square (system G): colour squares for photos

### 3.1 Parameters

Square = 8 × 8 pixels × 3 bytes (R, G, B; row-major inside the square) = 192 B. Grid `COLS = 96`, `ROWS = 174`,
`N = 16,704` squares; square `i` is at row `i div 96`, column `i mod 96`. Image = **768 × 1392** RGB pixels.
Square 0 is the header and is never moved; squares 1..95 are random filler; the data occupies grid rows 1..173
(16,608 squares, 768 × 1384 px, 3,188,736 B).

### 3.2 Header square (192 B, never moved)

| Offset | Size | Content |
|---|---|---|
| 0 | 16 | salt (plain) |
| 16 | 12 | nonce (plain; used for all three sub-keys, which are distinct) |
| 28 | 12 | `width(4) ‖ height(4) ‖ "SQv1"`, XOR the first 12 bytes of the ChaCha20 keystream under `hdr_key` and the nonce |
| 40 | 16 | Poly1305 tag of the whole padded data raster |
| 56 | 136 | random |

Keys: `PBKDF2(password, salt, 200000, 96)` split as `enc_key (32) ‖ hdr_key (32) ‖ perm_key (32)`.

### 3.3 Payload

File mode (what the app uses): `raster = BE32(len(file)) ‖ file`, zero-padded to whole rows of `768 × 3` B; the header
stores `width = 768` and `height = rows`. Capacity = **3,188,732 B**. The raster is zero-padded to the full
3,188,736 B, sealed with ChaCha20-Poly1305 under `enc_key`, the nonce, and **AAD = salt ‖ nonce**, and the ciphertext
(without tag) is cut into the 16,608 data squares in row-major order. (The Python reference also supports a photo
raster narrower than 768; the Android app does not read those and reports "unsupported".)

### 3.4 RG-Disperse v1 scatter (cosmetic once the payload is encrypted)

`K = 10325`, `KINV = 6845`, and `K * KINV mod N = 1`, `gcd(K, N) = 1`. Let `u32()` read the next 4 bytes of the
ChaCha20 keystream under `perm_key` and the nonce as a little-endian unsigned integer. `below(m)` draws `u32()`
until `v < 2^32 - (2^32 mod m)` and returns `v mod m` (rejection sampling, no modulo bias; rejected draws consume stream).

```
perm = [0, 1, 2, ..., N-1]
for i from N-1 down to 2:   j = 1 + below(i);  swap perm[i], perm[j]          # index 0 stays fixed
out[i] = squares[ (perm[i] * K) mod N ]                                        # encode
squares[j] = out[ inverse_perm[ (j * KINV) mod N ] ]                           # decode
```

### 3.5 Decoding

Accept an image of 768 × 1392 or 1392 × 768. For each rotation whose dimensions are 768 × 1392: read square 0,
derive keys, unmask the header; if bytes 8..11 of the unmasked fields are not `SQv1` (or width/height are out of range),
try the next rotation. After the header verifies: read all squares, undo the scatter, reassemble the ciphertext, append
the tag, open with ChaCha20-Poly1305. Header mismatch ⇒ "wrong password or not an RG-Square image" (false-accept
chance 2^-32). Tag failure after a good header ⇒ "the squares were changed". A password is mandatory.

## 4. Standard-QR tier (system A)

A real ISO/IEC 18004 QR code, error-correction level L, byte mode, automatic version, 4-module quiet zone, integer
scale `max(1, 1480 // modules)` (a full version-40 code is 185 × 8 = 1480 px).

- **Plain text, no password:** UTF-8 stored as-is (so any phone shows it), up to **2,953 B**. Text that starts with
  `RGQ1:` is never stored this way.
- **Everything else:** `"RGQ1:" + Base64(stream)` (RFC 4648, standard alphabet, with padding), where `stream` is the
  RG-Code stream of 2.3 (versions 1–3, CRC included). Base64 length ≤ 2,953 − 5 ⇒ `stream ≤ 2,211 B`
  (`3 * floor(2948 / 4)`). The data limit is therefore **2,211 − 8 = 2,203 B** without a password and
  **2,211 − 53 = 2,158 B** with one, before compression.
- Encoders may differ (the Python reference uses OpenCV's encoder, the app uses ZXing's); a reader must accept both.
  Python also treats text containing NUL as plain; the app sends such text through `RGQ1:`. Both decode.
- The checksum situation differs: a plain-text QR has **no integrity data at all**.

## 5. Choosing the system (what the app does)

Systems: **A** standard QR; **B** RG-Code 1:1; **C** 3:4; **D** 9:16; **E** 4K canvas; **F** 8K canvas (opt-in);
**G** RG-Square. Text and files may use A–F; a photo uses G only.

Cascade, smallest first: A (if it fits) → B → C → D → E → F. In each RG-Code shape the grade is the largest `px` in
{8, 4, 2, 1} whose capacity (encrypted or not) is at least the stored size; E and F use 1 px. Settings can pin a
minimum shape and a fixed grade. If nothing fits the app shows "does not fit" with the capacity arithmetic; a colour
mode (24 bits per pixel) is **not implemented** (a future stream version would be needed).
The app warns before any grade other than 8 px (see section 6).

## 6. Measurements (real numbers from this project)

**Test run:** `python3 tests.py` → 75 checks, all passed (every shape × grade at full capacity, raw and encrypted,
both ciphers, four rotations, wrong password, one-bit damage, RG-Square photo, standard QR, cascade).

**Sharing robustness** — RG-Code, full 9:16 grid of random unencrypted data, decoded by this reference decoder.
JPEG by Pillow at the stated quality; resize by Pillow bicubic. (The client's earlier table used Lanczos and its own
sampler; it differs at 2 px rs60/rs50 and 4 px rs75. Both are real; this table is the one these tools produce.)

| Grade | JPEG q80 | q50 | q30 | resize 75% | 60% | 50% | 33% |
|---|---|---|---|---|---|---|---|
| 1 px | OK | OK | FAIL | FAIL | FAIL | FAIL | FAIL |
| 2 px | OK | OK | OK | FAIL | FAIL | OK | FAIL |
| 4 px | OK | OK | OK | OK | OK | OK | FAIL |
| 8 px | OK | OK | OK | OK | OK | OK | OK |

Conclusion: **8 px is the only grade that survived every test**, so it is the default for anything sent as a photo.
Files sent as files (Drive, email, WhatsApp "Document") arrive byte-exact at any grade.

**Compression (zlib level 9).** English prose: 2.18× on the client's sample, 2.73× on the GPL-3 text
(14,947 B → 5,482 B): "roughly 2.2× to 2.7× for English prose". Photos and video are already compressed (2 to 5 percent).
zstd and brotli were **not measured**: the `zstandard` and `brotli` Python packages are not installed in the sandbox, and
the sandbox has no network access to install them, so no ratio exists for them. Left as a future option (and the app deliberately ships no native compression library).

**Standard QR boundary — source of these figures.** The 2,953 B / 2,954 B boundary at version 40, level L, byte mode
was **measured with the reference encoder** (OpenCV 4.13 `QRCodeEncoder`; one dense encode takes about 13 s there):
2,953 B accepted, 2,954 B refused. **ISO/IEC 18004 itself has NOT been consulted.** Every other capacity figure below comes
from secondary web pages (section 11). None of this is an authoritative capacity table; do not quote it as the standard. Published version-40 byte maxima for L/M/Q/H:
2,953 / 2,331 / 1,663 / 1,273 (numeric 7,089 / 5,596 / 3,993 / 3,057; alphanumeric 4,296 / 3,391 / 2,420 / 1,852).
**Gap:** the full versions 1–40 table was not reproduced or measured (a dense encode takes seconds; 160 cells were out of reach).

## 7. Test vectors

Generated by `rgcode-android/make_vectors.py` into `app/src/test/resources/vectors/` (PNG + expected `.bin`):
`rg_raw_1x1_8px`, `rg_deflate_3x4`, `rg_chacha_9x16` (password `pässword-ü`), `rg_aes_rot180` (`pw-aes`),
`rg_chacha_rot90_1px` (`pw`), `qr_text`, `qr_encrypted` (`qr-pw`), `square_file` (`sq-pw`).

Known answers (also in `crypto.properties`):

- CRC-16 of `123456789` = `0x29B1`.
- PBKDF2-HMAC-SHA256, password `passwd`, salt `salt`, 3 iterations, 40 bytes =
  `92df5c4cd7d900ab0b42336ea617caa1d3440cb93b8e8fb03fe3b31781c723cca13b84b7cf91dd6c`
- ChaCha20 keystream, key = bytes 0..31, nonce = bytes 0..11, counter 0, first 64 bytes =
  `103af111c18b549d39248fb07d60c29a95d1db88d892f7b4af709a5fd47a9e4bd5ff9a658dd52c708bef1f0f622b3747040fa3551300b1f293150a88620d5fed`
- Shuffle under the same key and nonce: first 16 entries of `perm` =
  `0,8890,12277,10232,16346,4106,11921,565,16206,11217,11627,5480,14084,9940,9039,2530`; SHA-256 of `perm` as 16,704 little-endian int32 =
  `408a93813b9f43a8f8f5f71dafd246eecebeca5e165f85dc617cf4e2e5cf9996`
- PBKDF2, password `pässword-ü` (UTF-8), salt = bytes 0..15, 200,000 iterations, first 32 of 96 bytes =
  `1733b10b0517321832c9b4c3806ccd46d2413e1ad4306816a609daf611f2c285`

## 8. Security model and limitations (read before relying on this)

1. **What protects the content:** the AEAD. With a password, an attacker without it learns nothing about the file beyond
   its approximate size and that a code exists. **There is no recovery: forget the password and the file is gone.**
2. **Without a password nothing is protected.** Version 1 and 2 codes are readable by anyone with this document.
   The integrity data is a 16-bit CRC (plus zlib's 32-bit checksum for version 2).
3. **A code is visibly a code, not noise.** The clock tracks and frame identify an RG-Code on sight; the 768 × 1392
   colour image is recognisable by size. This is **not steganography and gives no deniability.** Size class, salt,
   nonce and format are public.
4. **The scatter is cosmetic.** Permutation alone is not security. Published work treats block-scrambling image
   encryption as vulnerable to *jigsaw-puzzle-solver* ciphertext-only attacks, because neighbouring blocks stay correlated;
   security arguments based only on key-space size against brute force are not enough
   (Chuman et al., IEICE, https://www-isys.sd.tmu.ac.jp/local/2018/IEICEjournal_01_chuman.pdf; Imaizumi and Kiya,
   https://www-isys.sd.tmu.ac.jp/local/2018/IEICEjournal_12_imaizumi.pdf). Adding block rotation, colour shuffling and
   pixel shuffling raises resistance, yet an attack on block-plus-pixel shuffling has also been proposed
   (https://arxiv.org/pdf/2211.02369), and small block counts have been studied separately (https://arxiv.org/abs/2207.08109).
   Here every square holds AEAD **ciphertext**, so squares carry no image correlation for a solver to use. That is a
   design argument; no solver was run against this format. An unencrypted scattered photo would be breakable and is not offered.
5. **Password strength is the limit.** 200,000 PBKDF2-SHA256 rounds slow guessing but do not stop a determined offline
   attack on a weak password; 8 characters is a floor, not a recommendation. Argon2id is the better KDF and is reserved
   (flags bit1) but not implemented because Android has no platform Argon2. Recent guidance for PBKDF2-SHA256 asks for more
   rounds than 200,000; I did not re-verify the current figure in this session.
6. **No Unicode normalisation.** The same visible password typed with a different composition can fail to open the code.
7. **No file name, no type.** The app guesses an extension from the content and saves `restored.<ext>`.
8. **Fragile to re-encoding.** A photo-share, screenshot, cloud re-compression or colour management can change pixels;
   the reader then reports damage or a wrong password. Only 8 px survived every test above, and those tests used one
   encoder pair, not real chat apps.
9. **Mirrored images are not handled** (only rotations).
10. **A standard QR carries up to 2,953 B of text but only about 2,200 B of protected or binary data**, and dense codes
    may not scan on every phone camera or detector (OpenCV's classic detector failed on a full version-40 code; its
    ArUco-based detector read it).
11. **Limits:** one code holds at most 3.94 MiB (8K canvas, opt-in), 0.98 MiB (4K canvas, default) or 3.04 MiB (RG-Square, photos). Larger files do not fit.
12. **Future formats:** colour mode is not designed beyond reserving higher version bytes; a reader today calls them
    "not a code".

## 9. Verification status — what is and is not known

**Verified:** Python reference (75 checks pass). A Java port of the Kotlin decoders, PBKDF2, ChaCha20 stream, shuffle,
CRC, rotations, encoders and RG-Square, run against Python-made PNGs and in reverse (Python decoding images made by the
ported encoders), all passed. Contrast ratios and resource names were computed and checked statically.

**Not verified:** the Kotlin source has **never been compiled**; `CoreVectorsTest`, `PureTest` and `BuilderTest` have
**never run**; the Compose UI has not been rendered; ZXing encode and decode are untested (no jar offline); MediaStore
saving, the Photo Picker, the API 28 permission flow, sharing, and PBKDF2 speed on a phone have not been tried on a
device; the icon, splash, lockup and font files have not been seen by the build.

## 10. Open questions

1. Store an optional file name and type inside the stream (needs a new version).
2. Add Argon2id (flag bit1) and raise PBKDF2 iterations for new codes.
3. Normalise passwords (NFC) before encoding.
4. Define the colour-mode (24 bits per pixel) stream version.
5. Measure zstd and brotli against deflate.
6. Produce the full QR capacity table 1–40 from the standard.
7. Test on real phones: chat apps, the Photo Picker's treatment of originals, memory on 8K, PBKDF2 time.

## 11. References (retrieved during research)

- QR capacity (version 40: 7,089 / 4,296 / 2,953): https://help.accusoft.com/ImageGear-Net/v25.0/Windows/HTML/QRcode.html
- QR version-40 byte maxima per error-correction level (2,953 / 2,331 / 1,663 / 1,273) and the numeric and alphanumeric rows: node-qrcode README capacity table, as served at https://cdn.jsdelivr.net/npm/@lotaber_wang/openclaw-dc-plugin@0.1.17/node_modules/qrcode/README.md (a secondary source; check against ISO/IEC 18004 before quoting)
- Android cryptography overview and algorithm tables: https://developer.android.com/privacy-and-security/cryptography
  (ChaCha20 API 28+ shown at https://developer.android.com/reference/javax/crypto/KeyGenerator.html;
  PBKDF2withHmacSHA256 API 26+ at https://developer.android.com/reference/kotlin/javax/crypto/SecretKeyFactory)
- Jigsaw-solver attacks on permutation-based image encryption: the four papers in section 8, plus
  https://www.ieice.org/ken/paper/20161209SbOI/eng/
- rMQR (ISO/IEC 23941), ZXing `RGBLuminanceSource` decoding, ML Kit `InputImage.fromBitmap`, `Bitmap.compress` PNG
  behaviour: found in the earlier research pass; their URLs were not kept, so re-check them before quoting.
