# RG CODE - UI conformance list

Compared with the design sheet image (read by its printed labels, not measured pixel by pixel). Where the written spec and the
sheet disagree the written spec wins; each such place is listed with its reason. Nothing here has been rendered on a device.

## 0. Shared by every screen (from `RgScaffold`, `RgAppBar`, `Components.kt`)

| Part | Tokens |
|---|---|
| Background | `RgVoid` #0D0817 |
| Title | `RgType.Title` = Bricolage Grotesque ExtraBold 24 sp, `RgText` #EFE9F7 |
| Subtitle | `RgType.Label` = Fragment Mono 12 sp, `RgTextDim` #A99BC4 |
| Content | 20 dp side padding, 12 dp gaps; primary actions pinned at the bottom (thumb zone), then the bottom nav |
| Tile (`RgTile`) | `RgSurface` fill, 16 dp radius, 40 dp icon box on `RgSurfaceHigh`, title `RgType.BodyStrong` (Plex Medium 16 sp, `RgText`), subtitle `RgType.Small` (Plex 14 sp, `RgTextDim`) |
| Buttons (`PrimaryButton`, `GoldButton`, `OutlineButton`) | 56 dp minimum height, 16 dp radius, label `RgType.Button` (Plex Bold 18.5 sp). Primary: `RgViolet` fill, `RgText` label. Gold: `RgGold` fill, `RgVoid` label. Outline: 1.5 dp `RgVioletBright` border and label |
| Field (`RgField`) | `RgSurfaceHigh` fill, border `RgTextFaint` (focused `RgVioletBright`, error `RgRose`), label `RgTextDim`, text `RgType.Body` (or `Mono`) |
| Badge (`RgBadge`) | `RgType.Label`, 10 dp radius, tinted fill: Verified `RgMint`, Warning `RgGold`, Error `RgRose`, Info `RgVioletBright` |
| Callout | `RgSurface` fill, 4 dp `RgGold` side bar, title `BodyStrong`, text `Small` in `RgTextDim` |
| Info row (`InfoRow`) | label `RgType.Label` in `RgTextDim`, value `RgType.Mono` (Fragment Mono 14 sp) in `RgText` |
| Chip (`RgChip`) | 48 × 48 dp minimum, `RgViolet` when selected, `RgSurfaceHigh` otherwise, `RgType.Mono` |
| Step row (`StepRow`) | `RgType.Body` + detail `RgType.Label`; tick `RgVioletBright`, **`RgMint` only for the read-back step** |
| Code preview (`CodePreview`) | `RgSurface` box, `RgSurfaceHigh` border, nearest-neighbour scaling for codes |
| Bottom nav | `RgSurface`, selected `RgVioletBright`, labels `RgType.Label`, 64 dp minimum |

Colour rules kept: mint = verified only, rose = errors only, gold = warnings and the one irreversible action,
`RgTextFaint` never used for text. Touch targets are at least 48 dp by construction (buttons 56, tiles 64, chips 48,
nav 64, toggles 64); **none has been measured on a device.**

## Deviations that apply to several screens

- **Gallery grid -> system Photo Picker.** The sheet draws a thumbnail grid inside the app. That needs the
  READ_MEDIA_IMAGES / READ_EXTERNAL_STORAGE permission, which the written spec forbids; the Photo Picker needs none.
- **Default cipher.** The sheet says AES-256-GCM everywhere. Approved change: ChaCha20-Poly1305 is the default, AES-256-GCM is read. **Sheet out of date.**
- **Units.** The sheet writes MB/KB for binary sizes (e.g. 3.94 MB). The app writes B, KiB, MiB. **Sheet out of date.**
- **Words.** "No camera needed" (First run) and "no camera, no printing" (Pick) are not used: the copy rules say no camera anywhere, and "hide" / "offline" are never used.
- **Verification wording.** The sheet's "byte-identical" appears only where an original exists (after building). Opening a code shows the checks that actually ran.

## Screens (14 numbered by the client + the create-flow screens), in the order of the create flow where it applies

### 1 Home
- Route: `home`  - Composable: `HomeScreen` in `ui/screens/HomeScreens.kt`
- Elements: Brand title RG CODE; subtitle; 'Recent' list (name, shape/grade, date); two large actions: Make a code (violet), Open a code (gold); bottom nav.
- Components used (scanned from the source): `GoldButton`, `PrimaryButton`, `RgBottomNav`, `RgScaffold`, `RgTile`, `SectionLabel`
- Colour tokens named directly in the screen: `RgTextDim`
- Type styles named directly in the screen: `RgType.Small`
- Badges: none
- Deviations from the sheet:
  - Actions are pinned at the bottom, 72 dp tall, with no sub-text line (sheet: top tiles with 'Image, document, anything' / 'Pick from the gallery'). Reason: written spec puts primary actions in the thumb zone.
  - 'Open a code' is a gold fill (sheet: outlined). Reason: written spec says gold.
  - Recent rows show only codes the user saved from the app; opening one uses its saved URI.

### 2 What goes in (create step 2)
- Route: `create`  - Composable: `CreateScreen` in `ui/screens/HomeScreens.kt`
- Elements: Three tiles: Paste text, Photo from gallery, Any file; one explanatory line; bottom nav.
- Components used (scanned from the source): `RgBottomNav`, `RgScaffold`, `RgTile`
- Colour tokens named directly in the screen: `RgTextDim`
- Type styles named directly in the screen: `RgType.Small`
- Badges: none
- Deviations from the sheet:
  - Sub-text of the tiles differs from the sheet ('Write it, or paste it' etc.). Cosmetic.
  - The sheet's explanatory box is plain text here (no gold box): it is information, not a warning.

### 3 Paste box (create step 3)
- Route: `paste`  - Composable: `PasteScreen` in `ui/screens/HomeScreens.kt`
- Elements: Large multi-line field; live character count; 'compresses to' with ratio; Paste from clipboard; Continue.
- Components used (scanned from the source): `InfoRow`, `OutlineButton`, `PrimaryButton`, `RgField`, `RgScaffold`
- Colour tokens named directly in the screen: none (all colour comes from the shared components)
- Type styles named directly in the screen: none (shared components set them)
- Badges: none
- Deviations from the sheet:
  - None known beyond cosmetics. The ratio is computed live from deflate level 9.

### 4 Pick from gallery / any file
- Route: `pick/photo, pick/file`  - Composable: `PickScreen` in `ui/screens/HomeScreens.kt`
- Elements: Choose button, Browse files (photos), file tile (name, size, type), 'fits comfortably' badge, capacity and data rows, 'the file stays on this phone' box, Continue, Choose another.
- Components used (scanned from the source): `Callout`, `InfoRow`, `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgScaffold`, `RgTile`
- Colour tokens named directly in the screen: `RgTextDim`
- Type styles named directly in the screen: `RgType.Small`
- Badges: Verified, Warning
- Deviations from the sheet:
  - Photo Picker instead of the thumbnail grid (see above). No thumbnail of the chosen photo is shown. **Gap, easy to add.**
  - Badge is mint 'fits comfortably' (written spec: fit shown as a green badge) although mint is otherwise 'verified'; it is a computed fit check.
  - The sheet's 'Gallery only - no camera, no printing' subtitle is replaced by 'From your gallery or files'.

### 5 The app decides (create step 4)
- Route: `decide`  - Composable: `DecideScreen` in `ui/screens/FlowScreens.kt`
- Elements: System tile (letter, name, shape, grade); rows shape, grade, squares, capacity, your data; fit badge; chips of the applicable systems; hint line; Change system; photo-share warning when the grade is not 8 px; Continue.
- Components used (scanned from the source): `Callout`, `InfoRow`, `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgChip`, `RgScaffold`, `RgTile`, `SectionLabel`
- Colour tokens named directly in the screen: `RgTextDim`
- Type styles named directly in the screen: `RgType.Body`, `RgType.Label`
- Badges: Verified, Warning
- Deviations from the sheet:
  - Chips show only applicable systems: text and files A-E (F only when the 8K canvas is enabled), photos G only. The sheet shows A-F with G greyed. Reason: written spec says only the applicable ones.
  - Chips are tappable only after 'Change system'; disabled when that system cannot hold the data.
  - Squares and shape rows show '-' for the standard QR.

### 6 Password (create step 5)
- Route: `password`  - Composable: `PasswordScreen` in `ui/screens/FlowScreens.kt`
- Elements: 'Lock with password' switch; password and confirm fields; strength meter; compress toggle; when off the badge 'unprotected - anyone with this code can read it'; when on the gold box 'forget the password...'; gold 'Encrypt and build the code' (violet 'Build the code' when unlocked).
- Components used (scanned from the source): `Callout`, `GoldButton`, `PrimaryButton`, `RgBadge`, `RgField`, `RgScaffold`, `StrengthMeter`, `ToggleRow`
- Colour tokens named directly in the screen: none (all colour comes from the shared components)
- Type styles named directly in the screen: none (shared components set them)
- Badges: Warning
- Deviations from the sheet:
  - 'Lock with password' switch is new (written spec); the sheet has none. Photos force it on.
  - Subtitle reads ChaCha20-Poly1305 (sheet: AES-256-GCM). **Sheet out of date.**
  - Strength meter is gold when weak and violet otherwise, never mint (sheet: mint 'strength: good'). Reason: mint is reserved for verified states.
  - Minimum password length 8 enforced (approved).

### 7 Building (create step 6)
- Route: `building`  - Composable: `BuildingScreen` in `ui/screens/FlowScreens.kt`
- Elements: Progress bar; six steps (compress, encrypt, system chosen, drawing, writing PNG, verifying by reading it back); empty preview box; Cancel.
- Components used (scanned from the source): `CodePreview`, `OutlineButton`, `RgProgressBar`, `RgScaffold`, `StepRow`
- Colour tokens named directly in the screen: none (all colour comes from the shared components)
- Type styles named directly in the screen: none (shared components set them)
- Badges: none
- Deviations from the sheet:
  - Extra 'verifying' step and no 'pattern: RG-Disperse v1 / K=10325' detail rows (the sheet shows them). The scatter is cosmetic, so it is not advertised.
  - Subtitle is 'It is read back before you see it' (sheet shows shape/grade/canvas). Reason: those are on the previous screen.

### 8 Code ready (create step 7)
- Route: `ready`  - Composable: `ReadyScreen` in `ui/screens/FlowScreens.kt`
- Elements: Preview; mint verification badge; 'saved to...' badge after saving; unprotected warning when no password; rows system, grade, size, protection, compression; gold-bar 'Send it as a file, not a photo'; photo-share warning for non-8 px; Save, Share as file, Done.
- Components used (scanned from the source): `Callout`, `CodePreview`, `InfoRow`, `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgScaffold`
- Colour tokens named directly in the screen: none (all colour comes from the shared components)
- Type styles named directly in the screen: none (shared components set them)
- Badges: Verified, Warning
- Deviations from the sheet:
  - Button says 'Save to Pictures/RG CODE' (sheet: 'Save to Downloads'). Approved change. **Sheet out of date.**
  - Badge text is 'magic + CRC verified - byte-identical' (RG-Code), 'authentication tag verified - byte-identical' (colour squares), 'QR read back - byte-identical' (standard QR), from a real read-back.
  - **Gap:** for the standard QR (sheet screen 12, 'Small file = real QR') the dedicated wording 'any phone can read this' and 'bigger files switch to RG CODE's own 3:4 or 9:16 format' is NOT implemented; the generic Ready screen is used.

### 9 Open a code
- Route: `open`  - Composable: `OpenScreen` in `ui/screens/OpenScreens.kt`
- Elements: Pick from gallery (gold), Browse files, log of what was read, progress, password field only when the code needs one, recents, bottom nav.
- Components used (scanned from the source): `GoldButton`, `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgBottomNav`, `RgField`, `RgScaffold`, `RgTile`, `SectionLabel`, `StepRow`
- Colour tokens named directly in the screen: `RgTextDim`
- Type styles named directly in the screen: `RgType.Body`
- Badges: Info
- Deviations from the sheet:
  - No gallery strip (Photo Picker). Log lines differ from the sheet's wording but report the same facts (image read, grid found, orientation, header).
  - The sheet's 'No size or grade input needed' line is the idle text.

### 10 Restored
- Route: `restored`  - Composable: `RestoredScreen` in `ui/screens/OpenScreens.kt`
- Elements: Preview (images) or file tile; mint badge listing the checks that ran; rows system, protection, compression, size, guessed type; Save original; Open another code.
- Components used (scanned from the source): `CodePreview`, `InfoRow`, `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgScaffold`, `RgTile`
- Colour tokens named directly in the screen: `RgTextDim`
- Type styles named directly in the screen: `RgType.Small`
- Badges: Verified
- Deviations from the sheet:
  - Badge says e.g. 'CRC-16 OK - zlib checksum OK - authentication tag OK', not 'byte-identical - CRC OK'. Reason: nothing to compare against when opening.
  - 'Open in gallery' is replaced by 'Open another code'.
  - A note says the file name is not stored (saved as restored.<type>).

### 11 Error
- Route: `error`  - Composable: `ErrorScreen` in `ui/screens/OpenScreens.kt`
- Elements: Rose badge with the title; 'What happened' tile with the real reason; 'Was the image re-saved?' hint tile; Try another password (when possible); Pick a different file / Back to start.
- Components used (scanned from the source): `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgScaffold`, `RgTile`
- Colour tokens named directly in the screen: `RgRose`
- Type styles named directly in the screen: none (shared components set them)
- Badges: Error
- Deviations from the sheet:
  - The sheet's separate red chip 'magic 0xA5 not found' is not shown; the real reason text carries that information.
  - Subtitle 'Nothing was changed on your phone' kept.

### 12 Settings
- Route: `settings`  - Composable: `SettingsScreen` in `ui/screens/InfoScreens.kt`
- Elements: Default shape chips; default grade chips; canvas 4K/8K chips with an 8K warning; compress toggle; About tile; version and default cipher; bottom nav.
- Components used (scanned from the source): `Callout`, `InfoRow`, `RgBottomNav`, `RgChip`, `RgScaffold`, `RgTile`, `SectionLabel`, `ToggleRow`
- Colour tokens named directly in the screen: `RgTextDim`
- Type styles named directly in the screen: `RgType.Small`
- Badges: none
- Deviations from the sheet:
  - Canvas offers 4K and 8K (sheet: 'Auto - up to 2160 x 3840'). Written spec: 4K default, 8K opt-in.
  - Grade help says Auto = the sturdiest grade that fits (8 px first). The sheet's 'Auto - 1 px on Drive, 8 px for photos' is **out of date**: the measured table shows 1 px fails photo-sharing.

### 13 About and limits
- Route: `about`  - Composable: `AboutScreen` in `ui/screens/InfoScreens.kt`
- Elements: Logo lockup (rg_code_logo_lockup); tiles: lossless PNG only, no recovery, encryption, grade matters, colour squares, file names not stored, standard QR; font licence line; Close.
- Components used (scanned from the source): `PrimaryButton`, `RgScaffold`, `RgTile`
- Colour tokens named directly in the screen: `RgTextDim`
- Type styles named directly in the screen: `RgType.Label`
- Badges: none
- Deviations from the sheet:
  - The encryption tile names ChaCha20-Poly1305 default / AES-256-GCM also read. **Sheet out of date.**
  - The sheet's 'format: RG-Code v3 - RG-Square v1' row is not shown. **Gap.**
  - Three extra tiles (colour squares, file names, standard QR) tell the limits more fully.

### 14a Text result
- Route: `text`  - Composable: `TextResultScreen (qr = false)` in `ui/screens/OpenScreens.kt`
- Elements: Selectable text box; verification badge; rows characters, bytes, system; Copy text, Save as .txt, Open another code.
- Components used (scanned from the source): `Callout`, `InfoRow`, `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgScaffold`
- Colour tokens named directly in the screen: `RgSurface`, `RgText`
- Type styles named directly in the screen: `RgType.Mono`
- Badges: Info, Verified
- Deviations from the sheet:
  - Shows a 'system' row instead of the sheet's 'shape' row. Cosmetic.

### 14b Standard QR result
- Route: `qr`  - Composable: `TextResultScreen (qr = true)` in `ui/screens/OpenScreens.kt`
- Elements: Same layout as the text result; Info (violet) badge 'plain QR text - the format carries no checksum'; link warning box when the text is a web address.
- Components used (scanned from the source): `Callout`, `InfoRow`, `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgScaffold`
- Colour tokens named directly in the screen: `RgSurface`, `RgText`
- Type styles named directly in the screen: `RgType.Mono`
- Badges: Info, Verified
- Deviations from the sheet:
  - **Interpretation gap:** the sheet's screen 12 is a creation result (see Code ready). The decode-side QR screen here is an addition not drawn on the sheet.
  - A plain QR is never labelled 'verified': its format has no checksum.

### 15 First run
- Route: `first`  - Composable: `FirstRunScreen` in `ui/screens/HomeScreens.kt`
- Elements: Title, three tiles (codes are read from the gallery; the password is the only key; send codes as files), Got it.
- Components used (scanned from the source): `PrimaryButton`, `RgScaffold`, `RgTile`
- Colour tokens named directly in the screen: none (all colour comes from the shared components)
- Type styles named directly in the screen: none (shared components set them)
- Badges: none
- Deviations from the sheet:
  - No RG monogram on the sheet's welcome card; no drawing was made and the supplied mark is not wired here. **Gap, easy to add.**
  - First tile avoids the word camera (copy rule).

### 16 File too big
- Route: `toobig`  - Composable: `TooBigScreen` in `ui/screens/FlowScreens.kt`
- Elements: Tile 'Needs a bigger canvas' with the current maximum; rows file, after compression, maximum, over by; compression badge; short explanation; 'Colour mode - planned' tile; Choose another file; Allow the 8K canvas (when relevant).
- Components used (scanned from the source): `InfoRow`, `OutlineButton`, `PrimaryButton`, `RgBadge`, `RgScaffold`, `RgTile`
- Colour tokens named directly in the screen: `RgGold`, `RgTextDim`
- Type styles named directly in the screen: `RgType.Small`
- Badges: Info, Warning
- Deviations from the sheet:
  - Sizes in MiB (sheet: MB). **Sheet out of date.**
  - The sheet's colour-mode figure ('about 5.9 MB') is not shown: it was never derived or verified.
  - Extra 'Allow the 8K canvas' button.

## Items the client should decide

1. Standard-QR creation result: add the sheet's 'any phone can read this' wording to the Ready screen for system A?
2. Add the welcome monogram, a thumbnail on the Pick screen, and the 'format: RG-Code v3 - RG-Square v1' About row?
3. Keep the extra decode-side 'Standard QR' screen, or fold it into Text result?