"""Generates golden test vectors for the Kotlin core from the Python reference.
Run from the folder that contains rgcode.py:  python3 rgcode-android/make_vectors.py"""
import hashlib, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms
import rgcode, rgqr, rgsquare

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app/src/test/resources/vectors")
rng = np.random.default_rng(2026)
text = ("RG CODE golden vector. " * 40).encode()
blob = rng.bytes(2500)
big = rng.bytes(40_000)
meta = {}

def save(name, img, expected, password=None):
    img.save(os.path.join(OUT, name + ".png"))
    open(os.path.join(OUT, name + ".bin"), "wb").write(expected)
    meta[name] = {"password": password, "sha256": hashlib.sha256(expected).hexdigest(), "length": len(expected)}

save("rg_raw_1x1_8px", rgcode.encode(text, "1:1", 8, None, compress=False), text)
save("rg_deflate_3x4", rgcode.encode(text, "3:4", 8, None, compress=True), text)
save("rg_chacha_9x16", rgcode.encode(blob, "9:16", 8, "pässword-ü", compress=True, cipher="chacha20poly1305"), blob, "pässword-ü")
save("rg_aes_rot180", rgcode.encode(blob, "1:1", 4, "pw-aes", compress=False, cipher="aes-gcm").rotate(180), blob, "pw-aes")
save("rg_chacha_rot90_1px", rgcode.encode(big, "1:1", 1, "pw", compress=False).rotate(90, expand=True), big, "pw")
save("qr_text", rgqr.encode(text[:700]), text[:700])
save("qr_encrypted", rgqr.encode(blob[:800], "qr-pw"), blob[:800], "qr-pw")
sq_file = rng.bytes(30_000)
save("square_file", rgsquare.encode(rgsquare.file_to_raster(sq_file), "sq-pw"), sq_file, "sq-pw")

def ks(key, nonce, n):
    return Cipher(algorithms.ChaCha20(key, b"\0\0\0\0" + nonce), mode=None).encryptor().update(bytes(n))
key, nonce = bytes(range(32)), bytes(range(12))
import hashlib as h
meta["crypto"] = {
    "pbkdf2_password": "pässword-ü", "pbkdf2_salt": "000102030405060708090a0b0c0d0e0f",
    "pbkdf2_iter200k_96": h.pbkdf2_hmac("sha256", "pässword-ü".encode(), bytes(range(16)), 200_000, 96).hex(),
    "pbkdf2_iter3_40": h.pbkdf2_hmac("sha256", b"passwd", b"salt", 3, 40).hex(),
    "chacha_key": key.hex(), "chacha_nonce": nonce.hex(), "chacha_first_150": ks(key, nonce, 150).hex(),
    "crc16_123456789": rgcode._crc16(b"123456789"),
    "shuffle_key": key.hex(), "shuffle_nonce": nonce.hex(),
}
perm = rgsquare._shuffle(key, nonce)
meta["crypto"]["shuffle_sha256"] = h.sha256(perm.astype("<i4").tobytes()).hexdigest()
meta["crypto"]["shuffle_first_16"] = [int(x) for x in perm[:16]]
json.dump(meta, open(os.path.join(OUT, "vectors.json"), "w"), indent=1)
c = meta["crypto"]
with open(os.path.join(OUT, "crypto.properties"), "w", encoding="utf-8") as f:
    for k in ("pbkdf2_iter200k_96", "pbkdf2_iter3_40", "chacha_first_150", "shuffle_sha256"):
        f.write(f"{k}={c[k]}\n")
    f.write("shuffle_first_16=" + ",".join(map(str, c["shuffle_first_16"])) + "\n")
print({k: v.get("length") for k, v in meta.items() if "length" in v})
print("pbkdf2 sample", meta["crypto"]["pbkdf2_iter3_40"][:32], "crc", hex(meta["crypto"]["crc16_123456789"]))
