package com.rgcode.app.data

import android.content.Context
import com.rgcode.app.core.AppSettings
import com.rgcode.app.core.ShapePref

/** Settings in SharedPreferences. Unknown or out-of-range values fall back to the defaults. */
class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("rg_settings", Context.MODE_PRIVATE)

    fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            shape = ShapePref.values().getOrElse(p.getInt("shape", d.shape.ordinal)) { d.shape },
            grade = p.getInt("grade", d.grade).takeIf { it in 0..4 } ?: d.grade,
            canvas8k = p.getBoolean("canvas8k", d.canvas8k),
            compress = p.getBoolean("compress", d.compress),
        )
    }

    fun firstRunDone() = p.getBoolean("first_run_done", false)
    fun setFirstRunDone() { p.edit().putBoolean("first_run_done", true).apply() }

    fun save(s: AppSettings) {
        p.edit().putInt("shape", s.shape.ordinal).putInt("grade", s.grade)
            .putBoolean("canvas8k", s.canvas8k).putBoolean("compress", s.compress).apply()
    }
}

/** The "recent codes" list on Home: newest first, at most 8, only codes the user actually saved. */
class RecentStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("rg_recent", Context.MODE_PRIVATE)

    fun load(): List<Pure.Recent> = Pure.recentsDecode(p.getString("list", "") ?: "")

    fun add(r: Pure.Recent): List<Pure.Recent> {
        val next = Pure.recentsAdd(load(), r)
        p.edit().putString("list", Pure.recentsEncode(next)).apply()
        return next
    }

    fun remove(uri: String): List<Pure.Recent> {
        val next = load().filter { it.uri != uri }
        p.edit().putString("list", Pure.recentsEncode(next)).apply()
        return next
    }
}
