package com.rgcode.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rgcode.app.StepState
import com.rgcode.app.StepUi
import com.rgcode.app.UiMessage
import com.rgcode.app.ui.theme.Bricolage
import com.rgcode.app.ui.theme.RgGold
import com.rgcode.app.ui.theme.RgMint
import com.rgcode.app.ui.theme.RgRose
import com.rgcode.app.ui.theme.RgSurface
import com.rgcode.app.ui.theme.RgSurfaceHigh
import com.rgcode.app.ui.theme.RgText
import com.rgcode.app.ui.theme.RgTextDim
import com.rgcode.app.ui.theme.RgTextFaint
import com.rgcode.app.ui.theme.RgType
import com.rgcode.app.ui.theme.RgViolet
import com.rgcode.app.ui.theme.RgVioletBright
import com.rgcode.app.ui.theme.RgVoid
import kotlinx.coroutines.delay

/** Every touch target in the app is at least 48 dp; primary actions sit in the bottom (thumb) zone. */
private val MinTarget = 48.dp

// ===================================================================== scaffold + app bar

/**
 * Screen frame: app bar on top, scrolling content, then [actions] pinned at the bottom (thumb zone),
 * then an optional [bottomBar] (RgBottomNav). Handles status bar, navigation bar and keyboard insets.
 */
@Composable
fun RgScaffold(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    message: UiMessage? = null,
    onDismissMessage: () -> Unit = {},
    bottomBar: (@Composable () -> Unit)? = null,
    actions: (@Composable ColumnScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Box(modifier.fillMaxSize().background(RgVoid)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            RgAppBar(title, subtitle, onBack)
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                content()
                Spacer(Modifier.height(8.dp))
            }
            if (actions != null) {
                Column(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) { actions() }
            }
            bottomBar?.invoke()
        }
        MessageBar(message, onDismissMessage, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 96.dp))
    }
}

@Composable
fun RgAppBar(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack, modifier = Modifier.size(MinTarget)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = RgText)
            }
        } else Spacer(Modifier.width(12.dp))
        Column(Modifier.padding(vertical = 8.dp)) {
            Text(title, style = RgType.Title, color = RgText, modifier = Modifier.semantics { heading() })
            if (subtitle != null) Text(subtitle, style = RgType.Label, color = RgTextDim)
        }
    }
}

/** The app name is always written RG CODE, in capitals. */
@Composable
fun BrandName(modifier: Modifier = Modifier) {
    Text("RG CODE", modifier = modifier, color = RgText, fontFamily = Bricolage, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, letterSpacing = 2.sp)
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), style = RgType.Label, color = RgTextDim, modifier = modifier.padding(top = 8.dp))
}

// ===================================================================== tile + rows

@Composable
fun RgTile(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    accent: Color = RgVioletBright,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.fillMaxWidth().clip(shape).background(RgSurface)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .heightIn(min = 64.dp).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(RgSurfaceHigh), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(14.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = RgType.BodyStrong, color = RgText)
            if (subtitle != null) Text(subtitle, style = RgType.Small, color = RgTextDim)
        }
        if (trailing != null) {
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

/** label (mono, dim) on the left, value (mono) on the right: capacities, hex, shape, grade. */
@Composable
fun InfoRow(label: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().heightIn(min = 40.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = RgType.Label, color = RgTextDim)
        Spacer(Modifier.width(12.dp))
        Text(value, style = RgType.Mono, color = RgText, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}

@Composable
fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier, subtitle: String? = null, enabled: Boolean = true) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(RgSurface)
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChange)
            .heightIn(min = 64.dp).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = RgType.BodyStrong, color = if (enabled) RgText else RgTextDim)
            if (subtitle != null) Text(subtitle, style = RgType.Small, color = RgTextDim)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked, onCheckedChange = null, enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedTrackColor = RgViolet, checkedThumbColor = RgText, checkedBorderColor = RgViolet,
                uncheckedTrackColor = RgSurfaceHigh, uncheckedThumbColor = RgTextDim, uncheckedBorderColor = RgTextFaint,
                disabledCheckedTrackColor = RgSurfaceHigh, disabledCheckedThumbColor = RgTextDim, disabledCheckedBorderColor = RgTextFaint,
            ),
        )
    }
}

// ===================================================================== buttons

enum class ButtonStyle { Primary, Gold, Outline }

@Composable
fun RgButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, style: ButtonStyle = ButtonStyle.Primary, enabled: Boolean = true, icon: ImageVector? = null) {
    val shape = RoundedCornerShape(16.dp)
    val m = modifier.fillMaxWidth().heightIn(min = 56.dp)
    val label: @Composable RowScope.() -> Unit = {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(text, style = RgType.Button)
    }
    when (style) {
        ButtonStyle.Primary -> Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = RgViolet, contentColor = RgText, disabledContainerColor = RgSurfaceHigh, disabledContentColor = RgTextDim),
            content = label,
        )
        // Gold is reserved for the single irreversible action on a screen.
        ButtonStyle.Gold -> Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = RgGold, contentColor = RgVoid, disabledContainerColor = RgSurfaceHigh, disabledContentColor = RgTextDim),
            content = label,
        )
        ButtonStyle.Outline -> OutlinedButton(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            border = BorderStroke(1.5.dp, if (enabled) RgVioletBright else RgSurfaceHigh),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = RgVioletBright, disabledContentColor = RgTextDim),
            content = label,
        )
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null) =
    RgButton(text, onClick, modifier, ButtonStyle.Primary, enabled, icon)

@Composable
fun GoldButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null) =
    RgButton(text, onClick, modifier, ButtonStyle.Gold, enabled, icon)

@Composable
fun OutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null) =
    RgButton(text, onClick, modifier, ButtonStyle.Outline, enabled, icon)

/** System chip A-G. 48 dp minimum target; disabled chips stay visible but cannot be chosen. */
@Composable
fun RgChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.defaultMinSize(minWidth = MinTarget, minHeight = MinTarget).clip(shape)
            .background(if (selected) RgViolet else if (enabled) RgSurfaceHigh else RgSurface)
            .selectable(selected = selected, enabled = enabled, role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = RgType.Mono, color = if (enabled) RgText else RgTextDim)
    }
}

// ===================================================================== field

@Composable
fun RgField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String? = null,
    password: Boolean = false,
    mono: Boolean = false,
    singleLine: Boolean = true,
    minLines: Int = 1,
    isError: Boolean = false,
    supporting: String? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth().heightIn(min = 56.dp),
        label = { Text(label) },
        placeholder = if (placeholder != null) ({ Text(placeholder) }) else null,
        supportingText = if (supporting != null) ({ Text(supporting) }) else null,
        trailingIcon = if (password) ({
            IconButton(onClick = { visible = !visible }, modifier = Modifier.size(MinTarget)) {
                Icon(if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = if (visible) "Mask password" else "Show password")
            }
        }) else null,
        textStyle = if (mono) RgType.Mono else RgType.Body,
        singleLine = singleLine, minLines = minLines, isError = isError,
        visualTransformation = if (password && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboardType),
        shape = RoundedCornerShape(14.dp),
        // Labels stay RgTextDim even when focused: RgVioletBright is only 4.4:1 on surface-high.
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = RgText, unfocusedTextColor = RgText, errorTextColor = RgText,
            focusedContainerColor = RgSurfaceHigh, unfocusedContainerColor = RgSurfaceHigh, errorContainerColor = RgSurfaceHigh,
            cursorColor = RgVioletBright, errorCursorColor = RgRose,
            focusedBorderColor = RgVioletBright, unfocusedBorderColor = RgTextFaint, errorBorderColor = RgRose,
            focusedLabelColor = RgTextDim, unfocusedLabelColor = RgTextDim, errorLabelColor = RgRose,
            focusedPlaceholderColor = RgTextDim, unfocusedPlaceholderColor = RgTextDim,
            focusedSupportingTextColor = RgTextDim, unfocusedSupportingTextColor = RgTextDim, errorSupportingTextColor = RgRose,
            focusedTrailingIconColor = RgTextDim, unfocusedTrailingIconColor = RgTextDim,
        ),
    )
}

/** Three segments + a word. 1 = weak (gold), 2 = fair, 3 = good (violet). Never mint: it is not a verified state. */
@Composable
fun StrengthMeter(level: Int, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0 until 3) {
                val on = i < level
                Box(Modifier.weight(1f).height(6.dp).clip(CircleShape).background(if (!on) RgSurfaceHigh else if (level == 1) RgGold else RgVioletBright))
            }
        }
        Text("strength: " + when (level) { 0 -> "—"; 1 -> "weak"; 2 -> "fair"; else -> "good" }, style = RgType.Label, color = RgTextDim)
    }
}

// ===================================================================== badge + callout

enum class BadgeKind { Verified, Warning, Error, Info }

/** Mint = verified states only, gold = warning, rose = errors only. */
@Composable
fun RgBadge(text: String, kind: BadgeKind, modifier: Modifier = Modifier) {
    val color: Color
    val icon: ImageVector
    when (kind) {
        BadgeKind.Verified -> { color = RgMint; icon = Icons.Default.Check }
        BadgeKind.Warning -> { color = RgGold; icon = Icons.Default.Warning }
        BadgeKind.Error -> { color = RgRose; icon = Icons.Default.Error }
        BadgeKind.Info -> { color = RgVioletBright; icon = Icons.Default.Info }
    }
    val shape = RoundedCornerShape(10.dp)
    Row(
        modifier.clip(shape).background(color.copy(alpha = 0.12f)).border(1.dp, color.copy(alpha = 0.6f), shape).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = RgType.Label, color = if (kind == BadgeKind.Info) RgText else color)
    }
}

/** Gold side bar: warnings such as "send it as a file" or "forget the password and the file is gone". */
@Composable
fun Callout(text: String, modifier: Modifier = Modifier, title: String? = null) {
    Row(modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(14.dp)).background(RgSurface)) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(RgGold))
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (title != null) Text(title, style = RgType.BodyStrong, color = RgText)
            Text(text, style = RgType.Small, color = RgTextDim)
        }
    }
}

// ===================================================================== progress

@Composable
fun RgProgressBar(modifier: Modifier = Modifier, progress: Float? = null) {
    val m = modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
    if (progress != null) LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = m, color = RgViolet, trackColor = RgSurfaceHigh)
    else LinearProgressIndicator(modifier = m, color = RgViolet, trackColor = RgSurfaceHigh)
}

/** One line of the build / open step list. Set [verified] only for the read-back step: then the tick is mint. */
@Composable
fun StepRow(step: StepUi, modifier: Modifier = Modifier, verified: Boolean = false) {
    Row(modifier.fillMaxWidth().heightIn(min = MinTarget), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) {
            when (step.state) {
                StepState.DONE -> {
                    val c = if (verified) RgMint else RgVioletBright
                    Icon(Icons.Default.Check, contentDescription = "done", tint = c, modifier = Modifier.size(20.dp))
                }
                StepState.RUNNING -> CircularProgressIndicator(Modifier.size(20.dp), color = RgVioletBright, strokeWidth = 2.dp)
                StepState.TODO -> Box(Modifier.size(14.dp).border(1.5.dp, RgTextFaint, CircleShape))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(step.label, style = RgType.Body, color = if (step.state == StepState.TODO) RgTextDim else RgText)
            if (step.detail.isNotBlank()) Text(step.detail, style = RgType.Label, color = RgTextDim)
        }
    }
}

// ===================================================================== code preview

/** Shows a code image scaled down with nearest-neighbour filtering, so the noise stays crisp. */
@Composable
fun CodePreview(bitmap: Bitmap?, modifier: Modifier = Modifier, placeholder: String = "preview · black and white noise", smooth: Boolean = false) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.fillMaxWidth().clip(shape).background(RgSurface).border(1.dp, RgSurfaceHigh, shape).padding(12.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            val ratio = (bitmap.width.toFloat() / bitmap.height).coerceIn(0.4f, 2.5f)
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Preview of the code, drawn smaller than its real size",
                modifier = Modifier.heightIn(max = 380.dp).aspectRatio(ratio),
                contentScale = ContentScale.Fit,
                filterQuality = if (smooth) FilterQuality.Medium else FilterQuality.None,
            )
        } else {
            Text(placeholder, style = RgType.Label, color = RgTextDim, modifier = Modifier.padding(vertical = 56.dp))
        }
    }
}

// ===================================================================== bottom nav + message

/** Home / Create / Open / Settings. [current] is one of "home", "create", "open", "settings". */
@Composable
fun RgBottomNav(current: String, onSelect: (String) -> Unit) {
    val items = listOf(
        Triple("home", "Home", Icons.Default.Home), Triple("create", "Create", Icons.Default.Add),
        Triple("open", "Open", Icons.Default.FolderOpen), Triple("settings", "Settings", Icons.Default.Settings),
    )
    Row(Modifier.fillMaxWidth().background(RgSurface).padding(horizontal = 8.dp)) {
        for ((route, label, icon) in items) {
            val selected = route == current
            val c = if (selected) RgVioletBright else RgTextDim
            Column(
                Modifier.weight(1f).heightIn(min = 64.dp).selectable(selected = selected, role = Role.Tab, onClick = { onSelect(route) }).padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(24.dp))
                Text(label, style = RgType.Label, color = c)
            }
        }
    }
}

/** Result of a save or copy. Mint when a read-back verified it, rose when it failed. Tap or wait 7 s to dismiss. */
@Composable
fun MessageBar(message: UiMessage?, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    LaunchedEffect(message) {
        if (message != null) {
            delay(7000)
            onDismiss()
        }
    }
    if (message != null) {
        val c = if (message.ok) RgMint else RgRose
        val shape = RoundedCornerShape(14.dp)
        Row(
            modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(shape).background(RgSurfaceHigh).border(1.dp, c, shape)
                .clickable(onClick = onDismiss).semantics { liveRegion = LiveRegionMode.Polite }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(if (message.ok) Icons.Default.Check else Icons.Default.Error, contentDescription = null, tint = c, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text(message.text, style = RgType.Small, color = RgText)
        }
    }
}
