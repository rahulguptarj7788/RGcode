package com.rgcode.app

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rgcode.app.core.*
import com.rgcode.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>().applicationContext
    private val settingsStore = SettingsStore(ctx)
    private val recentStore = RecentStore(ctx)

    // One-shot navigation requests; the NavHost collects these (chunk 5).
    private val channel = Channel<String>(Channel.BUFFERED)
    val events = channel.receiveAsFlow()
    private fun go(route: String) { channel.trySend(route) }

    var settings by mutableStateOf(settingsStore.load()); private set
    var recents by mutableStateOf(recentStore.load()); private set
    var message by mutableStateOf<UiMessage?>(null)
    var firstRunDone by mutableStateOf(settingsStore.firstRunDone()); private set
    fun markFirstRunDone() { firstRunDone = true; settingsStore.setFirstRunDone() }

    fun updateSettings(s: AppSettings) { settings = s; settingsStore.save(s) }

    /** True only on API 28, where gallery folders need the legacy permission. The UI asks (SaveGate.kt). */
    fun needsStoragePermission() = Exporter.needsLegacyPermission(ctx)

    // =====================================================================================
    // DECODE PATH: open a code from the gallery, identify it, verify it, show the result.
    // =====================================================================================
    var openStage by mutableStateOf(Stage.IDLE); private set
    val openLog = mutableStateListOf<String>()
    var restored by mutableStateOf<RestoredUi?>(null); private set
    var failure by mutableStateOf<FailureUi?>(null); private set
    private var pending: Identified? = null
    private var openJob: Job? = null

    private fun log(line: String) { openLog.add(line) }

    fun resetOpen() {
        openJob?.cancel()
        pending = null
        openStage = Stage.IDLE
        openLog.clear()
        restored?.preview?.recycle()
        restored = null
        failure = null
    }

    fun openUri(uri: Uri) {
        resetOpen()
        openStage = Stage.BUSY
        openJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                val bmp = ImageIO.load(ctx, uri)
                log("image read · ${bmp.width} × ${bmp.height} px, no resampling")
                val id = try { Identify.run(BitmapPixels(bmp)) } finally { bmp.recycle() }
                pending = id
                when (id) {
                    is Identified.Stream -> {
                        log("grid found · ${id.system}")
                        log("clock tracks read · orientation resolved")
                        log("header: version ${id.parsed.version}" + if (id.parsed.encrypted) " · ${aeadOf(id.parsed)?.label()}" else "")
                        if (id.parsed.encrypted) askPassword() else deliverStream(id, null)
                    }
                    is Identified.PlainQr -> {
                        log("standard QR found")
                        deliver(id.text.toByteArray(Charsets.UTF_8), "Standard QR", "plain QR text · the format carries no checksum", false, false, null, route = "qr")
                    }
                    is Identified.Square -> {
                        log("colour squares found · ${RgSquare.COLS} × ${RgSquare.ROWS}")
                        askPassword()
                    }
                }
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                fail(e)
            }
        }
    }

    fun openRecent(r: Pure.Recent) = openUri(Uri.parse(r.uri))

    private fun askPassword() { openStage = Stage.NEED_PASSWORD }

    fun submitPassword(password: String) {
        val id = pending ?: return
        openStage = Stage.BUSY
        failure = null
        openJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                log("deriving the key · PBKDF2-HMAC-SHA256 · 200,000 rounds")
                when (id) {
                    is Identified.Stream -> deliverStream(id, password)
                    is Identified.Square -> {
                        val bytes = RgSquare.decodeFile(id.pixels, password)
                        deliver(bytes, "RG-Square", "authentication tag OK", true, false, Aead.CHACHA20_POLY1305)
                    }
                    is Identified.PlainQr -> Unit
                }
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                fail(e)
            }
        }
    }

    /** From the error screen: "Try another password". */
    fun retryPassword() {
        if (pending == null) return
        failure = null
        openStage = Stage.NEED_PASSWORD
        go("open")
    }

    private fun aeadOf(p: ParsedStream): Aead? =
        if (!p.encrypted) null else if (p.flags and RgCode.FLAG_CHACHA != 0) Aead.CHACHA20_POLY1305 else Aead.AES_GCM

    private fun Aead.label() = if (this == Aead.CHACHA20_POLY1305) "ChaCha20-Poly1305" else "AES-256-GCM"

    private fun deliverStream(id: Identified.Stream, password: String?) {
        val p = id.parsed
        val bytes = RgCode.open(p, password)          // CRC first, then tag, then inflate; throws, never partial
        val integrity = buildString {
            append("CRC-16 OK")
            if (p.compressed) append(" · zlib checksum OK")
            if (p.encrypted) append(" · authentication tag OK")
        }
        deliver(bytes, id.system, integrity, p.encrypted, p.compressed, aeadOf(p))
    }

    private fun deliver(bytes: ByteArray, system: String, integrity: String, encrypted: Boolean, compressed: Boolean, aead: Aead?, route: String? = null) {
        val info = Sniff.of(bytes)
        val text = if (info.kind == Sniff.Kind.TEXT || route == "qr") String(bytes, Charsets.UTF_8) else null
        val preview = if (info.kind == Sniff.Kind.IMAGE) samplePreview(bytes) else null
        restored = RestoredUi(bytes, info, system, integrity, preview, text, encrypted, compressed, aead)
        openStage = Stage.RESTORED
        go(route ?: if (text != null) "text" else "restored")
    }

    private fun samplePreview(bytes: ByteArray, maxSide: Int = 1024): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var s = 1
        while (o.outWidth / s > maxSide || o.outHeight / s > maxSide) s *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s; inScaled = false })
    }

    private val photoHint = "A photo-share or a screenshot recompresses the image and destroys 1 px data. Open the original PNG, sent as a file."

    private fun failureOf(e: Throwable): FailureUi = when (e) {
        is WrongPasswordException -> FailureUi("Wrong password or damaged file", e.message ?: "The tag did not verify.", photoHint, canRetryPassword = pending != null)
        is FileDamagedException -> FailureUi("File damaged", e.message ?: "The checksum does not match.", photoHint, false)
        is NotACodeException -> FailureUi("No code found", e.message ?: "No RG CODE found in this image.", photoHint, false)
        is UnsupportedException -> FailureUi("Not supported by this version", e.message ?: "", "Update RG CODE to open this code.", false)
        is CapacityException -> FailureUi("Not enough room", e.message ?: "", "Nothing was changed.", false)
        is VerifyFailedException -> FailureUi("Could not verify the code", e.message ?: "", "Nothing was saved. Try again.", false)
        is OutOfMemoryError -> FailureUi("Not enough memory", "The phone ran out of memory for this image.", "Choose the 4K canvas in Settings.", false)
        else -> FailureUi("Something went wrong", e.message ?: e.javaClass.simpleName, "Nothing was changed.", false)
    }

    private fun fail(e: Throwable) {
        failure = failureOf(e)
        openStage = Stage.FAILED
        go("error")
    }

    /** Recovered original -> Downloads/, written then read back byte for byte. */
    fun saveRestored() {
        val r = restored ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val name = Pure.safeFileName("restored", "restored", r.info.ext)
            when (val res = Exporter.saveOriginal(ctx, ArraySrc(r.bytes), name, r.info.mime)) {
                is SaveResult.Saved -> {
                    restored = r.copy(savedWhere = res.where)
                    message = UiMessage("Saved to ${res.where} · read back, byte-identical", true)
                }
                is SaveResult.Mismatch -> message = UiMessage(res.detail, false)
                is SaveResult.Failed -> message = UiMessage("Not saved: ${res.detail}", false)
            }
        }
    }

    fun copyText(): Boolean {
        val t = restored?.text ?: return false
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("RG CODE", t))
        return true
    }

    fun saveTextFile() {
        val r = restored ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val name = Pure.safeFileName("restored", "restored", "txt")
            when (val res = Exporter.saveOriginal(ctx, ArraySrc(r.bytes), name, "text/plain")) {
                is SaveResult.Saved -> { restored = r.copy(savedWhere = res.where); message = UiMessage("Saved to ${res.where} · read back, byte-identical", true) }
                is SaveResult.Mismatch -> message = UiMessage(res.detail, false)
                is SaveResult.Failed -> message = UiMessage("Not saved: ${res.detail}", false)
            }
        }
    }

    // =====================================================================================
    // ENCODE PATH: what goes in -> the app decides -> password -> build -> verify -> ready.
    // =====================================================================================
    private companion object { const val READ_LIMIT = 16 * 1024 * 1024 }

    var kind by mutableStateOf(PayloadKind.TEXT); private set
    var payload by mutableStateOf<Payload?>(null); private set
    var prepared by mutableStateOf<Prepared?>(null); private set
    var planResult by mutableStateOf<PlanResult?>(null); private set
    var forcedSystem by mutableStateOf<SystemId?>(null); private set
    var lockEnabled by mutableStateOf(false)
    var password by mutableStateOf("")
    var confirm by mutableStateOf("")
    var compressFirst by mutableStateOf(settings.compress)
    var tooBig by mutableStateOf<TooBigUi?>(null); private set
    var steps by mutableStateOf<List<StepUi>>(emptyList()); private set
    var ready by mutableStateOf<ReadyUi?>(null); private set
    var building by mutableStateOf(false); private set
    private var buildJob: Job? = null
    private var aead = Aead.CHACHA20_POLY1305     // default: ChaCha20-Poly1305 (flags bit2 = 1)

    /** Photos always get a password: a colour-square code has no unprotected mode. */
    fun lockOn() = lockEnabled || kind == PayloadKind.PHOTO
    fun passwordOk() = !lockOn() || PasswordRules.valid(password, confirm)

    fun startCreate(k: PayloadKind) {
        buildJob?.cancel()
        discardReady()
        kind = k
        payload = null; prepared = null; planResult = null; forcedSystem = null; tooBig = null
        lockEnabled = k == PayloadKind.PHOTO
        password = ""; confirm = ""; compressFirst = settings.compress
        steps = emptyList()
    }

    fun setText(text: String) {
        payload = if (text.isEmpty()) null else Payload(PayloadKind.TEXT, "text", text.toByteArray(Charsets.UTF_8), "text/plain")
    }

    fun estimate(text: String): Int = if (text.isEmpty()) 0 else minOf(text.toByteArray(Charsets.UTF_8).size, RgCode.deflate(text.toByteArray(Charsets.UTF_8)).size)

    /** Photo Picker / document result for "Photo from gallery" and "Any file". */
    fun pickForCreate(uri: Uri, k: PayloadKind) {
        kind = k
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val f = ImageIO.readPicked(ctx, uri, READ_LIMIT)
                if (f.bytes == null) {
                    tooBig = tooBigFor(f.name, f.size, k)
                    go("toobig")
                    return@launch
                }
                payload = Payload(k, f.name, f.bytes, f.mime)
                computePlan()
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                message = UiMessage("Could not read the file: ${e.message ?: e.javaClass.simpleName}", false)
            }
        }
    }

    private fun topCapacity(k: PayloadKind): Pair<Int, String> {
        if (k == PayloadKind.PHOTO) return RgSquare.FILE_CAPACITY to "RG-Square"
        val top = if (settings.canvas8k) RgCode.Shape.BIG8K else RgCode.Shape.BIG4K
        val (w, h) = RgCode.gridSize(top, 1)
        return RgCode.capacity(w, h, lockOn()) to "${top.label} canvas, 1 px"
    }

    private fun tooBigFor(name: String, size: Long, k: PayloadKind): TooBigUi {
        val (cap, label) = topCapacity(k)
        return TooBigUi(name, size, size, cap, label, compressionHelps = false, isPhoto = k == PayloadKind.PHOTO)
    }

    private fun computePlan() {
        val p = payload ?: return
        val prep = Planner.prepare(p.kind, p.bytes, compressFirst)
        prepared = prep
        planResult = Planner.plan(prep, lockOn(), settings, forcedSystem)
    }

    /** Re-plan after the password lock, compression toggle or system choice changes. */
    fun replan() { viewModelScope.launch(Dispatchers.Default) { computePlan() } }

    fun chooseSystem(id: SystemId?) { forcedSystem = id; replan() }

    /** Called by "Continue": plan, then either the decide screen or the "too big" screen. */
    fun proceedToDecide() {
        viewModelScope.launch(Dispatchers.Default) {
            computePlan()
            val r = planResult
            val p = payload
            if (r is PlanResult.TooBig && p != null) {
                tooBig = TooBigUi(p.name, p.bytes.size.toLong(), r.stored.toLong(), r.maxCapacity, r.maxLabel, r.compressionHelps, p.kind == PayloadKind.PHOTO)
                go("toobig")
            } else go("decide")
        }
    }

    private fun setStep(i: Int, state: StepState, detail: String = "") {
        steps = steps.mapIndexed { k, s -> if (k == i) StepUi(s.label, state, detail) else s }
    }

    private fun discardReady() {
        ready?.let { it.preview.recycle(); it.file.delete() }
        ready = null
    }

    fun cancelBuild() {
        buildJob?.cancel()
        building = false
        steps = emptyList()
    }

    /** Compress -> encrypt -> choose system -> draw -> write PNG -> read it back with the real decoder. */
    fun startBuild() {
        val p = payload ?: return
        discardReady()
        val encrypted = lockOn()
        val pw = if (encrypted) password else null
        steps = listOf("Compress", "Encrypt", "System chosen", "Drawing squares", "Writing PNG", "Verifying by reading it back").map { StepUi(it, StepState.TODO) }
        building = true
        go("building")
        buildJob = viewModelScope.launch(Dispatchers.Default) {
            var bmp: Bitmap? = null
            var out: File? = null
            try {
                setStep(0, StepState.RUNNING)
                val prep = Planner.prepare(p.kind, p.bytes, compressFirst)
                setStep(0, StepState.DONE, if (compressFirst && prep.compressionHelps) "${fmt(prep.rawLen)} B → ${fmt(prep.storedLen)} B" else "kept as is · ${fmt(prep.rawLen)} B")
                ensureActive()

                val res = Planner.plan(prep, encrypted, settings, forcedSystem)
                if (res !is PlanResult.Fits) {
                    res as PlanResult.TooBig
                    tooBig = TooBigUi(p.name, p.bytes.size.toLong(), res.stored.toLong(), res.maxCapacity, res.maxLabel, res.compressionHelps, p.kind == PayloadKind.PHOTO)
                    building = false
                    go("toobig")
                    return@launch
                }
                val plan = res.plan

                setStep(1, StepState.RUNNING)
                val content = CodeBuilder.seal(plan, p.bytes, pw, compressFirst, aead)
                setStep(1, StepState.DONE, if (encrypted) "${if (plan.system == SystemId.G) "ChaCha20-Poly1305" else aead.label()} · PBKDF2 200,000" else "not locked")
                ensureActive()

                setStep(2, StepState.DONE, "${plan.system.letter} · ${plan.system.label}" + if (plan.px > 0) " · ${plan.px} px" else "")
                setStep(3, StepState.RUNNING)
                var canvasW = 0
                val dims = CodeBuilder.draw(plan, content) { w, h ->
                    canvasW = w
                    bmp = ImageIO.newCanvas(w, h)
                    BitmapSink(bmp!!)
                }
                val image = bmp!!
                val preview = previewOf(image)
                setStep(3, StepState.DONE, "${dims.first} × ${dims.second} px")
                ensureActive()

                setStep(4, StepState.RUNNING)
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val name = Pure.safeFileName("rg_code_$stamp", "rg_code", "png")
                out = File(File(ctx.cacheDir, "codes"), name)
                ImageIO.writePng(image, out)       // lossless PNG, quality argument is ignored by the encoder
                image.recycle(); bmp = null          // never hold two full-size bitmaps at once
                setStep(4, StepState.DONE, "${fmt(out.length().toInt())} B")
                ensureActive()

                setStep(5, StepState.RUNNING)
                val back = ImageIO.loadFile(out)
                val badge = try { CodeBuilder.readBack(BitmapPixels(back), plan, p.bytes, pw) } finally { back.recycle() }
                setStep(5, StepState.DONE, badge)

                val compressed = (content as? Content.Stream)?.let { RgCode.parseStream(it.bytes)?.compressed } ?: false
                ready = ReadyUi(out, name, plan, preview, badge, out.length(), encrypted, compressed, if (encrypted) (if (plan.system == SystemId.G) Aead.CHACHA20_POLY1305 else aead) else null)
                building = false
                go("ready")
            } catch (e: Throwable) {
                bmp?.recycle()
                out?.delete()
                if (e is kotlinx.coroutines.CancellationException) throw e
                building = false
                failure = failureOf(e)
                go("error")
            }
        }
    }

    private fun fmt(n: Int) = String.format(Locale.US, "%,d", n)

    private fun previewOf(bmp: Bitmap): Bitmap {
        val f = maxOf(1, (maxOf(bmp.width, bmp.height) + 639) / 640)
        return if (f == 1) Bitmap.createBitmap(bmp) else Bitmap.createScaledBitmap(bmp, bmp.width / f, bmp.height / f, false)
    }

    private fun lineFor(plan: Plan) = if (plan.px > 0) "${plan.shape?.label} · ${plan.px} px" else plan.system.label

    /** Generated code -> Pictures/RG CODE/, then added to the recent list. */
    fun saveCode() {
        val r = ready ?: return
        viewModelScope.launch(Dispatchers.IO) {
            when (val res = Exporter.saveCode(ctx, FileSrc(r.file), r.fileName)) {
                is SaveResult.Saved -> {
                    ready = r.copy(savedWhere = res.where)
                    recents = recentStore.add(Pure.Recent(System.currentTimeMillis(), r.fileName, lineFor(r.plan), res.uri.toString()))
                    message = UiMessage("Saved to ${res.where} · read back, byte-identical", true)
                }
                is SaveResult.Mismatch -> message = UiMessage(res.detail, false)
                is SaveResult.Failed -> message = UiMessage("Not saved: ${res.detail}", false)
            }
        }
    }

    fun shareCode() {
        val r = ready ?: return
        try { Exporter.share(ctx, r.file, r.fileName) } catch (e: Exception) { message = UiMessage("Could not share: ${e.message}", false) }
    }

    fun removeRecent(r: Pure.Recent) { recents = recentStore.remove(r.uri) }

    override fun onCleared() {
        buildJob?.cancel(); openJob?.cancel()
        discardReady()
        super.onCleared()
    }
}
