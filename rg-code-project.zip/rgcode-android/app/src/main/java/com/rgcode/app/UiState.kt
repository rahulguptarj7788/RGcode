package com.rgcode.app

import android.graphics.Bitmap
import com.rgcode.app.core.Aead
import com.rgcode.app.core.PayloadKind
import com.rgcode.app.core.Plan
import com.rgcode.app.core.Sniff
import java.io.File

class Payload(val kind: PayloadKind, val name: String, val bytes: ByteArray, val mime: String?)

enum class Stage { IDLE, BUSY, NEED_PASSWORD, RESTORED, FAILED }
enum class StepState { TODO, RUNNING, DONE }
class StepUi(val label: String, val state: StepState, val detail: String = "")

/** A finished, read-back-verified code. [file] lives in the app cache until the user saves it. */
data class ReadyUi(
    val file: File, val fileName: String, val plan: Plan, val preview: Bitmap, val verified: String,
    val sizeBytes: Long, val encrypted: Boolean, val compressed: Boolean, val aead: Aead?, val savedWhere: String? = null,
)

/** A recovered original. [integrity] states only what the format actually verified. */
data class RestoredUi(
    val bytes: ByteArray, val info: Sniff.Info, val system: String, val integrity: String, val preview: Bitmap?,
    val text: String?, val encrypted: Boolean, val compressed: Boolean, val aead: Aead?, val savedWhere: String? = null,
)

class FailureUi(val title: String, val reason: String, val hint: String, val canRetryPassword: Boolean)

class TooBigUi(
    val name: String, val rawBytes: Long, val storedBytes: Long, val maxCapacity: Int, val maxLabel: String,
    val compressionHelps: Boolean, val isPhoto: Boolean,
)

class UiMessage(val text: String, val ok: Boolean)
