package com.rgcode.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.rgcode.app.MainViewModel
import com.rgcode.app.R
import com.rgcode.app.core.ShapePref
import com.rgcode.app.ui.*
import com.rgcode.app.ui.theme.*

// ------------------------------------------------------------------ 11. Settings
@Composable
fun SettingsScreen(vm: MainViewModel, nav: NavController) {
    val s = vm.settings
    val ctx = LocalContext.current
    val version = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0" } catch (e: Exception) { "1.0" } }
    RgScaffold(
        title = "Settings", subtitle = "RG CODE $version",
        bottomBar = { RgBottomNav("settings") { nav.tab(it) } },
    ) {
        SectionLabel("Default shape")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ShapePref.values().forEach { p -> RgChip(p.label, s.shape == p, { vm.updateSettings(s.copy(shape = p)) }, Modifier.weight(1f)) }
        }
        Text("Auto picks the smallest shape that fits.", style = RgType.Small, color = RgTextDim)

        SectionLabel("Default grade")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0 to "Auto", 1 to "1 px", 2 to "2 px", 3 to "4 px", 4 to "8 px").forEach { (g, label) ->
                RgChip(label, s.grade == g, { vm.updateSettings(s.copy(grade = g)) }, Modifier.weight(1f))
            }
        }
        Text("8 px is the only grade that survived every photo-sharing test. Auto uses the sturdiest grade that fits.", style = RgType.Small, color = RgTextDim)

        SectionLabel("Canvas")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RgChip("4K", !s.canvas8k, { vm.updateSettings(s.copy(canvas8k = false)) }, Modifier.weight(1f))
            RgChip("8K", s.canvas8k, { vm.updateSettings(s.copy(canvas8k = true)) }, Modifier.weight(1f))
        }
        if (s.canvas8k) Callout("The 8K canvas needs about 127 MiB of memory for the picture. A phone with little memory may fail to build or open it.", title = "Opt-in")
        else Text("4K is the default: a picture of about 32 MiB.", style = RgType.Small, color = RgTextDim)

        ToggleRow("Compress first", s.compress, { vm.updateSettings(s.copy(compress = it)) }, subtitle = "Deflate level 9 before encrypting")
        RgTile("About and limits", subtitle = "What this app can and cannot do", icon = Icons.Default.Info, onClick = { nav.navigate("about") })
        InfoRow("version", version)
        InfoRow("default cipher", "ChaCha20-Poly1305")
    }
}

// ------------------------------------------------------------------ 12. About and limits
@Composable
fun AboutScreen(vm: MainViewModel, nav: NavController) {
    RgScaffold(
        title = "About and limits", subtitle = "Told plainly, before you rely on it", onBack = { nav.popBackStack() },
        actions = { PrimaryButton("Close", { nav.popBackStack() }) },
    ) {
        Image(
            painter = painterResource(R.drawable.rg_code_logo_lockup), contentDescription = "RG CODE",
            modifier = Modifier.fillMaxWidth().heightIn(max = 160.dp), contentScale = ContentScale.Fit,
        )
        RgTile("Lossless PNG only", subtitle = "Re-saving a code as a JPEG, or sending it as a photo, destroys the small pixels.", icon = Icons.Default.Image)
        RgTile("No recovery", subtitle = "The password is the only key. Forget it and the file is gone for good.", icon = Icons.Default.Lock)
        RgTile("Encryption", subtitle = "ChaCha20-Poly1305 by default. AES-256-GCM is also read. Key from PBKDF2-HMAC-SHA256, 200,000 rounds.", icon = Icons.Default.Key)
        RgTile("Grade matters when sharing", subtitle = "Only 8 px squares survived every photo test. 1 px needs a file transfer.", icon = Icons.Default.Tune)
        RgTile("Colour squares", subtitle = "The scatter is only a visual effect. The encryption is what protects the file.", icon = Icons.Default.Palette)
        RgTile("File names are not stored", subtitle = "A restored file is saved as restored.<type>, guessed from its content.", icon = Icons.Default.Description)
        RgTile("Standard QR", subtitle = "Up to 2,953 bytes of plain text. With a password, or for binary data, about 2,200 bytes.", icon = Icons.Default.Info)
        Text("Fonts: Bricolage Grotesque, IBM Plex Sans, Fragment Mono · SIL Open Font Licence.", style = RgType.Label, color = RgTextDim)
    }
}
