package com.rgcode.app.core

class IntPixels(override val width: Int, override val height: Int, val data: IntArray) : PixelSource {
    override fun readRow(y: Int, out: IntArray) = System.arraycopy(data, y * width, out, 0, width)
}

/** What a picked image turned out to be. The user is never asked which format a code uses. */
sealed interface Identified {
    class Stream(val parsed: ParsedStream, val system: String) : Identified     // RG-Code or RGQ1 QR
    class PlainQr(val text: String) : Identified                                  // an ordinary QR
    class Square(val pixels: IntPixels) : Identified                              // colour squares
}

object Identify {
    fun run(src: PixelSource): Identified {
        RgCode.read(src)?.let { return Identified.Stream(it, "RG-Code ${it.gridW} × ${it.gridH}") }
        if (RgSquare.isSquareSized(src.width, src.height)) {
            val data = IntArray(src.width * src.height)
            val row = IntArray(src.width)
            for (y in 0 until src.height) { src.readRow(y, row); System.arraycopy(row, 0, data, y * src.width, src.width) }
            return Identified.Square(IntPixels(src.width, src.height, data))
        }
        val text = QrTier.read(src) ?: throw NotACodeException()
        val (plain, parsed) = QrTier.parseContent(text)
        return if (plain != null) Identified.PlainQr(text) else Identified.Stream(parsed!!, "Standard QR")
    }
}

/** Content sniffing: the format stores no file name, so the app guesses a sensible extension. */
object Sniff {
    enum class Kind { TEXT, IMAGE, OTHER }
    class Info(val kind: Kind, val ext: String, val mime: String)

    fun of(b: ByteArray): Info {
        fun starts(vararg v: Int) = b.size >= v.size && v.indices.all { (b[it].toInt() and 255) == v[it] }
        return when {
            starts(0x89, 0x50, 0x4E, 0x47) -> Info(Kind.IMAGE, "png", "image/png")
            starts(0xFF, 0xD8, 0xFF) -> Info(Kind.IMAGE, "jpg", "image/jpeg")
            starts(0x47, 0x49, 0x46, 0x38) -> Info(Kind.IMAGE, "gif", "image/gif")
            b.size > 12 && String(b, 0, 4, Charsets.ISO_8859_1) == "RIFF" && String(b, 8, 4, Charsets.ISO_8859_1) == "WEBP" -> Info(Kind.IMAGE, "webp", "image/webp")
            starts(0x25, 0x50, 0x44, 0x46) -> Info(Kind.OTHER, "pdf", "application/pdf")
            starts(0x50, 0x4B, 0x03, 0x04) -> Info(Kind.OTHER, "zip", "application/zip")
            b.size > 8 && String(b, 4, 4, Charsets.ISO_8859_1) == "ftyp" -> Info(Kind.OTHER, "mp4", "video/mp4")
            looksLikeText(b) -> Info(Kind.TEXT, "txt", "text/plain")
            else -> Info(Kind.OTHER, "bin", "application/octet-stream")
        }
    }

    fun looksLikeText(b: ByteArray): Boolean {
        if (b.isEmpty()) return true
        val s = try { Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(b)).toString() } catch (e: java.nio.charset.CharacterCodingException) { return false }
        val bad = s.count { it.code < 32 && it != '\n' && it != '\r' && it != '\t' }
        return bad * 100 <= s.length
    }
}
