package com.rgcode.app.ui

import java.util.Locale

/** 12,345 (thousands separators, locale-independent so tests and screenshots match). */
fun fmtInt(n: Long): String = String.format(Locale.US, "%,d", n)
fun fmtInt(n: Int): String = fmtInt(n.toLong())

/** Binary units, stated plainly: B, KiB, MiB (1 MiB = 1,048,576 B). */
fun fmtBytes(n: Long): String = when {
    n < 1024 -> "${fmtInt(n)} B"
    n < 1024 * 1024 -> String.format(Locale.US, "%.1f KiB", n / 1024.0)
    else -> String.format(Locale.US, "%.2f MiB", n / 1048576.0)
}
fun fmtBytes(n: Int): String = fmtBytes(n.toLong())
