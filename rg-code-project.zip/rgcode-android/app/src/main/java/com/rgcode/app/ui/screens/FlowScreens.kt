package com.rgcode.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.rgcode.app.MainViewModel
import com.rgcode.app.StepState
import com.rgcode.app.UiMessage
import com.rgcode.app.core.*
import com.rgcode.app.ui.*
import com.rgcode.app.ui.theme.*

private const val PHOTO_SHARE_WARNING =
    "This grade will not survive being sent as a photo. Only 8 px squares do. Send the PNG as a file instead."

// ------------------------------------------------------------------ 4. The app decides
@Composable
fun DecideScreen(vm: MainViewModel, nav: NavController) {
    val result = vm.planResult
    val prepared = vm.prepared
    var choosing by remember { mutableStateOf(false) }
    RgScaffold(
        title = "Chosen for you", subtitle = "Nothing to fill in", onBack = { nav.popBackStack() },
        actions = { PrimaryButton("Continue", { nav.navigate("password") }, enabled = result is PlanResult.Fits) },
    ) {
        if (result !is PlanResult.Fits || prepared == null) {
            Text("Working it out…", style = RgType.Body, color = RgTextDim)
            return@RgScaffold
        }
        val plan = result.plan
        RgTile("${plan.system.letter} · ${plan.system.label}", subtitle = shapeLabel(plan) + " · " + gradeLabel(plan), icon = Icons.Default.Tune)
        InfoRow("shape", shapeLabel(plan))
        InfoRow("grade", gradeLabel(plan))
        InfoRow("squares", if (plan.squares > 0) fmtInt(plan.squares) else "—")
        InfoRow("capacity", "${fmtInt(plan.capacity)} B")
        InfoRow("your data", "${fmtInt(plan.stored)} B")
        RgBadge(if (plan.comfortable) "fits comfortably" else "fits · nearly full", if (plan.comfortable) BadgeKind.Verified else BadgeKind.Warning)

        // Only the systems that apply to this input: text and files show A-F, a photo shows G.
        val ids = Planner.applicable(vm.kind, vm.settings.canvas8k)
        val locked = vm.lockOn()
        val fits = remember(prepared, locked, vm.settings) { ids.associateWith { Planner.plan(prepared, locked, vm.settings, it) is PlanResult.Fits } }
        SectionLabel("System")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ids.forEach { id ->
                RgChip(id.letter.toString(), selected = id == plan.system, enabled = choosing && fits[id] == true, onClick = { vm.chooseSystem(id) })
            }
        }
        Text(
            if (vm.kind == PayloadKind.PHOTO) "A–F · the text systems appear only for text and files"
            else "G · the image system appears only for photos",
            style = RgType.Label, color = RgTextDim,
        )
        OutlineButton(
            if (choosing) "Use the automatic choice" else "Change system",
            { if (choosing) vm.chooseSystem(null); choosing = !choosing },
            enabled = ids.size > 1,
        )
        if (!plan.survivesPhotoShare) Callout(PHOTO_SHARE_WARNING)
    }
}

// ------------------------------------------------------------------ 5. Password
@Composable
fun PasswordScreen(vm: MainViewModel, nav: NavController) {
    val photo = vm.kind == PayloadKind.PHOTO
    val locked = vm.lockOn()
    val mismatch = vm.confirm.isNotEmpty() && vm.confirm != vm.password
    RgScaffold(
        title = "Lock it", subtitle = "ChaCha20-Poly1305 · PBKDF2-SHA256 · 200,000 rounds", onBack = { nav.popBackStack() },
        actions = {
            if (locked) GoldButton("Encrypt and build the code", { vm.startBuild() }, enabled = vm.passwordOk(), icon = Icons.Default.Lock)
            else PrimaryButton("Build the code", { vm.startBuild() })
        },
    ) {
        ToggleRow(
            "Lock with password", checked = locked, onChange = { vm.lockEnabled = it; vm.replan() }, enabled = !photo,
            subtitle = if (photo) "Colour-square codes always need a password" else null,
        )
        if (locked) {
            RgField(vm.password, { vm.password = it }, "Password", password = true, supporting = "At least ${PasswordRules.MIN_LENGTH} characters")
            StrengthMeter(PasswordRules.strength(vm.password))
            RgField(
                vm.confirm, { vm.confirm = it }, "Confirm password", password = true,
                isError = mismatch, supporting = if (mismatch) "The two passwords do not match" else null,
            )
        } else {
            RgBadge("unprotected — anyone with this code can read it", BadgeKind.Warning)
        }
        if (!photo) {
            ToggleRow(
                if (locked) "Compress before encrypting" else "Compress first", checked = vm.compressFirst,
                onChange = { vm.compressFirst = it; vm.replan() }, subtitle = "Deflate level 9 · about 2.2× to 2.7× on English prose",
            )
        }
        if (locked) Callout("Forget the password and the file is gone for good. There is no hint and no way back.")
    }
}

// ------------------------------------------------------------------ 6. Building
@Composable
fun BuildingScreen(vm: MainViewModel, nav: NavController) {
    val cancel = { vm.cancelBuild(); nav.popBackStack(); Unit }
    BackHandler { cancel() }
    val steps = vm.steps
    RgScaffold(
        title = "Building the code", subtitle = "It is read back before you see it",
        actions = { OutlineButton("Cancel", { cancel() }) },
    ) {
        if (steps.isEmpty()) RgProgressBar() else RgProgressBar(progress = steps.count { it.state == StepState.DONE }.toFloat() / steps.size)
        steps.forEachIndexed { i, s -> StepRow(s, verified = i == steps.lastIndex) }
        CodePreview(null, placeholder = "preview · appears once the code has been read back")
    }
}

// ------------------------------------------------------------------ 7. Code ready
@Composable
fun ReadyScreen(vm: MainViewModel, nav: NavController) {
    val r = vm.ready
    val gate = rememberSaveGate(onDenied = { vm.message = UiMessage("Storage permission was refused, so nothing was saved.", false) })
    if (r == null) {
        LaunchedEffect(Unit) { nav.tab("home") }
        return
    }
    RgScaffold(
        title = "Code ready", subtitle = r.fileName,
        message = vm.message, onDismissMessage = { vm.message = null },
        actions = {
            PrimaryButton(if (r.savedWhere == null) "Save to Pictures/RG CODE" else "Saved", { gate { vm.saveCode() } }, enabled = r.savedWhere == null, icon = Icons.Default.Save)
            OutlineButton("Share as file", { vm.shareCode() }, icon = Icons.Default.Share)
            OutlineButton("Done", { nav.tab("home") })
        },
    ) {
        CodePreview(r.preview)
        RgBadge(r.verified, BadgeKind.Verified)
        if (r.savedWhere != null) RgBadge("saved to ${r.savedWhere} · read back", BadgeKind.Verified)
        if (!r.encrypted) RgBadge("unprotected — anyone with this code can read it", BadgeKind.Warning)
        InfoRow("system", "${r.plan.system.letter} · ${r.plan.system.label}")
        InfoRow("grade", gradeLabel(r.plan))
        InfoRow("size", fmtBytes(r.sizeBytes))
        InfoRow("protection", aeadLabel(r.aead))
        InfoRow("compression", if (r.compressed) "deflate" else "none")
        Callout("Drive, email and WhatsApp Document keep every pixel. Sending it as a photo recompresses it and can destroy the data.", title = "Send it as a file, not a photo")
        if (!r.plan.survivesPhotoShare) Callout(PHOTO_SHARE_WARNING)
    }
}

// ------------------------------------------------------------------ 14. File too big
@Composable
fun TooBigScreen(vm: MainViewModel, nav: NavController) {
    val t = vm.tooBig
    if (t == null) {
        LaunchedEffect(Unit) { nav.tab("home") }
        return
    }
    RgScaffold(
        title = "Does not fit", subtitle = "${fmtBytes(t.rawBytes)} is more than one code can hold", onBack = { nav.popBackStack() },
        actions = {
            PrimaryButton("Choose another file", { nav.tab("create") })
            if (!t.isPhoto && !vm.settings.canvas8k) OutlineButton("Allow the 8K canvas", { nav.navigate("settings") })
        },
    ) {
        RgTile("Needs a bigger canvas", subtitle = "Current maximum: ${fmtBytes(t.maxCapacity)} (${t.maxLabel})", icon = Icons.Default.Warning, accent = RgGold)
        InfoRow("file", "${t.name} · ${fmtBytes(t.rawBytes)}")
        InfoRow("after compression", fmtBytes(t.storedBytes))
        InfoRow("maximum", fmtBytes(t.maxCapacity))
        InfoRow("over by", fmtBytes(maxOf(0L, t.storedBytes - t.maxCapacity)))
        if (t.compressionHelps) RgBadge("try compression first", BadgeKind.Info)
        else RgBadge("compression will not help · already compressed", BadgeKind.Warning)
        Text("Photos, video and most documents are already compressed, so deflate saves only 2 to 5 percent.", style = RgType.Small, color = RgTextDim)
        RgTile("Colour mode — planned", subtitle = "A 24 bits-per-pixel mode is planned for a later version. It is not in this one.", icon = Icons.Default.Palette)
    }
}
