package com.rgcode.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.rgcode.app.R

/*
 * Fonts are the supplied variable files, bundled as res/font/ (names fixed in ASSETS_TO_DROP_IN.md):
 *   bricolage_grotesque.ttf  ibm_plex_sans.ttf  fragment_mono_regular.ttf
 * Variable axes are set explicitly; they need API 26+ (minSdk is 28).
 */
@OptIn(ExperimentalTextApi::class)
val Bricolage = FontFamily(
    Font(R.font.bricolage_grotesque, FontWeight.SemiBold, variationSettings = FontVariation.Settings(FontVariation.weight(600))),
    Font(R.font.bricolage_grotesque, FontWeight.ExtraBold, variationSettings = FontVariation.Settings(FontVariation.weight(800))),
)

@OptIn(ExperimentalTextApi::class)
val PlexSans = FontFamily(
    Font(R.font.ibm_plex_sans, FontWeight.Normal, variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.ibm_plex_sans, FontWeight.Medium, variationSettings = FontVariation.Settings(FontVariation.weight(500))),
    Font(R.font.ibm_plex_sans, FontWeight.SemiBold, variationSettings = FontVariation.Settings(FontVariation.weight(600))),
    Font(R.font.ibm_plex_sans, FontWeight.Bold, variationSettings = FontVariation.Settings(FontVariation.weight(700))),
)

val FragmentMono = FontFamily(Font(R.font.fragment_mono_regular, FontWeight.Normal))

/** Colour is applied where the text is used, so one style works on every surface. */
object RgType {
    val Display = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.ExtraBold, fontSize = 32.sp, lineHeight = 38.sp)
    val Title = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, lineHeight = 30.sp)
    val Headline = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp)
    val Body = TextStyle(fontFamily = PlexSans, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp)
    val BodyStrong = TextStyle(fontFamily = PlexSans, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 24.sp)
    val Small = TextStyle(fontFamily = PlexSans, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp)
    /** 18.5 sp bold counts as "large text" (WCAG: 3:1 needed); the violet fill still measures 4.6:1. */
    val Button = TextStyle(fontFamily = PlexSans, fontWeight = FontWeight.Bold, fontSize = 18.5.sp, lineHeight = 24.sp)
    val Label = TextStyle(fontFamily = FragmentMono, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.4.sp)
    val Mono = TextStyle(fontFamily = FragmentMono, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp)
}

val RgTypography = Typography(
    displayLarge = RgType.Display, displayMedium = RgType.Display, displaySmall = RgType.Title,
    headlineLarge = RgType.Title, headlineMedium = RgType.Title, headlineSmall = RgType.Headline,
    titleLarge = RgType.Title, titleMedium = RgType.Headline, titleSmall = RgType.BodyStrong,
    bodyLarge = RgType.Body, bodyMedium = RgType.Small, bodySmall = RgType.Small,
    labelLarge = RgType.Button, labelMedium = RgType.Label, labelSmall = RgType.Label,
)
