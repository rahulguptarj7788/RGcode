package com.rgcode.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

/** Dark only: there is deliberately no light scheme and no isSystemInDarkTheme() check. */
private val RgScheme = darkColorScheme(
    primary = RgViolet, onPrimary = RgText,
    primaryContainer = RgVioletDeep, onPrimaryContainer = RgText,
    secondary = RgGold, onSecondary = RgVoid,
    tertiary = RgMint, onTertiary = RgVoid,
    error = RgRose, onError = RgVoid,
    background = RgVoid, onBackground = RgText,
    surface = RgSurface, onSurface = RgText,
    surfaceVariant = RgSurfaceHigh, onSurfaceVariant = RgTextDim,
    surfaceContainerLowest = RgVoid, surfaceContainerLow = RgSurface, surfaceContainer = RgSurface,
    surfaceContainerHigh = RgSurfaceHigh, surfaceContainerHighest = RgSurfaceHigh,
    outline = RgTextFaint, outlineVariant = RgSurfaceHigh,
)

@Composable
fun RgTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = RgScheme, typography = RgTypography, content = content)
}
