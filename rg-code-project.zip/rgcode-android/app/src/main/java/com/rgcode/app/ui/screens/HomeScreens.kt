package com.rgcode.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.rgcode.app.MainViewModel
import com.rgcode.app.core.*
import com.rgcode.app.ui.*
import com.rgcode.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ 1. Home
@Composable
fun HomeScreen(vm: MainViewModel, nav: NavController) {
    val dateFormat = remember { SimpleDateFormat("d MMM", Locale.getDefault()) }
    RgScaffold(
        title = "RG CODE", subtitle = "Make and read your own codes",
        message = vm.message, onDismissMessage = { vm.message = null },
        bottomBar = { RgBottomNav("home") { nav.tab(it) } },
        actions = {
            PrimaryButton("Make a code", { nav.tab("create") }, Modifier.heightIn(min = 72.dp), icon = Icons.Default.Add)
            GoldButton("Open a code", { nav.tab("open") }, Modifier.heightIn(min = 72.dp), icon = Icons.Default.FolderOpen)
        },
    ) {
        SectionLabel("Recent")
        if (vm.recents.isEmpty()) Text("Codes you save appear here.", style = RgType.Small, color = RgTextDim)
        vm.recents.forEach { r ->
            RgTile(
                title = r.name, subtitle = "${r.line} · ${dateFormat.format(Date(r.whenMs))}", icon = Icons.Default.Image,
                onClick = { vm.openRecent(r); nav.tab("open") },
            )
        }
    }
}

// ------------------------------------------------------------------ create flow, step 2: what goes in
@Composable
fun CreateScreen(vm: MainViewModel, nav: NavController) {
    RgScaffold(
        title = "What goes in?", subtitle = "The app picks the right system for it",
        message = vm.message, onDismissMessage = { vm.message = null },
        bottomBar = { RgBottomNav("create") { nav.tab(it) } },
    ) {
        RgTile("Paste text", subtitle = "Write it, or paste it", icon = Icons.Default.TextFields,
            onClick = { vm.startCreate(PayloadKind.TEXT); nav.navigate("paste") })
        RgTile("Photo from gallery", subtitle = "Cut into 8 × 8 squares and scattered", icon = Icons.Default.Image,
            onClick = { vm.startCreate(PayloadKind.PHOTO); nav.navigate("pick/photo") })
        RgTile("Any file", subtitle = "PDF, zip, document, anything up to the size limit", icon = Icons.Default.Description,
            onClick = { vm.startCreate(PayloadKind.FILE); nav.navigate("pick/file") })
        Text("Text and files become RG-Code (black and white). Photos become RG-Square (colour squares).", style = RgType.Small, color = RgTextDim)
    }
}

// ------------------------------------------------------------------ 3. Paste box
@Composable
fun PasteScreen(vm: MainViewModel, nav: NavController) {
    var text by remember { mutableStateOf(vm.payload?.takeIf { it.kind == PayloadKind.TEXT }?.let { String(it.bytes, Charsets.UTF_8) } ?: "") }
    val clipboard = LocalClipboardManager.current
    val bytes = remember(text) { text.toByteArray(Charsets.UTF_8).size }
    val estimate = remember(text) { vm.estimate(text) }
    RgScaffold(
        title = "Your text", subtitle = "Type it, or paste it", onBack = { nav.popBackStack() },
        actions = { PrimaryButton("Continue", { vm.proceedToDecide() }, enabled = text.isNotEmpty()) },
    ) {
        RgField(
            value = text, onValueChange = { text = it; vm.setText(it) }, label = "Text",
            placeholder = "Paste it, or type it", singleLine = false, minLines = 8,
        )
        InfoRow("characters", fmtInt(text.length))
        InfoRow("compresses to", if (bytes == 0) "—" else "${fmtInt(estimate)} B (${String.format(Locale.US, "%.2f", bytes.toDouble() / estimate)}×)")
        OutlineButton("Paste from clipboard", {
            clipboard.getText()?.text?.takeIf { it.isNotEmpty() }?.let { text = it; vm.setText(it) }
        }, icon = Icons.Default.ContentPaste)
    }
}

// ------------------------------------------------------------------ 2. Pick from gallery / any file
@Composable
fun PickScreen(vm: MainViewModel, nav: NavController, kind: String) {
    val isPhoto = kind == "photo"
    val k = if (isPhoto) PayloadKind.PHOTO else PayloadKind.FILE
    // Photo Picker and the system document picker need no storage permission.
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) vm.pickForCreate(uri, k) }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.pickForCreate(uri, k) }
    val choose = {
        if (isPhoto) photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        else docPicker.launch(arrayOf("*/*"))
    }
    val p = vm.payload?.takeIf { it.kind == k }
    RgScaffold(
        title = if (isPhoto) "Choose a photo" else "Choose a file", subtitle = "From your gallery or files",
        message = vm.message, onDismissMessage = { vm.message = null }, onBack = { nav.popBackStack() },
        actions = {
            if (p == null) {
                PrimaryButton(if (isPhoto) "Choose a photo" else "Choose a file", { choose() }, icon = Icons.Default.Image)
                if (isPhoto) OutlineButton("Browse files instead", { docPicker.launch(arrayOf("image/*")) })
            } else {
                PrimaryButton("Continue", { vm.proceedToDecide() })
                OutlineButton("Choose another", { choose() })
            }
        },
    ) {
        if (p != null) {
            RgTile(p.name, subtitle = "${fmtBytes(p.bytes.size)} · ${p.mime ?: "unknown type"}", icon = if (isPhoto) Icons.Default.Image else Icons.Default.Description)
            when (val r = vm.planResult) {
                is PlanResult.Fits -> {
                    RgBadge(if (r.plan.comfortable) "fits comfortably" else "fits · nearly full", if (r.plan.comfortable) BadgeKind.Verified else BadgeKind.Warning)
                    InfoRow("capacity", "${fmtInt(r.plan.capacity)} B")
                    InfoRow("your data", "${fmtInt(r.plan.stored)} B")
                }
                is PlanResult.TooBig -> RgBadge("too big for one code · ${fmtBytes(r.stored)} of ${fmtBytes(r.maxCapacity)} possible", BadgeKind.Warning)
                null -> Unit
            }
        }
        if (isPhoto) Text("Photos always get a password: a colour-square code has no unprotected mode.", style = RgType.Small, color = RgTextDim)
        Callout("The file stays on this phone. Nothing is uploaded anywhere.")
    }
}

// ------------------------------------------------------------------ First run
@Composable
fun FirstRunScreen(vm: MainViewModel, nav: NavController) {
    RgScaffold(
        title = "Welcome to RG CODE", subtitle = "Three things to know",
        actions = {
            PrimaryButton("Got it", {
                vm.markFirstRunDone()
                nav.navigate("home") { popUpTo("first") { inclusive = true } }
            })
        },
    ) {
        RgTile("Codes are read from your gallery", subtitle = "Pick the PNG and the app reads it straight from the file.", icon = Icons.Default.Image)
        RgTile("Your password is the only key", subtitle = "Nothing is uploaded and nothing is recoverable. Forget it and the file is gone.", icon = Icons.Default.Lock)
        RgTile("Send codes as files", subtitle = "A photo-share recompresses the image and destroys small pixels. Use Drive, email, or WhatsApp Document.", icon = Icons.Default.Share)
    }
}
