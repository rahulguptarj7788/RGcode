package com.rgcode.app.ui.theme

import androidx.compose.ui.graphics.Color

/*
 * The only colours in the app. Measured contrast (WCAG 2.x):
 *   RgText      16.6 on void   RgTextDim  7.7 on void / 6.0 on surface-high
 *   RgTextFaint  4.1 on void   -> NEVER for text (fails 4.5:1); borders, dividers and "to do" dots only
 *   RgVioletBright 5.6 on void, 4.4 on surface-high -> icons and links on void/surface; not body text on surface-high
 *   RgText on RgViolet button 4.6;  RgVoid on RgGold 8.8
 * Semantics: gold = the single irreversible action + warnings; mint = verified states ONLY; rose = errors ONLY.
 */
val RgVoid = Color(0xFF0D0817)           // app background
val RgSurface = Color(0xFF1A1229)        // cards, tiles
val RgSurfaceHigh = Color(0xFF2B1D42)    // inputs, raised rows
val RgViolet = Color(0xFF7B3FF2)         // primary buttons, active
val RgVioletBright = Color(0xFF9E6BFF)   // icons, links, focus
val RgVioletDeep = Color(0xFF4A1E96)     // gradient end
val RgGold = Color(0xFFD9A441)
val RgMint = Color(0xFF4FD1A5)
val RgRose = Color(0xFFFF7A8A)
val RgText = Color(0xFFEFE9F7)           // never pure white
val RgTextDim = Color(0xFFA99BC4)
val RgTextFaint = Color(0xFF7A6C94)
