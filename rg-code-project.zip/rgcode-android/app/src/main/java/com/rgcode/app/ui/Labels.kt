package com.rgcode.app.ui

import com.rgcode.app.core.Aead
import com.rgcode.app.core.Plan
import com.rgcode.app.core.SystemId

fun aeadLabel(a: Aead?): String = when (a) {
    Aead.CHACHA20_POLY1305 -> "ChaCha20-Poly1305"
    Aead.AES_GCM -> "AES-256-GCM"
    null -> "none"
}

fun shapeLabel(p: Plan): String = when (p.system) {
    SystemId.A -> "square (standard QR)"
    SystemId.G -> "96 × 174 squares of 8 px"
    else -> p.shape?.label ?: "—"
}

fun gradeLabel(p: Plan): String = when {
    p.system == SystemId.G -> "8 px squares"
    p.px > 0 -> "${p.grade} · ${p.px} px"
    else -> "—"
}
