package com.rgcode.app.core

import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.LuminanceSource
import com.google.zxing.MultiFormatReader
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.qrcode.encoder.Encoder
import java.util.Base64

/**
 * Standard QR tier (ISO/IEC 18004), level L, byte mode, 4-module quiet zone. Plain UTF-8 text is stored
 * as text so any phone can read it. Everything else is "RGQ1:" + base64(RG-Code stream).
 * Limits: text <= 2,953 bytes; stream <= 2,211 bytes (base64 length <= 2,953 - 5).
 */
object QrTier {
    const val BYTE_MAX = 2953
    const val PREFIX = "RGQ1:"
    const val STREAM_MAX = 3 * ((BYTE_MAX - 5) / 4)      // 2,211

    fun isPlainText(data: ByteArray): String? {
        val s = try {
            Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(data)).toString()
        } catch (e: java.nio.charset.CharacterCodingException) { return null }
        return if (s.startsWith(PREFIX) || s.any { it.code == 0 }) null else s
    }

    /** Content string for the QR, or null if it does not fit. */
    fun content(data: ByteArray, password: String?, compress: Boolean, aead: Aead): String? {
        if (password == null) isPlainText(data)?.let { return if (data.size <= BYTE_MAX) it else null }
        val stream = RgCode.buildStream(data, password, compress, aead)
        return if (stream.size > STREAM_MAX) null else PREFIX + Base64.getEncoder().encodeToString(stream)
    }

    /** Draws the QR; [makeSink] receives the square image size in pixels. */
    fun render(text: String, makeSink: (Int) -> RowSink): Int {
        val hints = mapOf(EncodeHintType.CHARACTER_SET to "UTF-8")
        val matrix = Encoder.encode(text, ErrorCorrectionLevel.L, hints).matrix
        val modules = matrix.width + 2 * RgCode.QUIET
        val scale = maxOf(1, 1480 / modules)
        val size = modules * scale
        val sink = makeSink(size)
        val row = IntArray(size)
        for (my in 0 until modules) {
            for (mx in 0 until modules) {
                val x = mx - RgCode.QUIET; val y = my - RgCode.QUIET
                val on = x in 0 until matrix.width && y in 0 until matrix.height && matrix.get(x, y).toInt() == 1
                java.util.Arrays.fill(row, mx * scale, mx * scale + scale, if (on) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
            }
            for (t in 0 until scale) sink.writeRow(my * scale + t, row)
        }
        return size
    }

    private class Lum(w: Int, h: Int, val data: ByteArray) : LuminanceSource(w, h) {
        override fun getRow(y: Int, row: ByteArray?): ByteArray {
            val r = if (row == null || row.size < width) ByteArray(width) else row
            System.arraycopy(data, y * width, r, 0, width)
            return r
        }
        override fun getMatrix(): ByteArray = data
    }

    /** Reads a standard QR. Down-scales (QR path only) when the image is large. Returns the text or null. */
    fun read(src: PixelSource): String? {
        val f = maxOf(1, (maxOf(src.width, src.height) + 1499) / 1500)
        val w = src.width / f; val h = src.height / f
        if (w < 21 || h < 21) return null
        val lum = ByteArray(w * h)
        val row = IntArray(src.width)
        val acc = IntArray(w)
        for (y in 0 until h) {
            java.util.Arrays.fill(acc, 0)
            for (dy in 0 until f) {
                src.readRow(y * f + dy, row)
                for (x in 0 until w) for (dx in 0 until f) {
                    val p = row[x * f + dx]
                    acc[x] += (299 * ((p shr 16) and 255) + 587 * ((p shr 8) and 255) + 114 * (p and 255)) / 1000
                }
            }
            for (x in 0 until w) lum[y * w + x] = (acc[x] / (f * f)).toByte()
        }
        val source = Lum(w, h, lum)
        val hints = mapOf(
            DecodeHintType.TRY_HARDER to true,
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
        )
        for (binarizer in listOf<(LuminanceSource) -> com.google.zxing.Binarizer>(::HybridBinarizer, ::GlobalHistogramBinarizer)) {
            try {
                return MultiFormatReader().decode(BinaryBitmap(binarizer(source)), hints).text
            } catch (e: com.google.zxing.ReaderException) { /* try the next binarizer */ }
        }
        return null
    }

    /** Text read from a QR -> original bytes, or a stream to open. */
    fun parseContent(text: String): Pair<ByteArray?, ParsedStream?> {
        if (!text.startsWith(PREFIX)) return text.toByteArray(Charsets.UTF_8) to null
        val raw = try { Base64.getDecoder().decode(text.substring(PREFIX.length)) } catch (e: IllegalArgumentException) { throw NotACodeException("The QR content is damaged.") }
        val parsed = RgCode.parseStream(raw) ?: throw NotACodeException("This QR is not an RG CODE stream.")
        return null to parsed
    }
}
