package com.rgcode.app.data

import java.io.InputStream

/** Android-free helpers, so they can be unit-tested on the JVM. */
object Pure {
    private fun fill(s: InputStream, buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) {
            val r = s.read(buf, n, buf.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    /** True only if both streams have exactly the same bytes (this is the save read-back check). */
    fun sameBytes(a: InputStream, b: InputStream): Boolean {
        val x = ByteArray(65536)
        val y = ByteArray(65536)
        while (true) {
            val n = fill(a, x)
            val m = fill(b, y)
            if (n != m) return false
            if (n == 0) return true
            for (i in 0 until n) if (x[i] != y[i]) return false
        }
    }

    /** A display name that is safe for MediaStore and any file system. */
    fun safeFileName(raw: String, fallback: String, ext: String): String {
        var base = raw.substringAfterLast('/').substringAfterLast('\\')
            .filter { it.code >= 32 && it !in "<>:\"|?*" }.trim().trim('.')
        if (base.isEmpty()) base = fallback
        val want = ".$ext"
        if (!base.lowercase().endsWith(want)) base = base.substringBeforeLast('.', base) + want
        return base.take(100)
    }

    class Recent(val whenMs: Long, val name: String, val line: String, val uri: String)

    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')

    fun recentsEncode(list: List<Recent>): String =
        list.joinToString("\n") { "${it.whenMs}\t${clean(it.uri)}\t${clean(it.name)}\t${clean(it.line)}" }

    fun recentsDecode(s: String): List<Recent> = s.lines().mapNotNull { l ->
        val p = l.split('\t')
        val t = p.getOrNull(0)?.toLongOrNull()
        if (p.size == 4 && t != null) Recent(t, p[2], p[3], p[1]) else null
    }

    /** Newest first, one entry per uri, at most [max]. */
    fun recentsAdd(list: List<Recent>, r: Recent, max: Int = 8): List<Recent> =
        (listOf(r) + list.filter { it.uri != r.uri }).take(max)
}
