package com.rgcode.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorSpace
import android.net.Uri
import android.provider.OpenableColumns
import com.rgcode.app.core.CapacityException
import com.rgcode.app.core.NotACodeException
import com.rgcode.app.core.PixelSource
import com.rgcode.app.core.RowSink
import java.io.File
import java.io.IOException

/** Row-wise view of a Bitmap; nothing is copied or resampled. */
class BitmapPixels(private val bmp: Bitmap) : PixelSource {
    override val width get() = bmp.width
    override val height get() = bmp.height
    override fun readRow(y: Int, out: IntArray) = bmp.getPixels(out, 0, bmp.width, 0, y, bmp.width, 1)
}

/** Draws rendered rows straight into a Bitmap, one pixel row at a time. */
class BitmapSink(private val bmp: Bitmap) : RowSink {
    override fun writeRow(y: Int, argb: IntArray) = bmp.setPixels(argb, 0, bmp.width, 0, y, bmp.width, 1)
}

class PickedFile(val name: String, val size: Long, val mime: String?, val bytes: ByteArray?)

object ImageIO {
    /** 8K canvas = 33.2 M pixels; anything beyond this is refused before decoding. */
    const val MAX_PIXELS = 40_000_000L

    private fun decodeOptions() = BitmapFactory.Options().apply {
        inScaled = false                               // no density scaling, ever
        inPreferredConfig = Bitmap.Config.ARGB_8888
        inDither = false
        inMutable = false
        inPreferredColorSpace = ColorSpace.get(ColorSpace.Named.SRGB)
    }

    private fun check(o: BitmapFactory.Options) {
        if (o.outWidth <= 0 || o.outHeight <= 0) throw NotACodeException("This file is not an image the phone can read.")
        if (o.outWidth.toLong() * o.outHeight > MAX_PIXELS) throw CapacityException("This image is too large to open (${o.outWidth} × ${o.outHeight} px).")
    }

    private fun decode(open: () -> java.io.InputStream?): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        (open() ?: throw IOException("Cannot open the file.")).use { BitmapFactory.decodeStream(it, null, bounds) }
        check(bounds)
        return try {
            (open() ?: throw IOException("Cannot open the file.")).use { BitmapFactory.decodeStream(it, null, decodeOptions()) }
                ?: throw NotACodeException("This file is not an image the phone can read.")
        } catch (e: OutOfMemoryError) {
            throw CapacityException("Not enough memory to open this image.")
        }
    }

    /** Gallery / document uri -> Bitmap at its native size and ARGB_8888. Caller must recycle(). */
    fun load(ctx: Context, uri: Uri): Bitmap = decode { ctx.contentResolver.openInputStream(uri) }

    fun loadFile(file: File): Bitmap = decode { file.inputStream() }

    /** Opaque ARGB canvas (no alpha channel in the PNG, so it stays small). */
    fun newCanvas(w: Int, h: Int): Bitmap = try {
        Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.setHasAlpha(false) }
    } catch (e: OutOfMemoryError) {
        throw CapacityException("Not enough memory for a $w × $h canvas. Choose the 4K canvas in Settings.")
    }

    /** Lossless PNG only. There is deliberately no JPEG path anywhere in this app. */
    fun writePng(bmp: Bitmap, file: File) {
        file.parentFile?.mkdirs()
        val ok = file.outputStream().buffered().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (!ok) throw IOException("The PNG could not be written.")
    }

    /** Name and size without reading the content. */
    fun describe(ctx: Context, uri: Uri): Triple<String, Long, String?> {
        var name = "file"
        var size = -1L
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { c.getString(it)?.let { n -> name = n } }
                c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 && !c.isNull(it) }?.let { size = c.getLong(it) }
            }
        }
        return Triple(name, size, ctx.contentResolver.getType(uri))
    }

    /** Reads a picked file fully unless it is larger than [limit] (then bytes = null and size is reported). */
    fun readPicked(ctx: Context, uri: Uri, limit: Int): PickedFile {
        val (name, declared, mime) = describe(ctx, uri)
        if (declared > limit) return PickedFile(name, declared, mime, null)
        val buf = ctx.contentResolver.openInputStream(uri)?.use { s ->
            val out = java.io.ByteArrayOutputStream()
            val chunk = ByteArray(65536)
            while (out.size() <= limit) {
                val n = s.read(chunk)
                if (n < 0) break
                out.write(chunk, 0, n)
            }
            out.toByteArray()
        } ?: throw IOException("Cannot open the file.")
        return if (buf.size > limit) PickedFile(name, buf.size.toLong(), mime, null) else PickedFile(name, buf.size.toLong(), mime, buf)
    }
}
