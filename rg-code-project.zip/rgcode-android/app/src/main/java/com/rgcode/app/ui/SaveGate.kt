package com.rgcode.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.rgcode.app.data.Exporter

/**
 * Wraps a save action. On API 29+ it just runs the action (no permission exists or is requested).
 * On API 28 only, it asks for WRITE_EXTERNAL_STORAGE first and runs the action once granted.
 */
@Composable
fun rememberSaveGate(onDenied: () -> Unit): (() -> Unit) -> Unit {
    val ctx = LocalContext.current
    var waiting by remember { mutableStateOf<(() -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val action = waiting
        waiting = null
        if (granted) action?.invoke() else onDenied()
    }
    return { action ->
        if (Exporter.needsLegacyPermission(ctx)) {
            waiting = action
            launcher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else action()
    }
}
