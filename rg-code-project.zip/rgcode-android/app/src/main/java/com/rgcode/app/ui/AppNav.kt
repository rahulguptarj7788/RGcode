package com.rgcode.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rgcode.app.MainViewModel
import com.rgcode.app.ui.screens.*

/** Bottom-nav jump: always lands on top of Home, never stacks copies. */
fun NavController.tab(route: String) {
    navigate(route) {
        popUpTo("home")
        launchSingleTop = true
    }
}

/**
 * Routes: first, home, create, paste, pick/{kind}, decide, password, building, ready, open,
 * restored, text, qr, error, settings, about, toobig.
 * The ViewModel emits: decide, toobig, building (pushed), and ready, error, restored, text, qr, open
 * (shown on top of Home, so Back always returns to Home).
 */
@Composable
fun AppNav(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    LaunchedEffect(Unit) {
        vm.events.collect { route ->
            when (route) {
                "decide", "toobig", "building" -> nav.navigate(route) { launchSingleTop = true }
                else -> nav.navigate(route) { popUpTo("home"); launchSingleTop = true }
            }
        }
    }
    NavHost(nav, startDestination = if (vm.firstRunDone) "home" else "first") {
        composable("first") { FirstRunScreen(vm, nav) }
        composable("home") { HomeScreen(vm, nav) }
        composable("create") { CreateScreen(vm, nav) }
        composable("paste") { PasteScreen(vm, nav) }
        composable("pick/{kind}") { PickScreen(vm, nav, it.arguments?.getString("kind") ?: "file") }
        composable("decide") { DecideScreen(vm, nav) }
        composable("password") { PasswordScreen(vm, nav) }
        composable("building") { BuildingScreen(vm, nav) }
        composable("ready") { ReadyScreen(vm, nav) }
        composable("toobig") { TooBigScreen(vm, nav) }
        composable("open") { OpenScreen(vm, nav) }
        composable("restored") { RestoredScreen(vm, nav) }
        composable("text") { TextResultScreen(vm, nav, qr = false) }
        composable("qr") { TextResultScreen(vm, nav, qr = true) }
        composable("error") { ErrorScreen(vm, nav) }
        composable("settings") { SettingsScreen(vm, nav) }
        composable("about") { AboutScreen(vm, nav) }
    }
}
