package com.rgcode.app.core

class VerifyFailedException(m: String) : RgException(m)

/** The sealed (compressed + encrypted) content of a code, before any pixel is drawn. */
sealed interface Content {
    class Stream(val bytes: ByteArray) : Content        // RG-Code stream, systems B-F
    class Qr(val text: String) : Content                // standard QR text, system A
    class Square(val pix: IntArray) : Content           // 768 x 1392 ARGB, system G
}

/** Android-free build pipeline: seal -> draw -> read back with the real decoder. */
object CodeBuilder {
    /** Compress (if it helps) and encrypt. This is the slow step when a password is used (PBKDF2). */
    fun seal(plan: Plan, data: ByteArray, password: String?, compress: Boolean, aead: Aead): Content = when (plan.system) {
        SystemId.A -> Content.Qr(QrTier.content(data, password, compress, aead) ?: throw CapacityException("This does not fit one standard QR."))
        SystemId.G -> Content.Square(RgSquare.encodeFile(data, password ?: throw UnsupportedException("A colour-square code always needs a password.")))
        else -> Content.Stream(RgCode.buildStream(data, password, compress, aead))
    }

    /** Draws row by row into whatever [canvas] returns; returns the image size. */
    fun draw(plan: Plan, content: Content, canvas: (Int, Int) -> RowSink): Pair<Int, Int> = when (content) {
        is Content.Qr -> {
            val size = QrTier.render(content.text) { s -> canvas(s, s) }
            size to size
        }
        is Content.Square -> {
            val sink = canvas(RgSquare.IMG_W, RgSquare.IMG_H)
            val row = IntArray(RgSquare.IMG_W)
            for (y in 0 until RgSquare.IMG_H) {
                System.arraycopy(content.pix, y * RgSquare.IMG_W, row, 0, RgSquare.IMG_W)
                sink.writeRow(y, row)
            }
            RgSquare.IMG_W to RgSquare.IMG_H
        }
        is Content.Stream -> {
            val shape = plan.shape ?: throw UnsupportedException("No shape for this plan.")
            val (w, h) = RgCode.gridSize(shape, plan.px)
            RgCode.render(content.bytes, w, h, plan.px, canvas(plan.imageW, plan.imageH))
            plan.imageW to plan.imageH
        }
    }

    /**
     * Reads the finished image with the real decoder and compares with the original.
     * Returns the badge text. Any difference throws: a code is never reported as ready unless it reads back.
     */
    fun readBack(src: PixelSource, plan: Plan, original: ByteArray, password: String?): String {
        val got: ByteArray
        val how: String
        when (plan.system) {
            SystemId.A -> {
                val text = QrTier.read(src) ?: throw VerifyFailedException("The finished QR could not be read back.")
                val (plain, parsed) = QrTier.parseContent(text)
                got = plain ?: RgCode.open(parsed!!, password)
                how = "QR read back"
            }
            SystemId.G -> {
                got = RgSquare.decodeFile(src, password ?: throw UnsupportedException("A colour-square code always needs a password."))
                how = "authentication tag verified"
            }
            else -> {
                val parsed = RgCode.read(src) ?: throw VerifyFailedException("The finished code could not be read back.")
                got = RgCode.open(parsed, password)
                how = "magic + CRC verified"
            }
        }
        if (!got.contentEquals(original)) throw VerifyFailedException("The code read back differs from the original. Nothing was saved.")
        return "$how · byte-identical"
    }
}

object PasswordRules {
    const val MIN_LENGTH = 8

    /** 0..3, drawn as three segments. */
    fun strength(pw: String): Int {
        if (pw.isEmpty()) return 0
        val classes = listOf(pw.any { it.isLowerCase() }, pw.any { it.isUpperCase() }, pw.any { it.isDigit() },
            pw.any { !it.isLetterOrDigit() }).count { it }
        return (if (pw.length >= MIN_LENGTH) 1 else 0) + (if (pw.length >= 12) 1 else 0) + (if (classes >= 3) 1 else 0)
    }

    fun valid(pw: String, confirm: String) = pw.length >= MIN_LENGTH && pw == confirm
}
