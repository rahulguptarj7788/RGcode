package com.rgcode.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.rgcode.app.MainViewModel
import com.rgcode.app.Stage
import com.rgcode.app.StepState
import com.rgcode.app.StepUi
import com.rgcode.app.UiMessage
import com.rgcode.app.ui.*
import com.rgcode.app.ui.theme.*

// ------------------------------------------------------------------ 8. Open a code
@Composable
fun OpenScreen(vm: MainViewModel, nav: NavController) {
    // Gallery via the Photo Picker (no permission); the document picker is the fallback.
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) vm.openUri(uri) }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.openUri(uri) }
    var password by remember { mutableStateOf("") }
    val stage = vm.openStage
    LaunchedEffect(Unit) { if (vm.openStage == Stage.RESTORED || vm.openStage == Stage.FAILED) vm.resetOpen() }
    RgScaffold(
        title = "Open a code", subtitle = "Pick the PNG from your gallery",
        message = vm.message, onDismissMessage = { vm.message = null },
        bottomBar = { RgBottomNav("open") { nav.tab(it) } },
        actions = {
            when (stage) {
                Stage.NEED_PASSWORD -> {
                    PrimaryButton("Open", { vm.submitPassword(password); password = "" }, enabled = password.isNotEmpty(), icon = Icons.Default.LockOpen)
                    OutlineButton("Cancel", { vm.resetOpen() })
                }
                Stage.BUSY -> OutlineButton("Cancel", { vm.resetOpen() })
                else -> {
                    GoldButton("Pick from gallery", { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, Modifier.heightIn(min = 72.dp), icon = Icons.Default.Image)
                    OutlineButton("Browse files", { docPicker.launch(arrayOf("image/*")) })
                }
            }
        },
    ) {
        if (stage == Stage.IDLE || stage == Stage.RESTORED || stage == Stage.FAILED) {
            Text("Nothing to enter. The app reads the size, the grade and the orientation from the image itself.", style = RgType.Body, color = RgTextDim)
            if (vm.recents.isNotEmpty()) {
                SectionLabel("Recent")
                vm.recents.forEach { r -> RgTile(r.name, subtitle = r.line, icon = Icons.Default.Image, onClick = { vm.openRecent(r) }) }
            }
        } else {
            vm.openLog.forEach { StepRow(StepUi(it, StepState.DONE)) }
            if (stage == Stage.BUSY) StepRow(StepUi("working…", StepState.RUNNING))
            if (stage == Stage.NEED_PASSWORD) {
                RgBadge("This code needs a password", BadgeKind.Info)
                RgField(password, { password = it }, "Password", password = true)
            }
        }
    }
}

// ------------------------------------------------------------------ 9. Restored
@Composable
fun RestoredScreen(vm: MainViewModel, nav: NavController) {
    val r = vm.restored
    val gate = rememberSaveGate(onDenied = { vm.message = UiMessage("Storage permission was refused, so nothing was saved.", false) })
    if (r == null) {
        LaunchedEffect(Unit) { nav.tab("home") }
        return
    }
    RgScaffold(
        title = "Restored", subtitle = "${r.info.ext.uppercase()} · ${fmtBytes(r.bytes.size)}",
        message = vm.message, onDismissMessage = { vm.message = null },
        actions = {
            PrimaryButton(if (r.savedWhere == null) "Save original" else "Saved", { gate { vm.saveRestored() } }, enabled = r.savedWhere == null, icon = Icons.Default.Save)
            OutlineButton("Open another code", { vm.resetOpen(); nav.tab("open") })
        },
    ) {
        if (r.preview != null) CodePreview(r.preview, smooth = true)
        else RgTile("File restored", subtitle = "${r.info.ext.uppercase()} · ${fmtBytes(r.bytes.size)}", icon = Icons.Default.Description)
        // Only what the format actually verified: no claim of "byte-identical" without an original to compare.
        RgBadge(r.integrity, BadgeKind.Verified)
        if (r.savedWhere != null) RgBadge("saved to ${r.savedWhere} · read back", BadgeKind.Verified)
        InfoRow("system", r.system)
        InfoRow("protection", aeadLabel(r.aead))
        InfoRow("compression", if (r.compressed) "deflate" else "none")
        InfoRow("size", fmtBytes(r.bytes.size))
        InfoRow("type (guessed)", r.info.mime)
        Text("A code does not store the file name. The file is saved as restored.${r.info.ext} in Downloads.", style = RgType.Small, color = RgTextDim)
    }
}

// ------------------------------------------------------------------ 13. Text result and standard QR result
@Composable
fun TextResultScreen(vm: MainViewModel, nav: NavController, qr: Boolean) {
    val r = vm.restored
    val gate = rememberSaveGate(onDenied = { vm.message = UiMessage("Storage permission was refused, so nothing was saved.", false) })
    val text = r?.text
    if (r == null || text == null) {
        LaunchedEffect(Unit) { nav.tab("home") }
        return
    }
    val isLink = text.trim().let { it.startsWith("http://") || it.startsWith("https://") }
    RgScaffold(
        title = if (qr) "Standard QR" else "Restored text", subtitle = "${fmtInt(text.length)} characters",
        message = vm.message, onDismissMessage = { vm.message = null },
        actions = {
            PrimaryButton("Copy text", { if (vm.copyText()) vm.message = UiMessage("Copied to the clipboard", true) }, icon = Icons.Default.ContentCopy)
            OutlineButton("Save as .txt", { gate { vm.saveTextFile() } })
            OutlineButton("Open another code", { vm.resetOpen(); nav.tab("open") })
        },
    ) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(RgSurface).padding(14.dp)) {
            SelectionContainer { Text(text, style = RgType.Mono, color = RgText) }
        }
        // A plain QR has no checksum in its format, so it is shown as information, never as "verified".
        RgBadge(r.integrity, if (qr) BadgeKind.Info else BadgeKind.Verified)
        InfoRow("characters", fmtInt(text.length))
        InfoRow("bytes", fmtInt(r.bytes.size))
        InfoRow("system", r.system)
        if (isLink) Callout("This holds a web address. RG CODE never opens links for you; copy it if you want to use it.")
    }
}

// ------------------------------------------------------------------ 10. Error
@Composable
fun ErrorScreen(vm: MainViewModel, nav: NavController) {
    val f = vm.failure
    if (f == null) {
        LaunchedEffect(Unit) { nav.tab("home") }
        return
    }
    val fromOpen = vm.openStage == Stage.FAILED
    RgScaffold(
        title = if (fromOpen) "Could not open" else "Could not finish", subtitle = "Nothing was changed on your phone",
        actions = {
            if (f.canRetryPassword) PrimaryButton("Try another password", { vm.retryPassword() }, icon = Icons.Default.LockOpen)
            if (fromOpen) OutlineButton("Pick a different file", { vm.resetOpen(); nav.tab("open") })
            else OutlineButton("Back to start", { nav.tab("home") })
        },
    ) {
        RgBadge(f.title, BadgeKind.Error)
        RgTile("What happened", subtitle = f.reason, icon = Icons.Default.Error, accent = RgRose)
        RgTile("Was the image re-saved?", subtitle = f.hint, icon = Icons.Default.Info)
    }
}
