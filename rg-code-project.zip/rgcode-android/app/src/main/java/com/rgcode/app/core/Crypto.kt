package com.rgcode.app.core

import java.security.GeneralSecurityException
import java.util.stream.Collectors
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Failures every layer can show to the user verbatim. */
sealed class RgException(message: String) : Exception(message)
class NotACodeException(m: String = "No RG CODE found in this image.") : RgException(m)
class FileDamagedException(m: String = "File damaged: the CRC does not match.") : RgException(m)
class WrongPasswordException(val needsPassword: Boolean, m: String) : RgException(m)
class UnsupportedException(m: String) : RgException(m)
class CapacityException(m: String) : RgException(m)

enum class Aead { AES_GCM, CHACHA20_POLY1305 }

object Crypto {
    const val PBKDF2_ITERATIONS = 200_000
    const val TAG_LEN = 16

    /**
     * PBKDF2-HMAC-SHA256 on top of javax.crypto.Mac, password as UTF-8.
     * Implemented here (not SecretKeyFactory) so the password encoding is identical to the Python
     * reference on every Android version; blocks are independent and run in parallel.
     */
    fun pbkdf2Sha256(password: String, salt: ByteArray, iterations: Int, dkLen: Int): ByteArray {
        require(password.isNotEmpty()) { "empty password" }
        val pw = password.toByteArray(Charsets.UTF_8)
        val blocks = (dkLen + 31) / 32
        fun block(index: Int): ByteArray {
            val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(pw, "HmacSHA256")) }
            mac.update(salt)
            mac.update(byteArrayOf((index ushr 24).toByte(), (index ushr 16).toByte(), (index ushr 8).toByte(), index.toByte()))
            var u = mac.doFinal()
            val t = u.copyOf()
            for (i in 1 until iterations) {
                u = mac.doFinal(u)
                for (k in t.indices) t[k] = (t[k].toInt() xor u[k].toInt()).toByte()
            }
            return t
        }
        val parts = (1..blocks).toList().parallelStream().map { block(it) }.collect(Collectors.toList())
        val out = ByteArray(dkLen)
        parts.forEachIndexed { i, p -> System.arraycopy(p, 0, out, i * 32, minOf(32, dkLen - i * 32)) }
        return out
    }

    private fun cipher(kind: Aead, mode: Int, key: ByteArray, nonce: ByteArray, aad: ByteArray): Cipher {
        val c = when (kind) {
            Aead.AES_GCM -> Cipher.getInstance("AES/GCM/NoPadding").also {
                it.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            }
            Aead.CHACHA20_POLY1305 -> Cipher.getInstance("ChaCha20-Poly1305").also {
                it.init(mode, SecretKeySpec(key, "ChaCha20"), IvParameterSpec(nonce))
            }
        }
        c.updateAAD(aad)
        return c
    }

    /** Returns ciphertext || 16-byte tag, same layout as the Python reference. */
    fun seal(kind: Aead, key: ByteArray, nonce: ByteArray, aad: ByteArray, plain: ByteArray): ByteArray =
        cipher(kind, Cipher.ENCRYPT_MODE, key, nonce, aad).doFinal(plain)

    /** Throws [WrongPasswordException] when the tag does not verify. */
    fun open(kind: Aead, key: ByteArray, nonce: ByteArray, aad: ByteArray, sealed: ByteArray): ByteArray =
        try {
            cipher(kind, Cipher.DECRYPT_MODE, key, nonce, aad).doFinal(sealed)
        } catch (e: GeneralSecurityException) {
            throw WrongPasswordException(false, "Wrong password, or the data was changed.")
        }

    /** CRC-16/CCITT (poly 0x1021, init 0xFFFF, no reflection) = Python binascii.crc_hqx(data, 0xFFFF). */
    fun crc16(data: ByteArray, off: Int = 0, len: Int = data.size - off): Int {
        var crc = 0xFFFF
        for (i in off until off + len) {
            crc = crc xor ((data[i].toInt() and 0xFF) shl 8)
            repeat(8) { crc = if (crc and 0x8000 != 0) (crc shl 1) xor 0x1021 else crc shl 1 }
            crc = crc and 0xFFFF
        }
        return crc
    }
}

/** ChaCha20 keystream (RFC 8439, block counter starts at 0), endless. */
class ChaCha20Stream(key: ByteArray, nonce: ByteArray) {
    private val st = IntArray(16)
    private val work = IntArray(16)
    private val block = ByteArray(64)
    private var pos = 64
    private var counter = 0

    init {
        require(key.size == 32 && nonce.size == 12)
        st[0] = 0x61707865; st[1] = 0x3320646e; st[2] = 0x79622d32; st[3] = 0x6b206574
        for (i in 0 until 8) st[4 + i] = le32(key, i * 4)
        for (i in 0 until 3) st[13 + i] = le32(nonce, i * 4)
    }

    private fun le32(b: ByteArray, o: Int) =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)

    private fun qr(a: Int, b: Int, c: Int, d: Int) {
        val x = work
        x[a] += x[b]; x[d] = Integer.rotateLeft(x[d] xor x[a], 16)
        x[c] += x[d]; x[b] = Integer.rotateLeft(x[b] xor x[c], 12)
        x[a] += x[b]; x[d] = Integer.rotateLeft(x[d] xor x[a], 8)
        x[c] += x[d]; x[b] = Integer.rotateLeft(x[b] xor x[c], 7)
    }

    private fun refill() {
        st[12] = counter++
        System.arraycopy(st, 0, work, 0, 16)
        repeat(10) {
            qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15)
            qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14)
        }
        for (i in 0 until 16) {
            val v = work[i] + st[i]
            block[i * 4] = v.toByte(); block[i * 4 + 1] = (v ushr 8).toByte()
            block[i * 4 + 2] = (v ushr 16).toByte(); block[i * 4 + 3] = (v ushr 24).toByte()
        }
        pos = 0
    }

    fun nextByte(): Int {
        if (pos == 64) refill()
        return block[pos++].toInt() and 0xFF
    }

    fun nextBytes(n: Int) = ByteArray(n) { nextByte().toByte() }

    /** Next 4 stream bytes as an unsigned little-endian 32-bit value (Python struct "<I"). */
    fun nextU32(): Long {
        val b0 = nextByte().toLong(); val b1 = nextByte().toLong()
        val b2 = nextByte().toLong(); val b3 = nextByte().toLong()
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }
}
