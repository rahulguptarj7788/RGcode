package com.rgcode.app.data

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.InputStream

/** Something that can be opened as a fresh stream any number of times (needed for write + read-back). */
interface ByteSrc {
    val length: Long
    fun open(): InputStream
}

class FileSrc(private val file: File) : ByteSrc {
    override val length get() = file.length()
    override fun open(): InputStream = file.inputStream()
}

class ArraySrc(private val bytes: ByteArray) : ByteSrc {
    override val length get() = bytes.size.toLong()
    override fun open(): InputStream = bytes.inputStream()
}

sealed interface SaveResult {
    /** Written AND read back byte-for-byte. [where] is a human-readable location. */
    class Saved(val uri: Uri, val where: String, val bytes: Long) : SaveResult
    /** The stored bytes differ from what was written. The bad copy has been removed. */
    class Mismatch(val detail: String) : SaveResult
    class Failed(val detail: String) : SaveResult
}

object Exporter {
    const val CODES_DIR = "RG CODE"

    /** API 28 only: gallery folders need the legacy storage permission (declared with maxSdkVersion=28). */
    fun needsLegacyPermission(ctx: Context) =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED

    /** Generated code -> Pictures/RG CODE/, image/png. */
    fun saveCode(ctx: Context, src: ByteSrc, displayName: String): SaveResult =
        save(ctx, src, displayName, "image/png", Environment.DIRECTORY_PICTURES, CODES_DIR)

    /** Recovered original -> Downloads/. */
    fun saveOriginal(ctx: Context, src: ByteSrc, displayName: String, mime: String): SaveResult =
        save(ctx, src, displayName, mime, Environment.DIRECTORY_DOWNLOADS, null)

    private fun save(ctx: Context, src: ByteSrc, name: String, mime: String, dirType: String, sub: String?): SaveResult =
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveScoped(ctx, src, name, mime, dirType, sub)
            else saveLegacy(ctx, src, name, mime, dirType, sub)
        } catch (e: Exception) {
            SaveResult.Failed(e.message ?: e.javaClass.simpleName)
        }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.Q)
    private fun saveScoped(ctx: Context, src: ByteSrc, name: String, mime: String, dirType: String, sub: String?): SaveResult {
        val resolver = ctx.contentResolver
        val isDownload = dirType == Environment.DIRECTORY_DOWNLOADS
        val collection = if (isDownload) MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val rel = if (sub != null) "$dirType/$sub" else dirType
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: return SaveResult.Failed("The phone refused to create the file.")
        try {
            val out = resolver.openOutputStream(uri, "w") ?: throw java.io.IOException("Cannot open the new file for writing.")
            out.use { o -> src.open().use { it.copyTo(o) } }
            val same = (resolver.openInputStream(uri) ?: throw java.io.IOException("Cannot read the saved file back."))
                .use { saved -> src.open().use { Pure.sameBytes(saved, it) } }
            if (!same) {
                resolver.delete(uri, null, null)
                return SaveResult.Mismatch("The saved file does not match what was written, so it was removed. Nothing was saved.")
            }
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            var finalName = name
            resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) finalName = it.getString(0) ?: name
            }
            return SaveResult.Saved(uri, "$rel/$finalName", src.length)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            return SaveResult.Failed(e.message ?: "The file could not be saved.")
        }
    }

    private fun saveLegacy(ctx: Context, src: ByteSrc, name: String, mime: String, dirType: String, sub: String?): SaveResult {
        if (needsLegacyPermission(ctx)) return SaveResult.Failed("Storage permission is needed on this Android version.")
        @Suppress("DEPRECATION")
        val root = Environment.getExternalStoragePublicDirectory(dirType)
        val dir = if (sub != null) File(root, sub) else root
        if (!dir.isDirectory && !dir.mkdirs()) return SaveResult.Failed("Cannot create the folder ${dir.path}.")
        var target = File(dir, name)
        var n = 1
        while (target.exists()) {
            target = File(dir, name.substringBeforeLast('.') + " ($n)." + name.substringAfterLast('.', ""))
            n++
        }
        target.outputStream().use { o -> src.open().use { it.copyTo(o) } }
        val same = target.inputStream().use { saved -> src.open().use { Pure.sameBytes(saved, it) } }
        if (!same) {
            target.delete()
            return SaveResult.Mismatch("The saved file does not match what was written, so it was removed. Nothing was saved.")
        }
        MediaScannerConnection.scanFile(ctx, arrayOf(target.path), arrayOf(mime), null)
        return SaveResult.Saved(Uri.fromFile(target), "${sub?.let { "$dirType/$it" } ?: dirType}/${target.name}", src.length)
    }

    /**
     * Share as a file. The generic MIME type asks apps to treat it as a document, not a photo
     * (a photo share would recompress and destroy 1 px data). Whether a given app honours that cannot be
     * verified here; the UI keeps the warning either way.
     */
    fun share(ctx: Context, file: File, displayName: String) {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val copy = File(dir, displayName)
        file.copyTo(copy, overwrite = true)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", copy)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Share as file").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
