package com.rgcode.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.rgcode.app.ui.AppNav
import com.rgcode.app.ui.theme.RgTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_RGCode)          // leave the launch window; background stays #0D0817
        super.onCreate(savedInstanceState)
        val void = Color.parseColor("#0D0817")
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(void), navigationBarStyle = SystemBarStyle.dark(void))
        setContent { RgTheme { AppNav() } }
    }
}
