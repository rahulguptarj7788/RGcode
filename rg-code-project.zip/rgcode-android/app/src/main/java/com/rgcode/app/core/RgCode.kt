package com.rgcode.app.core

import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import java.util.zip.DataFormatException
import java.util.zip.Deflater
import java.util.zip.Inflater

/** Row-wise ARGB pixel access. Android Bitmap and the JVM tests both adapt to this. */
interface PixelSource {
    val width: Int
    val height: Int
    fun readRow(y: Int, out: IntArray)
}

/** Destination for rendered rows (ARGB). The Android side writes them into a Bitmap band by band. */
fun interface RowSink {
    fun writeRow(y: Int, argb: IntArray)
}

/** Bit-packed black/white image: 1 bit per pixel, so even an 8K canvas costs only ~4 MiB. */
class BitImage(val width: Int, val height: Int) {
    val bits = ByteArray(((width.toLong() * height + 7) shr 3).toInt())
    fun set(x: Int, y: Int) {
        val i = y.toLong() * width + x
        val b = (i shr 3).toInt()
        bits[b] = (bits[b].toInt() or (0x80 shr (i and 7).toInt())).toByte()
    }
    fun get(x: Int, y: Int): Boolean {
        val i = y.toLong() * width + x
        return ((bits[(i shr 3).toInt()].toInt() shr (7 - (i and 7).toInt())) and 1) == 1
    }
}

/** Binarise with threshold luminance < 128 (transparent pixels count as white). */
fun PixelSource.toBitImage(): BitImage {
    val img = BitImage(width, height)
    val row = IntArray(width)
    for (y in 0 until height) {
        readRow(y, row)
        for (x in 0 until width) {
            val p = row[x]
            val a = p ushr 24
            var l = (299 * ((p shr 16) and 255) + 587 * ((p shr 8) and 255) + 114 * (p and 255)) / 1000
            if (a < 255) l = (l * a + 255 * (255 - a)) / 255
            if (l < 128) img.set(x, y)
        }
    }
    return img
}

/** The image rotated counter-clockwise by 90*k degrees (numpy rot90 semantics), without copying. */
class Oriented(private val s: BitImage, private val k: Int) {
    val width = if (k % 2 == 0) s.width else s.height
    val height = if (k % 2 == 0) s.height else s.width
    fun get(x: Int, y: Int): Boolean = when (k) {
        0 -> s.get(x, y)
        1 -> s.get(s.width - 1 - y, x)
        2 -> s.get(s.width - 1 - x, s.height - 1 - y)
        else -> s.get(y, s.height - 1 - x)
    }
}

class ParsedStream(val version: Int, val flags: Int, val head: ByteArray, val payload: ByteArray, val crcOk: Boolean) {
    /** Module grid the stream was read from (0 when it came from a QR). */
    var gridW = 0
    var gridH = 0
    val encrypted get() = version == RgCode.V_ENCRYPTED
    val compressed get() = version == RgCode.V_DEFLATE || (encrypted && flags and RgCode.FLAG_DEFLATED != 0)
}

object RgCode {
    const val MAGIC = 0xA5
    const val V_RAW = 1
    const val V_DEFLATE = 2
    const val V_ENCRYPTED = 3
    const val FLAG_DEFLATED = 0x01
    const val FLAG_CHACHA = 0x04
    const val FLAGS_KNOWN = FLAG_DEFLATED or FLAG_CHACHA     // bit1 reserved for Argon2id
    const val SALT_LEN = 16
    const val NONCE_LEN = 12
    const val QUIET = 4
    private const val MAX_INFLATED = 64 * 1024 * 1024

    enum class Shape(val label: String, val short: Int, val a: Int, val b: Int) {
        SQUARE("1:1", 1480, 1, 1), R34("3:4", 1480, 3, 4), R916("9:16", 1480, 9, 16),
        BIG4K("4K", 2160, 9, 16), BIG8K("8K", 4320, 9, 16)
    }

    // ------------------------------------------------------------------ geometry (pinned rule)
    /** W = odd integer nearest to short/px - 8 (ties up); H = round_half_up((W+8)*b/a) - 8, forced odd. */
    fun gridSize(shape: Shape, px: Int): Pair<Int, Int> {
        val w = 2 * ((shape.short / px - 2 * QUIET) / 2) + 1
        val num = (w + 2 * QUIET) * shape.b
        var h = (2 * num + shape.a) / (2 * shape.a) - 2 * QUIET
        if (h % 2 == 0) h += 1
        return w to h
    }

    fun imageSize(shape: Shape, px: Int): Pair<Int, Int> {
        val (w, h) = gridSize(shape, px)
        return (w + 2 * QUIET) * px to (h + 2 * QUIET) * px
    }

    fun overhead(encrypted: Boolean) = if (encrypted) 37 + Crypto.TAG_LEN else 8

    /** Largest data length (after optional deflate) that fits the grid. */
    fun capacity(w: Int, h: Int, encrypted: Boolean) = ((h - 4) * (w - 4)) / 8 - overhead(encrypted)

    // ------------------------------------------------------------------ encode
    fun deflate(data: ByteArray): ByteArray {
        val d = Deflater(9)
        d.setInput(data)
        d.finish()
        val out = ByteArrayOutputStream(data.size / 2 + 64)
        val buf = ByteArray(65536)
        while (!d.finished()) out.write(buf, 0, d.deflate(buf))
        d.end()
        return out.toByteArray()
    }

    fun inflate(data: ByteArray): ByteArray {
        val inf = Inflater()
        inf.setInput(data)
        val out = ByteArrayOutputStream(data.size * 3)
        val buf = ByteArray(65536)
        try {
            while (!inf.finished()) {
                val n = inf.inflate(buf)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) throw FileDamagedException("Compressed data is damaged.")
                out.write(buf, 0, n)
                if (out.size() > MAX_INFLATED) throw FileDamagedException("Compressed data is implausibly large.")
            }
        } catch (e: DataFormatException) {
            throw FileDamagedException("Compressed data is damaged.")
        } finally {
            inf.end()
        }
        return out.toByteArray()
    }

    private fun be32(v: Long) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())

    /** header | payload | CRC. Deflate only if it helps; password -> version 3 (AEAD). */
    fun buildStream(data: ByteArray, password: String?, compress: Boolean, aead: Aead = Aead.CHACHA20_POLY1305): ByteArray {
        var body = data
        var deflated = false
        if (compress) {
            val packed = deflate(data)
            if (packed.size < data.size) { body = packed; deflated = true }
        }
        if (password == null) {
            val head = byteArrayOf(MAGIC.toByte(), (if (deflated) V_DEFLATE else V_RAW).toByte()) + be32(body.size.toLong())
            return head + body + crcBytes(body)
        }
        val rnd = SecureRandom()
        val salt = ByteArray(SALT_LEN).also(rnd::nextBytes)
        val nonce = ByteArray(NONCE_LEN).also(rnd::nextBytes)
        val flags = (if (deflated) FLAG_DEFLATED else 0) or (if (aead == Aead.CHACHA20_POLY1305) FLAG_CHACHA else 0)
        val head = byteArrayOf(MAGIC.toByte(), V_ENCRYPTED.toByte(), flags.toByte()) +
            be32((body.size + Crypto.TAG_LEN).toLong()) + salt + nonce
        val key = Crypto.pbkdf2Sha256(password, salt, Crypto.PBKDF2_ITERATIONS, 32)
        val sealed = Crypto.seal(aead, key, nonce, head, body)
        return head + sealed + crcBytes(sealed)
    }

    private fun crcBytes(p: ByteArray): ByteArray {
        val c = Crypto.crc16(p)
        return byteArrayOf((c ushr 8).toByte(), c.toByte())
    }

    private fun moduleBlack(stream: ByteArray, w: Int, h: Int, r: Int, c: Int): Boolean {
        if (r == h - 1 || c == w - 1) return true
        if (r == 0) return c % 2 == 0
        if (c == 0) return r % 2 == 0
        if (r < 2 || c < 2 || r >= h - 2 || c >= w - 2) return false
        val i = (r - 2) * (w - 4) + (c - 2)
        val byte = i shr 3
        return byte < stream.size && ((stream[byte].toInt() shr (7 - (i and 7))) and 1) == 1
    }

    /** Draws grid + 4-module quiet zone, one pixel row at a time (no full-size intermediate array). */
    fun render(stream: ByteArray, w: Int, h: Int, px: Int, sink: RowSink) {
        if (stream.size.toLong() * 8 > (h - 4).toLong() * (w - 4)) throw CapacityException("Stream of ${stream.size} B does not fit a $w x $h grid.")
        val imgW = (w + 2 * QUIET) * px
        val row = IntArray(imgW)
        val black = 0xFF000000.toInt()
        val white = 0xFFFFFFFF.toInt()
        for (m in 0 until h + 2 * QUIET) {
            val r = m - QUIET
            for (cm in 0 until w + 2 * QUIET) {
                val c = cm - QUIET
                val on = r in 0 until h && c in 0 until w && moduleBlack(stream, w, h, r, c)
                java.util.Arrays.fill(row, cm * px, cm * px + px, if (on) black else white)
            }
            for (t in 0 until px) sink.writeRow(m * px + t, row)
        }
    }

    // ------------------------------------------------------------------ decode
    private fun runs(len: Int, at: (Int) -> Boolean): Int {
        var n = 0
        var prev = false
        for (i in 0 until len) { val b = at(i); if (b && !prev) n++; prev = b }
        return n
    }

    /** Crop to the bounding box of all black pixels (the quiet zone is white and carries no information). */
    private fun cropToBlack(img: BitImage): BitImage? {
        var x0 = Int.MAX_VALUE; var x1 = -1; var y0 = Int.MAX_VALUE; var y1 = -1
        for (y in 0 until img.height) for (x in 0 until img.width) if (img.get(x, y)) {
            if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
        }
        if (x1 < 0) return null
        val out = BitImage(x1 - x0 + 1, y1 - y0 + 1)
        for (y in y0..y1) for (x in x0..x1) if (img.get(x, y)) out.set(x - x0, y - y0)
        return out
    }

    private class Grid(val w: Int, val h: Int, val on: BooleanArray) {
        fun get(r: Int, c: Int) = on[r * w + c]
    }

    /** Derive W, H and the module grid from one orientation, or null if this is not the right way up. */
    private fun sample(o: Oriented): Grid? {
        val bw = o.width; val bh = o.height
        var pitchX = 0
        while (pitchX < bw && o.get(bw - 1 - pitchX, bh / 2)) pitchX++
        var pitchY = 0
        while (pitchY < bh && o.get(bw / 2, bh - 1 - pitchY)) pitchY++
        pitchX = maxOf(pitchX, 1); pitchY = maxOf(pitchY, 1)
        val topY = minOf(pitchY / 2, bh - 1)
        val leftX = minOf(pitchX / 2, bw - 1)
        val w = 2 * runs(bw) { o.get(it, topY) } - 1
        val h = 2 * runs(bh) { o.get(leftX, it) } - 1
        if (w < 9 || h < 9 || Math.abs(w * pitchX - bw) > w || Math.abs(h * pitchY - bh) > h) return null
        val px = bw.toDouble() / w
        val py = bh.toDouble() / h
        val cols = IntArray(w) { ((it + 0.5) * px).toInt() }
        val rows = IntArray(h) { ((it + 0.5) * py).toInt() }
        val g = Grid(w, h, BooleanArray(w * h))
        for (r in 0 until h) for (c in 0 until w) g.on[r * w + c] = o.get(cols[c], rows[r])
        for (c in 0 until w) if (!g.get(h - 1, c)) return null
        for (r in 0 until h) if (!g.get(r, w - 1)) return null
        for (c in 0 until w) if (g.get(0, c) != (c % 2 == 0)) return null
        for (r in 0 until h) if (g.get(r, 0) != (r % 2 == 0)) return null
        return g
    }

    private fun gridBytes(g: Grid): ByteArray {
        val out = ByteArray(((g.h - 4) * (g.w - 4) + 7) / 8)
        var i = 0
        for (r in 2 until g.h - 2) for (c in 2 until g.w - 2) {
            if (g.get(r, c)) out[i shr 3] = (out[i shr 3].toInt() or (0x80 shr (i and 7))).toByte()
            i++
        }
        return out
    }

    /** Parse a stored stream. Null if the magic/version is not ours. A bad CRC is reported, not thrown. */
    fun parseStream(raw: ByteArray): ParsedStream? {
        if (raw.size < 8 || (raw[0].toInt() and 255) != MAGIC) return null
        val version = raw[1].toInt() and 255
        if (version !in V_RAW..V_ENCRYPTED) return null
        var pos = 2
        var flags = 0
        if (version == V_ENCRYPTED) { flags = raw[2].toInt() and 255; pos = 3 }
        if (pos + 4 > raw.size) return null
        val length = ((raw[pos].toLong() and 255) shl 24) or ((raw[pos + 1].toLong() and 255) shl 16) or
            ((raw[pos + 2].toLong() and 255) shl 8) or (raw[pos + 3].toLong() and 255)
        pos += 4 + if (version == V_ENCRYPTED) SALT_LEN + NONCE_LEN else 0
        if (pos + length + 2 > raw.size) return null
        val payload = raw.copyOfRange(pos, pos + length.toInt())
        val crc = ((raw[pos + length.toInt()].toInt() and 255) shl 8) or (raw[pos + length.toInt() + 1].toInt() and 255)
        return ParsedStream(version, flags, raw.copyOfRange(0, pos), payload, crc == Crypto.crc16(payload))
    }

    /** Find an RG-Code in the image (any of 4 rotations, any size, any grade). Null = not an RG-Code. */
    fun read(src: PixelSource): ParsedStream? {
        val box = cropToBlack(src.toBitImage()) ?: return null
        for (k in 0 until 4) {
            val g = sample(Oriented(box, k)) ?: continue
            val parsed = parseStream(gridBytes(g)) ?: continue
            parsed.gridW = g.w; parsed.gridH = g.h
            return parsed
        }
        return null
    }

    /** CRC first, then AEAD, then inflate. Never returns partial data. */
    fun open(p: ParsedStream, password: String?): ByteArray {
        if (!p.crcOk) throw FileDamagedException()
        if (p.version == V_RAW) return p.payload
        if (p.version == V_DEFLATE) return inflate(p.payload)
        if (p.flags and FLAGS_KNOWN.inv() != 0) throw UnsupportedException("This code uses a newer feature than this version of RG CODE understands.")
        if (password.isNullOrEmpty()) throw WrongPasswordException(true, "This code is protected: enter its password.")
        val salt = p.head.copyOfRange(7, 7 + SALT_LEN)
        val nonce = p.head.copyOfRange(7 + SALT_LEN, 7 + SALT_LEN + NONCE_LEN)
        val aead = if (p.flags and FLAG_CHACHA != 0) Aead.CHACHA20_POLY1305 else Aead.AES_GCM
        val key = Crypto.pbkdf2Sha256(password, salt, Crypto.PBKDF2_ITERATIONS, 32)
        val body = Crypto.open(aead, key, nonce, p.head, p.payload)
        return if (p.flags and FLAG_DEFLATED != 0) inflate(body) else body
    }
}
