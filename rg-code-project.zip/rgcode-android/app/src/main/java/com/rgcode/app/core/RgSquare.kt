package com.rgcode.app.core

import java.security.SecureRandom

/**
 * RG-Square: the file is laid into a 768-wide RGB raster, sealed with ChaCha20-Poly1305, cut into
 * 8x8 squares and scattered with RG-Disperse v1. Square 0 is the header. With encrypt-first the
 * scatter is cosmetic: confidentiality and integrity come from the AEAD, not from the permutation.
 */
object RgSquare {
    const val SQ = 8
    const val COLS = 96
    const val ROWS = 174
    const val N = COLS * ROWS            // 16,704 squares
    const val K = 10325L
    const val KINV = 6845L
    const val SQ_BYTES = SQ * SQ * 3     // 192
    const val IMG_ROWS = ROWS - 1        // image squares live in grid rows 1..173
    const val MAX_W = COLS * SQ          // 768
    const val MAX_H = IMG_ROWS * SQ      // 1384
    const val IMG_W = COLS * SQ          // 768
    const val IMG_H = ROWS * SQ          // 1392
    const val FILE_CAPACITY = MAX_W * MAX_H * 3 - 4
    private val MAGIC = "SQv1".toByteArray(Charsets.US_ASCII)

    fun isSquareSized(w: Int, h: Int) = (w == IMG_W && h == IMG_H) || (w == IMG_H && h == IMG_W)

    /** Fisher-Yates over 1..N-1 driven by the ChaCha20 keystream, rejection sampling (no modulo bias). */
    fun shuffle(permKey: ByteArray, nonce: ByteArray): IntArray {
        val ks = ChaCha20Stream(permKey, nonce)
        fun below(m: Int): Int {
            val limit = 4294967296L - (4294967296L % m)
            while (true) { val v = ks.nextU32(); if (v < limit) return (v % m).toInt() }
        }
        val perm = IntArray(N) { it }
        for (i in N - 1 downTo 2) {
            val j = 1 + below(i)
            val t = perm[i]; perm[i] = perm[j]; perm[j] = t
        }
        return perm
    }

    private fun keys(password: String, salt: ByteArray): Triple<ByteArray, ByteArray, ByteArray> {
        val d = Crypto.pbkdf2Sha256(password, salt, Crypto.PBKDF2_ITERATIONS, 96)
        return Triple(d.copyOfRange(0, 32), d.copyOfRange(32, 64), d.copyOfRange(64, 96))
    }

    private fun be32(b: ByteArray, o: Int) =
        ((b[o].toLong() and 255) shl 24) or ((b[o + 1].toLong() and 255) shl 16) or ((b[o + 2].toLong() and 255) shl 8) or (b[o + 3].toLong() and 255)

    private fun putBe32(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte(); b[o + 1] = (v ushr 16).toByte(); b[o + 2] = (v ushr 8).toByte(); b[o + 3] = v.toByte()
    }

    /** 4-byte big-endian length, the file, zero padding to whole 768*3-byte rows. Returns (rows, bytes). */
    fun fileToRaster(data: ByteArray): Pair<Int, ByteArray> {
        if (data.size > FILE_CAPACITY) throw CapacityException("File is larger than one RG-Square image holds ($FILE_CAPACITY B).")
        val rowBytes = MAX_W * 3
        val rows = (data.size + 4 + rowBytes - 1) / rowBytes
        val raster = ByteArray(rows * rowBytes)
        putBe32(raster, 0, data.size)
        System.arraycopy(data, 0, raster, 4, data.size)
        return rows to raster
    }

    /** Returns the 768 x 1392 image as ARGB ints. */
    fun encodeFile(data: ByteArray, password: String): IntArray {
        val (rows, raster) = fileToRaster(data)
        val rnd = SecureRandom()
        val salt = ByteArray(16).also(rnd::nextBytes)
        val nonce = ByteArray(12).also(rnd::nextBytes)
        val (encKey, hdrKey, permKey) = keys(password, salt)
        val padded = ByteArray(MAX_W * MAX_H * 3)
        System.arraycopy(raster, 0, padded, 0, raster.size)
        val sealed = Crypto.seal(Aead.CHACHA20_POLY1305, encKey, nonce, salt + nonce, padded)
        val cipherLen = sealed.size - Crypto.TAG_LEN

        val squares = ByteArray(N * SQ_BYTES).also(rnd::nextBytes)
        for (r in 0 until IMG_ROWS) for (c in 0 until COLS) for (ty in 0 until SQ) {
            System.arraycopy(sealed, ((r * SQ + ty) * MAX_W + c * SQ) * 3, squares, (COLS + r * COLS + c) * SQ_BYTES + ty * SQ * 3, SQ * 3)
        }
        val fields = ByteArray(12)
        putBe32(fields, 0, MAX_W); putBe32(fields, 4, rows)
        System.arraycopy(MAGIC, 0, fields, 8, 4)
        val mask = ChaCha20Stream(hdrKey, nonce).nextBytes(12)
        System.arraycopy(salt, 0, squares, 0, 16)
        System.arraycopy(nonce, 0, squares, 16, 12)
        for (i in 0 until 12) squares[28 + i] = (fields[i].toInt() xor mask[i].toInt()).toByte()
        System.arraycopy(sealed, cipherLen, squares, 40, Crypto.TAG_LEN)

        val perm = shuffle(permKey, nonce)
        val out = ByteArray(N * SQ_BYTES)
        for (i in 0 until N) {
            val src = ((perm[i].toLong() * K) % N).toInt()
            System.arraycopy(squares, src * SQ_BYTES, out, i * SQ_BYTES, SQ_BYTES)
        }
        val pix = IntArray(IMG_W * IMG_H)
        for (i in 0 until N) {
            val r = i / COLS; val c = i % COLS
            for (ty in 0 until SQ) for (tx in 0 until SQ) {
                val o = i * SQ_BYTES + (ty * SQ + tx) * 3
                pix[(r * SQ + ty) * IMG_W + c * SQ + tx] = 0xFF000000.toInt() or ((out[o].toInt() and 255) shl 16) or
                    ((out[o + 1].toInt() and 255) shl 8) or (out[o + 2].toInt() and 255)
            }
        }
        return pix
    }

    private class Keys(val enc: ByteArray, val perm: ByteArray, val salt: ByteArray, val nonce: ByteArray, val tag: ByteArray, val rows: Int)

    /** Reads square 0 of an oriented 768x1392 image; null if the magic does not verify. */
    private fun tryHeader(at: (Int, Int) -> Int, password: String): Keys? {
        val head = ByteArray(SQ_BYTES)
        for (ty in 0 until SQ) for (tx in 0 until SQ) {
            val p = at(tx, ty)
            val o = (ty * SQ + tx) * 3
            head[o] = (p shr 16).toByte(); head[o + 1] = (p shr 8).toByte(); head[o + 2] = p.toByte()
        }
        val salt = head.copyOfRange(0, 16); val nonce = head.copyOfRange(16, 28)
        val (enc, hdr, perm) = keys(password, salt)
        val mask = ChaCha20Stream(hdr, nonce).nextBytes(12)
        val fields = ByteArray(12) { (head[28 + it].toInt() xor mask[it].toInt()).toByte() }
        if (!fields.copyOfRange(8, 12).contentEquals(MAGIC)) return null
        val w = be32(fields, 0); val h = be32(fields, 4)
        if (w !in 1..MAX_W || h !in 1..IMG_ROWS * SQ) return null
        return Keys(enc, perm, salt, nonce, head.copyOfRange(40, 56), h.toInt())
    }

    /** Opens an RG-Square image (any of 4 rotations) and returns the original file bytes. */
    fun decodeFile(src: PixelSource, password: String): ByteArray {
        val w = src.width; val h = src.height
        if (!isSquareSized(w, h)) throw NotACodeException()
        val px = IntArray(w * h)
        val row = IntArray(w)
        for (y in 0 until h) { src.readRow(y, row); System.arraycopy(row, 0, px, y * w, w) }
        for (k in 0 until 4) {
            val ow = if (k % 2 == 0) w else h
            if (ow != IMG_W) continue
            val at = { x: Int, y: Int ->
                when (k) {
                    0 -> px[y * w + x]
                    1 -> px[x * w + (w - 1 - y)]
                    2 -> px[(h - 1 - y) * w + (w - 1 - x)]
                    else -> px[(h - 1 - x) * w + y]
                }
            }
            val keys = tryHeader(at, password) ?: continue
            val out = ByteArray(N * SQ_BYTES)
            for (i in 0 until N) {
                val r = i / COLS; val c = i % COLS
                for (ty in 0 until SQ) for (tx in 0 until SQ) {
                    val p = at(c * SQ + tx, r * SQ + ty)
                    val o = i * SQ_BYTES + (ty * SQ + tx) * 3
                    out[o] = (p shr 16).toByte(); out[o + 1] = (p shr 8).toByte(); out[o + 2] = p.toByte()
                }
            }
            val perm = shuffle(keys.perm, keys.nonce)
            val inv = IntArray(N)
            for (i in 0 until N) inv[perm[i]] = i
            val sealed = ByteArray(MAX_W * MAX_H * 3 + Crypto.TAG_LEN)
            for (r in 0 until IMG_ROWS) for (c in 0 until COLS) {
                val j = COLS + r * COLS + c                          // square index to restore
                val from = inv[((j.toLong() * KINV) % N).toInt()]    // squares[j] = out[inv[(j*KINV) mod N]]
                for (ty in 0 until SQ) {
                    System.arraycopy(out, from * SQ_BYTES + ty * SQ * 3, sealed, ((r * SQ + ty) * MAX_W + c * SQ) * 3, SQ * 3)
                }
            }
            System.arraycopy(keys.tag, 0, sealed, sealed.size - Crypto.TAG_LEN, Crypto.TAG_LEN)
            val padded = try {
                Crypto.open(Aead.CHACHA20_POLY1305, keys.enc, keys.nonce, keys.salt + keys.nonce, sealed)
            } catch (e: WrongPasswordException) {
                throw FileDamagedException("The squares were changed after the code was made. A photo-share or a screenshot destroys 1 px data.")
            }
            val len = be32(padded, 0)
            if (len < 0 || len > keys.rows.toLong() * MAX_W * 3 - 4) throw FileDamagedException("The stored length is invalid.")
            return padded.copyOfRange(4, 4 + len.toInt())
        }
        throw WrongPasswordException(false, "Wrong password, or this is not an RG-Square image.")
    }
}
