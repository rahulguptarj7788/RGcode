package com.rgcode.app.core

enum class PayloadKind { TEXT, PHOTO, FILE }

/** The seven systems shown as chips A-G. Text and files use A-F; photos use G only. */
enum class SystemId(val letter: Char, val label: String) {
    A('A', "Standard QR"), B('B', "RG-Code 1:1"), C('C', "RG-Code 3:4"), D('D', "RG-Code 9:16"),
    E('E', "RG-Code 4K canvas"), F('F', "RG-Code 8K canvas"), G('G', "RG-Square")
}

enum class ShapePref(val label: String) { AUTO("Auto"), S11("1:1"), S34("3:4"), S916("9:16") }

data class AppSettings(
    val shape: ShapePref = ShapePref.AUTO,
    val grade: Int = 0,                 // 0 = auto (sturdiest that fits), 1..4 = 1/2/4/8 px
    val canvas8k: Boolean = false,      // opt-in: needs ~127 MiB bitmap + large heap
    val compress: Boolean = true,
)

/** Data about the payload that planning needs; computed once so the cascade is cheap. */
class Prepared(val kind: PayloadKind, val rawLen: Int, val storedLen: Int, val plainText: Boolean) {
    val compressionHelps get() = storedLen < rawLen * 0.98
}

class Plan(
    val system: SystemId, val shape: RgCode.Shape?, val px: Int, val grade: Int, val squares: Long,
    val capacity: Int, val stored: Int, val imageW: Int, val imageH: Int,
) {
    val comfortable get() = stored <= capacity * 0.7
    /** Only 8 px squares survive being sent as a photo (measured, see the spec). */
    val survivesPhotoShare get() = system == SystemId.A || system == SystemId.G || px >= 8
}

sealed interface PlanResult {
    class Fits(val plan: Plan) : PlanResult
    class TooBig(val stored: Int, val maxCapacity: Int, val maxLabel: String, val compressionHelps: Boolean) : PlanResult
}

object Planner {
    fun applicable(kind: PayloadKind, allow8k: Boolean): List<SystemId> = when (kind) {
        PayloadKind.PHOTO -> listOf(SystemId.G)
        else -> listOf(SystemId.A, SystemId.B, SystemId.C, SystemId.D, SystemId.E) + if (allow8k) listOf(SystemId.F) else emptyList()
    }

    fun prepare(kind: PayloadKind, data: ByteArray, compress: Boolean): Prepared {
        val stored = if (kind == PayloadKind.PHOTO || !compress) data.size else minOf(data.size, RgCode.deflate(data).size)
        return Prepared(kind, data.size, stored, kind == PayloadKind.TEXT && QrTier.isPlainText(data) != null)
    }

    private fun pxFor(shape: RgCode.Shape, grade: Int): List<Int> = when {
        shape == RgCode.Shape.BIG4K || shape == RgCode.Shape.BIG8K -> listOf(1)
        grade in 1..4 -> listOf(intArrayOf(1, 2, 4, 8)[grade - 1])
        else -> listOf(8, 4, 2, 1)
    }

    private fun gradeOf(px: Int, shape: RgCode.Shape) = if (shape == RgCode.Shape.BIG4K || shape == RgCode.Shape.BIG8K) 5 else when (px) { 1 -> 1; 2 -> 2; 4 -> 3; else -> 4 }

    private fun qrPlan(p: Prepared, encrypted: Boolean): Plan? {
        val textPath = !encrypted && p.plainText
        val stored = if (textPath) p.rawLen else p.storedLen
        val cap = if (textPath) QrTier.BYTE_MAX else QrTier.STREAM_MAX - RgCode.overhead(encrypted)
        if (stored > cap) return null
        return Plan(SystemId.A, null, 0, 0, 0, cap, stored, 1480, 1480)
    }

    private fun shapePlan(system: SystemId, shape: RgCode.Shape, p: Prepared, encrypted: Boolean, s: AppSettings): Plan? {
        for (px in pxFor(shape, s.grade)) {
            val (w, h) = RgCode.gridSize(shape, px)
            val cap = RgCode.capacity(w, h, encrypted)
            if (p.storedLen <= cap) {
                val (iw, ih) = RgCode.imageSize(shape, px)
                return Plan(system, shape, px, gradeOf(px, shape), w.toLong() * h, cap, p.storedLen, iw, ih)
            }
        }
        return null
    }

    fun plan(p: Prepared, encrypted: Boolean, s: AppSettings, forced: SystemId? = null): PlanResult {
        if (p.kind == PayloadKind.PHOTO) {
            return if (p.rawLen <= RgSquare.FILE_CAPACITY)
                PlanResult.Fits(Plan(SystemId.G, null, 8, 4, RgSquare.N.toLong(), RgSquare.FILE_CAPACITY, p.rawLen, RgSquare.IMG_W, RgSquare.IMG_H))
            else PlanResult.TooBig(p.rawLen, RgSquare.FILE_CAPACITY, "RG-Square", false)
        }
        val chain = buildList {
            val startShape = when (s.shape) { ShapePref.AUTO -> 0; ShapePref.S11 -> 1; ShapePref.S34 -> 2; ShapePref.S916 -> 3 }
            val all = listOf(
                SystemId.A to null, SystemId.B to RgCode.Shape.SQUARE, SystemId.C to RgCode.Shape.R34,
                SystemId.D to RgCode.Shape.R916, SystemId.E to RgCode.Shape.BIG4K,
            ) + if (s.canvas8k) listOf(SystemId.F to RgCode.Shape.BIG8K) else emptyList()
            addAll(all.filterIndexed { i, _ -> i >= startShape })
        }
        for ((id, shape) in chain) {
            if (forced != null && forced != id) continue
            val plan = if (shape == null) qrPlan(p, encrypted) else shapePlan(id, shape, p, encrypted, s)
            if (plan != null) return PlanResult.Fits(plan)
        }
        val top = if (s.canvas8k) RgCode.Shape.BIG8K else RgCode.Shape.BIG4K
        val (w, h) = RgCode.gridSize(top, 1)
        return PlanResult.TooBig(p.storedLen, RgCode.capacity(w, h, encrypted), "${top.label} canvas, 1 px", p.compressionHelps)
    }
}
