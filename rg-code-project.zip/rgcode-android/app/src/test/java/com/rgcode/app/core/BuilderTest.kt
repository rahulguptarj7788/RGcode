package com.rgcode.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.awt.image.BufferedImage

/** Exercises the Kotlin encoders and the QR path end to end: seal -> draw -> read back with the real decoder. */
class BuilderTest {
    private class Img(val img: BufferedImage) : PixelSource {
        override val width get() = img.width
        override val height get() = img.height
        override fun readRow(y: Int, out: IntArray) { img.getRGB(0, y, width, 1, out, 0, width) }
    }

    private fun run(kind: PayloadKind, data: ByteArray, pw: String?, forced: SystemId?, aead: Aead = Aead.CHACHA20_POLY1305): Plan {
        val s = AppSettings()
        val prep = Planner.prepare(kind, data, true)
        val res = Planner.plan(prep, pw != null, s, forced) as PlanResult.Fits
        val plan = res.plan
        val content = CodeBuilder.seal(plan, data, pw, true, aead)
        var img: BufferedImage? = null
        val dims = CodeBuilder.draw(plan, content) { w, h ->
            img = BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB)
            RowSink { y, row -> img!!.setRGB(0, y, w, 1, row, 0, w) }
        }
        assertEquals(dims, img!!.width to img!!.height)
        val badge = CodeBuilder.readBack(Img(img!!), plan, data, pw)
        assertTrue(badge, badge.endsWith("byte-identical"))
        return plan
    }

    private val text = "RG CODE builder test. ".repeat(40).toByteArray()
    private val blob = ByteArray(3000) { (it * 37 + it / 7).toByte() }

    @Test fun qrPlainAndEncrypted() {
        assertEquals(SystemId.A, run(PayloadKind.TEXT, "hello ü".toByteArray(), null, null).system)
        assertEquals(SystemId.A, run(PayloadKind.FILE, blob.copyOf(1200), "pass-word-1", SystemId.A).system)
    }

    @Test fun rgCodeShapesAndCiphers() {
        for (aead in Aead.values()) {
            run(PayloadKind.TEXT, text, "pass-word-1", SystemId.B, aead)
            run(PayloadKind.FILE, blob, "pass-word-1", SystemId.C, aead)
            run(PayloadKind.FILE, blob, null, SystemId.D, aead)
        }
    }

    @Test fun bigCanvasAndSquare() {
        run(PayloadKind.FILE, ByteArray(40_000) { (it * 31).toByte() }, "pass-word-1", SystemId.E)
        assertEquals(SystemId.G, run(PayloadKind.PHOTO, ByteArray(100_000) { (it * 17).toByte() }, "pass-word-1", null).system)
    }

    @Test fun readBackFailsLoudlyOnDamage() {
        val plan = (Planner.plan(Planner.prepare(PayloadKind.FILE, blob, true), false, AppSettings(), SystemId.D) as PlanResult.Fits).plan
        val content = CodeBuilder.seal(plan, blob, null, true, Aead.CHACHA20_POLY1305)
        var img: BufferedImage? = null
        CodeBuilder.draw(plan, content) { w, h -> img = BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB); RowSink { y, r -> img!!.setRGB(0, y, w, 1, r, 0, w) } }
        val x = img!!.width / 2; val y = img!!.height / 2
        img!!.setRGB(x, y, img!!.getRGB(x, y) xor 0xFFFFFF)          // flip one pixel in the data area
        try { CodeBuilder.readBack(Img(img!!), plan, blob, null); fail("damage not detected") } catch (e: RgException) { }
    }

    @Test fun plannerRules() {
        val big = Planner.prepare(PayloadKind.FILE, ByteArray(5_000_000) { (it * 7919).toByte() }, true)
        assertTrue(Planner.plan(big, false, AppSettings(), null) is PlanResult.TooBig)
        val photo = Planner.prepare(PayloadKind.PHOTO, ByteArray(3_000_000), false)
        assertTrue(Planner.plan(photo, true, AppSettings(), null) is PlanResult.Fits)
        assertEquals(listOf(SystemId.G), Planner.applicable(PayloadKind.PHOTO, true))
        assertTrue(SystemId.G !in Planner.applicable(PayloadKind.TEXT, true))
    }

    @Test fun passwordRules() {
        assertEquals(0, PasswordRules.strength(""))
        assertEquals(3, PasswordRules.strength("Correct-horse-9"))
        assertTrue(!PasswordRules.valid("short", "short"))
        assertTrue(PasswordRules.valid("long-enough-1", "long-enough-1"))
        assertTrue(!PasswordRules.valid("long-enough-1", "long-enough-2"))
    }
}
