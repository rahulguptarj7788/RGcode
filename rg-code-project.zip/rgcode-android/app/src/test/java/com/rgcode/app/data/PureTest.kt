package com.rgcode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PureTest {
    @Test fun sameBytesDetectsEqualAndDifferent() {
        val a = ByteArray(200_000) { (it * 13).toByte() }
        assertTrue(Pure.sameBytes(a.inputStream(), a.copyOf().inputStream()))
        val b = a.copyOf().also { it[150_000] = (it[150_000] + 1).toByte() }
        assertFalse(Pure.sameBytes(a.inputStream(), b.inputStream()))
        assertFalse(Pure.sameBytes(a.inputStream(), a.copyOf(a.size - 1).inputStream()))
        assertTrue(Pure.sameBytes(ByteArray(0).inputStream(), ByteArray(0).inputStream()))
    }

    @Test fun sameBytesHandlesShortReads() {
        val data = ByteArray(100_000) { it.toByte() }
        val trickle = object : java.io.InputStream() {
            var pos = 0
            override fun read() = if (pos < data.size) data[pos++].toInt() and 255 else -1
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (pos >= data.size) return -1
                val n = minOf(len, 7, data.size - pos)
                System.arraycopy(data, pos, b, off, n); pos += n
                return n
            }
        }
        assertTrue(Pure.sameBytes(trickle, data.inputStream()))
    }

    @Test fun safeFileNames() {
        assertEquals("a.png", Pure.safeFileName("../x/a.png", "code", "png"))
        assertEquals("code.png", Pure.safeFileName("  ?*  ", "code", "png"))
        assertEquals("photo.png", Pure.safeFileName("photo.jpg", "code", "png"))
        assertEquals("notes.txt", Pure.safeFileName("notes", "x", "txt"))
    }

    @Test fun recentsRoundTripAndLimit() {
        var list = emptyList<Pure.Recent>()
        for (i in 1..10) list = Pure.recentsAdd(list, Pure.Recent(i.toLong(), "n\t$i", "9:16 · grade 4\nx", "content://u/$i"))
        assertEquals(8, list.size)
        assertEquals(10L, list.first().whenMs)
        val back = Pure.recentsDecode(Pure.recentsEncode(list))
        assertEquals(list.map { it.uri }, back.map { it.uri })
        assertEquals("n 10", back.first().name)
        list = Pure.recentsAdd(list, Pure.Recent(99, "again", "l", "content://u/5"))
        assertEquals(1, list.count { it.uri == "content://u/5" })
        assertEquals("content://u/5", list.first().uri)
        assertTrue(Pure.recentsDecode("garbage\n\nx\ty").isEmpty())
    }
}
