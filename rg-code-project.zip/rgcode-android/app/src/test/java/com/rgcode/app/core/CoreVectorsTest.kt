package com.rgcode.app.core

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.awt.image.BufferedImage
import java.security.MessageDigest
import java.util.Properties
import javax.imageio.ImageIO

/** JVM tests against golden files produced by the Python reference (run `python3 make_vectors.py` to refresh). */
class CoreVectorsTest {
    private class Img(val img: BufferedImage) : PixelSource {
        override val width get() = img.width
        override val height get() = img.height
        override fun readRow(y: Int, out: IntArray) { img.getRGB(0, y, width, 1, out, 0, width) }
    }

    private fun res(name: String) = javaClass.getResourceAsStream("/vectors/$name")!!.readBytes()
    private fun png(name: String) = Img(ImageIO.read(javaClass.getResourceAsStream("/vectors/$name.png")))
    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    private val props = Properties().apply { load(javaClass.getResourceAsStream("/vectors/crypto.properties")!!.reader(Charsets.UTF_8)) }

    @Test fun crc16MatchesPythonCrcHqx() = assertEquals(0x29B1, Crypto.crc16("123456789".toByteArray()))

    @Test fun pbkdf2MatchesPython() {
        assertEquals(props["pbkdf2_iter3_40"], Crypto.pbkdf2Sha256("passwd", "salt".toByteArray(), 3, 40).toHex())
        val salt = ByteArray(16) { it.toByte() }
        assertEquals(props["pbkdf2_iter200k_96"], Crypto.pbkdf2Sha256("pässword-ü", salt, 200_000, 96).toHex())
    }

    @Test fun chacha20KeystreamMatchesPython() {
        val s = ChaCha20Stream(ByteArray(32) { it.toByte() }, ByteArray(12) { it.toByte() })
        assertEquals(props["chacha_first_150"], s.nextBytes(150).toHex())
    }

    @Test fun shuffleMatchesPython() {
        val perm = RgSquare.shuffle(ByteArray(32) { it.toByte() }, ByteArray(12) { it.toByte() })
        assertEquals((props["shuffle_first_16"] as String), perm.take(16).joinToString(","))
        val le = java.nio.ByteBuffer.allocate(perm.size * 4).order(java.nio.ByteOrder.LITTLE_ENDIAN).also { b -> perm.forEach { b.putInt(it) } }
        assertEquals(props["shuffle_sha256"], MessageDigest.getInstance("SHA-256").digest(le.array()).toHex())
    }

    @Test fun dispersionConstantsAreInverse() {
        assertEquals(1L, (RgSquare.K * RgSquare.KINV) % RgSquare.N)
    }

    @Test fun pinnedCapacities() {
        val table = listOf(
            Triple(RgCode.Shape.R916 to 1, 1473 to 2625, 481273), Triple(RgCode.Shape.R916 to 2, 733 to 1309, 118910),
            Triple(RgCode.Shape.R916 to 4, 363 to 653, 29115), Triple(RgCode.Shape.R916 to 8, 177 to 321, 6847),
            Triple(RgCode.Shape.SQUARE to 1, 1473 to 1473, 269737), Triple(RgCode.Shape.R34 to 1, 1473 to 1967, 360447),
            Triple(RgCode.Shape.BIG4K to 1, 2153 to 3835, 1029094),
        )
        for ((sp, grid, cap) in table) {
            val (w, h) = RgCode.gridSize(sp.first, sp.second)
            assertEquals("grid ${sp.first} ${sp.second}", grid, w to h)
            // Python capacity() minus the unencrypted 8-byte overhead equals the spec formula ((H-4)(W-4)-64)//8
            assertEquals(cap, RgCode.capacity(w, h, false))
        }
        assertEquals(1484 to 2644, RgCode.imageSize(RgCode.Shape.R916, 4))
    }

    private fun openRg(name: String, password: String?): ByteArray {
        val parsed = RgCode.read(png(name)) ?: throw AssertionError("no RG-Code in $name")
        return RgCode.open(parsed, password)
    }

    @Test fun pythonRawDeflateAndEncryptedCodesDecode() {
        assertArrayEquals(res("rg_raw_1x1_8px.bin"), openRg("rg_raw_1x1_8px", null))
        assertArrayEquals(res("rg_deflate_3x4.bin"), openRg("rg_deflate_3x4", null))
        assertArrayEquals(res("rg_chacha_9x16.bin"), openRg("rg_chacha_9x16", "pässword-ü"))
    }

    @Test fun rotatedCodesDecode() {
        assertArrayEquals(res("rg_aes_rot180.bin"), openRg("rg_aes_rot180", "pw-aes"))
        assertArrayEquals(res("rg_chacha_rot90_1px.bin"), openRg("rg_chacha_rot90_1px", "pw"))
    }

    @Test fun wrongPasswordAndMissingPasswordAreClean() {
        val parsed = RgCode.read(png("rg_chacha_9x16"))!!
        try { RgCode.open(parsed, "nope"); fail() } catch (e: WrongPasswordException) { assertTrue(!e.needsPassword) }
        try { RgCode.open(parsed, null); fail() } catch (e: WrongPasswordException) { assertTrue(e.needsPassword) }
    }

    @Test fun standardQrDecodes() {
        val plain = QrTier.read(png("qr_text"))!!
        assertArrayEquals(res("qr_text.bin"), QrTier.parseContent(plain).first)
        val enc = QrTier.parseContent(QrTier.read(png("qr_encrypted"))!!).second!!
        assertArrayEquals(res("qr_encrypted.bin"), RgCode.open(enc, "qr-pw"))
    }

    @Test fun squareCodeFromPythonDecodes() {
        assertArrayEquals(res("square_file.bin"), RgSquare.decodeFile(png("square_file"), "sq-pw"))
        try { RgSquare.decodeFile(png("square_file"), "bad"); fail() } catch (e: WrongPasswordException) { }
    }

    @Test fun kotlinEncoderRoundTripsBothCiphers() {
        for (aead in Aead.values()) for (shape in listOf(RgCode.Shape.SQUARE to 8, RgCode.Shape.R916 to 4)) {
            val data = ByteArray(1500) { (it * 31).toByte() }
            val stream = RgCode.buildStream(data, "pw", true, aead)
            val (w, h) = RgCode.gridSize(shape.first, shape.second)
            val (iw, ih) = RgCode.imageSize(shape.first, shape.second)
            val img = BufferedImage(iw, ih, BufferedImage.TYPE_INT_ARGB)
            RgCode.render(stream, w, h, shape.second) { y, row -> img.setRGB(0, y, iw, 1, row, 0, iw) }
            assertArrayEquals(data, RgCode.open(RgCode.read(Img(img))!!, "pw"))
        }
    }

    @Test fun kotlinSquareRoundTrips() {
        val data = ByteArray(5000) { (it * 7).toByte() }
        val pix = RgSquare.encodeFile(data, "pw")
        val out = RgSquare.decodeFile(IntPixels(RgSquare.IMG_W, RgSquare.IMG_H, pix), "pw")
        assertArrayEquals(data, out)
    }

    @Test fun kotlinQrRoundTrips() {
        val text = QrTier.content("hello ü QR".toByteArray(), null, true, Aead.CHACHA20_POLY1305)!!
        var img: BufferedImage? = null
        QrTier.render(text) { size -> img = BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB); RowSink { y, r -> img!!.setRGB(0, y, size, 1, r, 0, size) } }
        assertEquals(text, QrTier.read(Img(img!!)))
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
}
