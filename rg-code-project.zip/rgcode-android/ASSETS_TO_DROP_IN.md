# Files to add (NOT in this project: the attachments did not reach the sandbox)

From rg_code_app_icons_purple.zip -> legacy launcher icons:
  app/src/main/res/mipmap-mdpi/ic_launcher.png     <- ic_launcher_48.png
  app/src/main/res/mipmap-hdpi/ic_launcher.png     <- ic_launcher_72.png
  app/src/main/res/mipmap-xhdpi/ic_launcher.png    <- ic_launcher_96.png
  app/src/main/res/mipmap-xxhdpi/ic_launcher.png   <- ic_launcher_144.png
  app/src/main/res/mipmap-xxxhdpi/ic_launcher.png  <- ic_launcher_192.png
  (ic_launcher_512.png = store listing only)
Single files -> app/src/main/res/drawable-nodpi/ (keep these exact names):
  rg_code_app_icon_purple.png   (adaptive-icon foreground, already wired in ic_launcher_fg.xml)
  rg_code_splash.png            (launch window, already wired in splash_window.xml; background #0D0817)
  rg_code_logo_lockup.png       (About header)
From rg_code_fonts.zip -> app/src/main/res/font/ (Android needs lowercase snake_case names):
  BricolageGrotesque.ttf  -> bricolage_grotesque.ttf   (variable; weights 600/800 set in Type.kt)
  IBMPlexSans.ttf         -> ibm_plex_sans.ttf         (variable; body)
  FragmentMono-Regular.ttf-> fragment_mono_regular.ttf
  Keep the three OFL licence texts in app/src/main/assets/licenses/ and show them under About.
The project does not compile until these exist.
