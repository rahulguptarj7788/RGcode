"""Standard-QR tier (payload <= 2,953 bytes): a real ISO/IEC 18004 QR, readable by any phone.

Plain UTF-8 text without a password is stored as-is, so a normal scanner shows the text.
Anything else (binary, or encrypted) is stored as  "RGQ1:" + base64(RG-Code stream)  because QR
text content must be printable; the stream is the same self-describing one rgcode uses
(magic | version | ... | CRC), so encryption, compression and the GCM tag work unchanged.
Version 40, level L, byte mode, 4-module quiet zone, 8 px per module at full size (1480 px).
"""
import base64

import cv2
import numpy as np
from PIL import Image

import rgcode

QR_BYTE_MAX = 2953                 # version 40-L, byte mode (verified: OpenCV rejects 2,954)
PREFIX = "RGQ1:"


def _stream_text(stream: bytes) -> str:
    return PREFIX + base64.b64encode(stream).decode("ascii")


def encode(data: bytes, password: str | None = None) -> Image.Image:
    """Return a standard QR image, or raise CapacityError when it does not fit."""
    text = None
    if password is None:
        try:
            plain = data.decode("utf-8")
            if not plain.startswith(PREFIX):
                text = plain
        except UnicodeDecodeError:
            pass
    if text is None:
        text = _stream_text(rgcode.build_stream(data, password, compress=True))
    if len(text.encode("utf-8")) > QR_BYTE_MAX:
        raise rgcode.CapacityError(f"{len(text.encode('utf-8'))} B does not fit one standard QR ({QR_BYTE_MAX} B)")
    params = cv2.QRCodeEncoder_Params()
    params.correction_level = cv2.QRCodeEncoder_CORRECT_LEVEL_L
    params.mode = cv2.QRCodeEncoder_MODE_BYTE
    modules = cv2.QRCodeEncoder.create(params).encode(text)       # includes a 2-module border
    modules = cv2.copyMakeBorder(modules, 2, 2, 2, 2, cv2.BORDER_CONSTANT, value=255)  # -> 4 modules
    scale = max(1, 1480 // modules.shape[0])
    return Image.fromarray(np.kron(modules, np.ones((scale, scale), np.uint8))).convert("1")


def decode(image: Image.Image, password: str | None = None) -> bytes:
    """Read a standard QR (independent OpenCV ArUco-based detector) and return the original data."""
    gray = np.asarray(image.convert("L"))
    text, _, _ = cv2.QRCodeDetectorAruco().detectAndDecode(gray)
    if not text:
        raise rgcode.NotACodeError("no standard QR code found")
    if not text.startswith(PREFIX):
        return text.encode("utf-8")
    stream = base64.b64decode(text[len(PREFIX):])
    return rgcode.decode_stream(stream, password)


def encode_cascade(data: bytes, password: str | None = None) -> Image.Image:
    """Shape cascade: standard QR if it fits, else rgcode 1:1 -> 3:4 -> 9:16 -> big canvas."""
    try:
        return encode(data, password)
    except rgcode.CapacityError:
        return rgcode.encode_auto(data, password)
