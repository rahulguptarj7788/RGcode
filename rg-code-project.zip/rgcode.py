"""RG-Code: rectangular black-and-white code (reference implementation).

Pipeline (encode):  file -> deflate (only if smaller) -> AES-256-GCM (if password) -> grid
Pipeline (decode):  PNG  -> orientation + grid size derived from the image -> parse -> verify
                    CRC-16 (transport damage) -> verify GCM tag (password / tampering)
                    -> inflate.

Stream layout written row-major into the (H-4) x (W-4) data area (big-endian):
    magic   0xA5                                  1 byte
    version 1 raw | 2 deflate | 3 encrypted       1 byte
    flags   bit0 = deflated before encryption     1 byte   (version 3 only)
    length  length of the STORED payload          4 bytes
    salt    PBKDF2 salt                           16 bytes (version 3 only)
    nonce   AES-GCM nonce                         12 bytes (version 3 only)
    payload stored payload (ciphertext||tag if v3) length bytes
    crc16   CRC-CCITT (init 0xFFFF) of payload    2 bytes
    zero padding up to the grid size
For version 3 the AES-GCM associated data is every header byte before the payload.
"""
import binascii
import os
import struct
import zlib

import numpy as np
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from PIL import Image

MAGIC = 0xA5
V_RAW, V_DEFLATE, V_ENCRYPTED = 1, 2, 3
FLAG_DEFLATED = 0x01        # bit0
FLAG_CHACHA = 0x04          # bit2: 0 = AES-256-GCM, 1 = ChaCha20-Poly1305 (bit1 reserved: Argon2id)
FLAGS_KNOWN = FLAG_DEFLATED | FLAG_CHACHA
PBKDF2_ITERATIONS = 200_000
SALT_LEN, NONCE_LEN, TAG_LEN = 16, 12, 16
QUIET = 4                   # white quiet zone, in modules, on every side
# shape -> (a, b, nominal short side in px); aspect ratio is a:b (width:height)
SHAPES = {"1:1": (1480, (1, 1)), "3:4": (1480, (3, 4)), "9:16": (1480, (9, 16)), "big": (2160, (9, 16)), "big8k": (4320, (9, 16))}
GRADE_PX = {1: 1, 2: 2, 3: 4, 4: 8}   # grade -> square size in pixels (grade 5 = "big" canvas, 1 px)


class RGCodeError(Exception):
    """Base class for every clean decode failure."""


class NotACodeError(RGCodeError):
    """No valid RG-Code found in the image."""


class FileDamagedError(RGCodeError):
    """Magic matched but the CRC did not: the file is damaged."""


class WrongPasswordError(RGCodeError):
    """GCM tag failed: wrong password or tampered data."""


class UnsupportedError(RGCodeError):
    """Valid code, but it uses a feature this reader does not know (reserved flag bits)."""


class CapacityError(RGCodeError):
    """Payload does not fit the chosen grid."""


# ---------------------------------------------------------------- geometry
def _round_half_up(num: int, den: int) -> int:
    return (2 * num + den) // (2 * den)


def _round_half_up(num: int, den: int) -> int:
    return (2 * num + den) // (2 * den)


def grid_size(shape: str, px: int) -> tuple[int, int]:
    """Pinned grid rule (QUIET = 4, all rounding half up, integer arithmetic only):
        W = odd integer nearest to (short_side // px) - 2*QUIET      (ties go up)
        H = round((W + 2*QUIET) * b / a) - 2*QUIET ; if H is even: H += 1
    """
    short, (a, b) = SHAPES[shape]
    w = 2 * ((short // px - 2 * QUIET) // 2) + 1
    h = _round_half_up((w + 2 * QUIET) * b, a) - 2 * QUIET
    return w, h + (1 - h % 2)


def image_size(shape: str, px: int) -> tuple[int, int]:
    """Real PNG size in pixels: grid plus a 4-module quiet zone on each side, times px."""
    w, h = grid_size(shape, px)
    return (w + 2 * QUIET) * px, (h + 2 * QUIET) * px


def overhead(encrypted: bool) -> int:
    """Header + CRC bytes (plus the GCM tag for encrypted codes)."""
    return 8 if not encrypted else 37 + TAG_LEN


def capacity(w: int, h: int, encrypted: bool = False) -> int:
    """Maximum STORED-payload-derived data bytes. Unencrypted: ((H-4)(W-4)-64)//8."""
    return ((h - 4) * (w - 4)) // 8 - overhead(encrypted)


# ---------------------------------------------------------------- crypto
def _derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(hashes.SHA256(), 32, salt, PBKDF2_ITERATIONS)
    return kdf.derive(password.encode("utf-8"))


def _crc16(data: bytes) -> int:
    return binascii.crc_hqx(data, 0xFFFF)


# ---------------------------------------------------------------- encode
def _aead(flags: int, key: bytes):
    return ChaCha20Poly1305(key) if flags & FLAG_CHACHA else AESGCM(key)


def build_stream(data: bytes, password: str | None, compress: bool, cipher: str = "chacha20poly1305") -> bytes:
    """Serialise `data` into the stored byte stream (header | payload | crc)."""
    body, deflated = data, False
    if compress:
        packed = zlib.compress(data, 9)
        if len(packed) < len(data):
            body, deflated = packed, True
    if password is None:
        payload = body
        head = struct.pack(">BBI", MAGIC, V_DEFLATE if deflated else V_RAW, len(payload))
        return head + payload + struct.pack(">H", _crc16(payload))
    salt, nonce = os.urandom(SALT_LEN), os.urandom(NONCE_LEN)
    flags = (FLAG_DEFLATED if deflated else 0) | (FLAG_CHACHA if cipher == "chacha20poly1305" else 0)
    length = len(body) + TAG_LEN
    head = struct.pack(">BBBI", MAGIC, V_ENCRYPTED, flags, length) + salt + nonce
    payload = _aead(flags, _derive_key(password, salt)).encrypt(nonce, body, head)
    return head + payload + struct.pack(">H", _crc16(payload))


def render(stream: bytes, w: int, h: int, px: int) -> Image.Image:
    """Draw the module grid plus a 4-module quiet zone into a 1-bit image."""
    bits_cap = (h - 4) * (w - 4)
    if len(stream) * 8 > bits_cap:
        raise CapacityError(f"stream of {len(stream)} B exceeds grid {w}x{h}")
    bits = np.unpackbits(np.frombuffer(stream, np.uint8))
    bits = np.concatenate([bits, np.zeros(bits_cap - bits.size, np.uint8)])
    g = np.zeros((h, w), np.uint8)               # 1 = black
    g[0, 0::2] = 1                               # row 0: clock track
    g[0::2, 0] = 1                               # column 0: clock track
    g[h - 1, :] = 1                              # bottom frame
    g[:, w - 1] = 1                              # right frame
    g[2:h - 2, 2:w - 2] = bits.reshape(h - 4, w - 4)
    g = np.pad(1 - g, QUIET, constant_values=1)  # white quiet zone
    return Image.fromarray(np.kron(g, np.ones((px, px), np.uint8)) * 255).convert("1")


def encode(data: bytes, shape: str = "9:16", px: int | None = None,
           password: str | None = None, compress: bool = True, cipher: str = "chacha20poly1305") -> Image.Image:
    """Encode `data`. px=None picks the largest square size (sturdiest) that fits."""
    stream = build_stream(data, password, compress, cipher)
    candidates = [px] if px else [8, 4, 2, 1]
    for p in candidates:
        w, h = grid_size(shape, p)
        if len(stream) * 8 <= (h - 4) * (w - 4):
            return render(stream, w, h, p)
    raise CapacityError(f"{len(stream)} B does not fit shape {shape} at px {candidates}")


def encode_auto(data: bytes, password: str | None = None, compress: bool = True) -> Image.Image:
    """Smallest shape first (1:1, 3:4, 9:16), then the big canvas; sturdiest grade that fits."""
    for shape in ("1:1", "3:4", "9:16", "big"):
        try:
            return encode(data, shape, None, password, compress)
        except CapacityError:
            continue
    raise CapacityError("payload too large for every canvas (colour mode is a future hook)")


# ---------------------------------------------------------------- decode
def _runs(line: np.ndarray) -> int:
    """Number of black runs in a boolean line."""
    return int(np.count_nonzero(line[1:] & ~line[:-1]) + int(line[0]))


def _edge_run(line: np.ndarray) -> int:
    """Length of the black run that starts at index 0 of `line`."""
    n = int(np.argmin(line)) if not line.all() else line.size
    return max(n, 1)


def _sample(black: np.ndarray):
    """Derive the module grid from one orientation of the binarised image, or None."""
    ys, xs = np.nonzero(black)
    if ys.size == 0:
        return None
    box = black[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    bh, bw = box.shape
    pitch_x = _edge_run(box[bh // 2, ::-1])       # thickness of the right frame = one module
    pitch_y = _edge_run(box[::-1, bw // 2])       # thickness of the bottom frame
    top = box[min(pitch_y // 2, bh - 1), :]       # clock tracks, read mid-module
    left = box[:, min(pitch_x // 2, bw - 1)]
    w, h = 2 * _runs(top) - 1, 2 * _runs(left) - 1
    if w < 9 or h < 9 or abs(w * pitch_x - bw) > w or abs(h * pitch_y - bh) > h:
        return None
    px_, py_ = bw / w, bh / h
    cols = ((np.arange(w) + 0.5) * px_).astype(int)
    rows = ((np.arange(h) + 0.5) * py_).astype(int)
    grid = box[np.ix_(rows, cols)]
    ok = (grid[h - 1].all() and grid[:, w - 1].all()
          and (grid[0, 0::2].all() and not grid[0, 1::2].any())
          and (grid[0::2, 0].all() and not grid[1::2, 0].any()))
    return grid if ok else None


def _parse_grid(grid: np.ndarray):
    h, w = grid.shape
    return _parse_bytes(np.packbits(grid[2:h - 2, 2:w - 2].astype(np.uint8).ravel()).tobytes())


def _parse_bytes(raw: bytes):
    """Return (version, flags, header_bytes, payload, crc_ok) or None if magic is wrong."""
    if len(raw) < 8 or raw[0] != MAGIC or raw[1] not in (V_RAW, V_DEFLATE, V_ENCRYPTED):
        return None
    version, pos = raw[1], 2
    flags = 0
    if version == V_ENCRYPTED:
        flags, pos = raw[2], 3
    (length,) = struct.unpack_from(">I", raw, pos)
    pos += 4 + (SALT_LEN + NONCE_LEN if version == V_ENCRYPTED else 0)
    if pos + length + 2 > len(raw):
        return None
    payload = raw[pos:pos + length]
    (crc,) = struct.unpack_from(">H", raw, pos + length)
    return version, flags, raw[:pos], payload, crc == _crc16(payload)


def _open(parsed, password):
    """Verify CRC, then decrypt/inflate a parsed stream."""
    version, flags, head, payload, crc_ok = parsed
    if not crc_ok:
        raise FileDamagedError("file damaged: CRC mismatch")
    if version != V_ENCRYPTED:
        return zlib.decompress(payload) if version == V_DEFLATE else payload
    if password is None:
        raise WrongPasswordError("this code is encrypted: a password is required")
    if flags & ~FLAGS_KNOWN:
        raise UnsupportedError("this code uses a newer feature (reserved flag bits set)")
    salt, nonce = head[7:7 + SALT_LEN], head[7 + SALT_LEN:]
    try:
        body = _aead(flags, _derive_key(password, salt)).decrypt(nonce, payload, head)
    except InvalidTag:
        raise WrongPasswordError("wrong password or tampered file") from None
    return zlib.decompress(body) if flags & FLAG_DEFLATED else body


def decode(image: Image.Image, password: str | None = None) -> bytes:
    """Decode an RG-Code image. Size, grade and orientation are derived, never supplied."""
    gray = np.asarray(image.convert("L"))
    for k in range(4):                            # 0/90/180/270; the magic check settles it
        grid = _sample(np.rot90(gray, k) < 128)
        parsed = _parse_grid(grid) if grid is not None else None
        if parsed is not None:
            return _open(parsed, password)
    raise NotACodeError("no RG-Code found in this image")


def decode_stream(stream: bytes, password: str | None = None) -> bytes:
    """Decode a raw RG-Code byte stream (used by the standard-QR tier)."""
    parsed = _parse_bytes(stream)
    if parsed is None:
        raise NotACodeError("not an RG-Code stream")
    return _open(parsed, password)
